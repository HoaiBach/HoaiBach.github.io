package GenerateDataset;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.distribution.LaplaceDistribution;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.distribution.RealDistribution;
import org.apache.commons.math3.distribution.UniformRealDistribution;

import weka.core.Debug.Random;

public class GenerateDataset {

	public GenerateDataset() throws Exception {
		int noInstances = 100;
		int nTotal = 10;
		int nInvariant = 5; //the
		int nVariant = nTotal-nInvariant;
		int nRelated = 6;
//		List<Integer> drawFrom = new ArrayList<Integer>();
//		for(int i=0;i<nTotal;i++) {
//			drawFrom.add(i);
//		}

		List<Integer> related = new ArrayList<Integer>();
//		Collections.shuffle(drawFrom);
//		for(int i=0;i<nRelated;i++) {
//			related.add(drawFrom.get(i));
//		}
		related.add(0);
		related.add(1);
		related.add(4);
		related.add(5);
		related.add(6);

		List<Integer> invariant = new ArrayList<Integer>();
		List<Integer> variant = new ArrayList<Integer>();

		invariant.add(2);
		invariant.add(3);
		invariant.add(7);
		invariant.add(8);
		invariant.add(9);

		variant.add(0);
		variant.add(1);
		variant.add(4);
		variant.add(5);
		variant.add(6);

//		Collections.shuffle(drawFrom);
//		for(int i=0;i<nInvariant;i++) {
//			invariant.add(drawFrom.get(i));
//		}
//		for(int i=nInvariant;i<nTotal;i++) {
//			variant.add(drawFrom.get(i));
//		}

		Random random = new Random(100);

		//weights for buiulding class
		double[] weights = new double[nTotal];
		for(int i=0;i<nTotal;i++) {
			if(related.contains(i))
				weights[i] = 2*(random.nextDouble()-0.5);
			else
				weights[i] = 0;
		}


		//build distributions for each dataset
		RealDistribution[] srcDis = new RealDistribution[nTotal];
		RealDistribution[] tarDis = new RealDistribution[nTotal];

		for(int i=0;i<nTotal;i++) {
			boolean same = true;
			if(variant.contains(i))
				same = false;
			RealDistribution[] pair = buildDistribution(same, random);
			srcDis[i] = pair[0];tarDis[i] = pair[1];
		}

		//generate dataset for each set of distribution
		double[][] src = generateData(srcDis, noInstances, weights);
		double[][] tarU = generateData(tarDis, noInstances, weights);
		double[][] tarL = generateData(tarDis,noInstances,weights);

		String dir = "/home/nguyenhoai2/Eclipse/Datasets/Transferlearning/Pairs/SimpleSynthetic/";
		new File(dir).mkdirs();
		PrintStream pt = new PrintStream(new File(dir+"noFeatures"));
		pt.println(nTotal);
		pt.close();
		pt = new PrintStream(new File(dir+"information"));
		pt.println("Related features: ("+nRelated+")");
		for(int index:related)
			pt.print(index+",");
		pt.println();
		pt.println("Invariant features: ("+nInvariant+")");
		for(int index:invariant)
			pt.print(index+",");
		pt.println();
		pt.println("Variant features: ("+nVariant+")");
		for(int index:variant)
			pt.print(index+",");
		pt.println();
		pt.close();

		printDataset(src,dir+"Source");
		printDataset(tarL,dir+"TargetL");
		printDataset(tarU,dir+"TargetU");

	}

	public void printDataset(double[][] data, String name) throws FileNotFoundException {
		PrintStream pt = new PrintStream(new File(name));
		for(int i=0;i<data.length;i++) {
			for(int j=0;j<data[0].length-1;j++) {
				pt.print(data[i][j]+",");
			}
			pt.println(data[i][data[0].length-1]);
		}
	}

	public double[][] generateData(RealDistribution[] dis, int noInstances, double[] weights) throws Exception{
		//inclduing class
		double[][] data = new double[noInstances][dis.length+1];
		for(int i=0;i<noInstances;i++) {
			double[] features = new double[dis.length];
			for(int j=0;j<dis.length;j++) {
				double value = dis[j].sample();
				features[j] = value;
				data[i][j] = value;
			}
			data[i][dis.length] = this.createClass(features, weights);
		}
		return data;
	}

	public double createClass(double[] features,double[] weights) throws Exception {
		if(features.length!=weights.length)
			throw new Exception("Feature vector and weight vector do no have the same length!!");
		double sum = 0;
		for(int i=0;i<features.length;i++) {
			sum+= features[i] * weights[i];
		}

		return sum>0.0?1:0;
	}

	public RealDistribution[] buildDistribution(boolean same, Random random) throws Exception {
		//0: exponential
		//1: uniform
		//2: gamma
		//3: Laplace
		//4: nornal
		RealDistribution src,tar;
		int type = random.nextInt(5);
		switch(type) {
		case 0:
//			double mean1 = random.nextDouble();
//			src = new ExponentialDistribution(mean1);
//			double mean2;
//			if(same) {
//				mean2 = mean1;
//			}
//			else {
//				mean2 = gen(mean1, random);
//			}
//			tar = new ExponentialDistribution(mean2);
//			break;

		case 1:
//			double lower1 = random.nextDouble();
//			double upper1 = random.nextDouble();
//			if(lower1 > upper1) {
//				double tmp = upper1;
//				upper1 = lower1;
//				lower1 = tmp;
//			}
//			src= new UniformRealDistribution(lower1, upper1);
//			double lower2,upper2;
//			if(same) {
//				lower2 = lower1; upper2 = upper1;
//			}
//			else {
//				lower2 = gen(lower1,random);
//				upper2 = gen(upper1,random);
//			}
//			if(lower2 > upper2) {
//				double tmp = upper2;
//				upper2 = lower2;
//				lower2 = tmp;
//			}
//			tar = new UniformRealDistribution(lower2, upper2);
//			break;
		case 2:
//			double shape1 = random.nextDouble();
//			double scale1 = random.nextDouble();
//			src = new GammaDistribution(shape1, scale1);
//			double shape2,scale2;
//			if(same) {
//				shape2 = shape1;scale2= scale1;
//			}
//			else {
//				shape2 = gen(shape1,random);
//				scale2 = gen(scale1,random);
//			}
//			tar = new GammaDistribution(shape2, scale2);
//			break;
		case 3:
//			double mu1 = random.nextDouble();
//			double beta1 = random.nextDouble();
//			src = new LaplaceDistribution(mu1, beta1);
//			double mu2,beta2;
//			if(same) {
//				mu2 = mu1; beta2 = beta1;
//			}
//			else {
//				mu2 = gen(mu1,random);
//				beta2 = gen(beta1,random);
//			}
//			tar = new LaplaceDistribution(mu2, beta2);
//			break;
		case 4:
			double mean41 = random.nextDouble();
			double sd41 = random.nextDouble();
			src = new NormalDistribution(mean41, sd41);
			double mean42,sd42;
			if(same) {
				mean42 = mean41; sd42 = sd41;
			}
			else {
				mean42 = gen(mean41,random);
				sd42 = gen(sd41,random);
			}
			tar= new NormalDistribution(mean42, sd42);
			break;
		default:
			throw new Exception("Wrong index for distribution!!!");
		}
		return new RealDistribution[] {src,tar};
	}

	public double gen(double value, Random random) {
		double ge = value;
		while(ge==value)
			ge = random.nextDouble();
		return ge;
	}

	public static void main(String[] args) throws Exception {
		GenerateDataset gen = new GenerateDataset();
	}
}
