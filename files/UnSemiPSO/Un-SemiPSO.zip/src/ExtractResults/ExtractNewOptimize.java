package ExtractResults;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import TransferMain.MyClassifier;
import Utility.HelpDataset;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.Instance;
import net.sf.javaml.distance.DistanceMeasure;
import net.sf.javaml.distance.EuclideanDistance;
import net.sf.javaml.tools.data.FileHandler;

public class ExtractNewOptimize {

	public static void main(String[] args) throws IOException {
		String[] datasets = new String[] {"GasSensor1-8", "SURFc-w", "USPS-MNIST"};
		String dir = "/local/scratch/Transferlearning/Pairs/";
		for(String dataset: datasets) {
			String srcName = dir+dataset+"/Source";
			String tarUName = dir+dataset+"/TargetU";
			String tarLName = dir+dataset+"/TargetL";

			Scanner sc = new Scanner(new File(dir+dataset+"/noFeatures"));
			int noFeatures = Integer.parseInt(sc.nextLine().trim());
			sc.close();

			Dataset srcDataset  = FileHandler.loadDataset(new File(srcName), noFeatures,",");
			Dataset tarUDataset = FileHandler.loadDataset(new File(tarUName), noFeatures,",");
			Dataset tarLDataset = FileHandler.loadDataset(new File(tarLName), noFeatures,",");

			for(int sw = 0;sw<=10;sw++) {
				for(int tw = 0; tw<= 10-sw;tw++) {
					double dsw = sw/10.0;
					double dtw = tw/10.0;
					String fileName = "Optimize/Results/Sup/"+dataset+"/"+dsw+"_"+dtw+".txt";
					new File("NewOptimize/Results/Sup/"+dataset).mkdirs();
					PrintStream pt = new PrintStream(new File("NewOptimize/Results/Sup/"+dataset+"/"+dsw+"_"+dtw+".txt"));
					sc = new Scanner(new File(fileName));
					int size = 0;
					double[] features = new double[noFeatures];

					while(sc.hasNext()) {
						String line = sc.nextLine();
						if(line.startsWith("Size")) {
							line = sc.nextLine();
							size = Integer.parseInt(line.split(",")[0]);
							pt.println("Size");
							pt.println(size);
							pt.println("=========================");
							line = sc.nextLine();
							line = line.substring(1);
							line = line.substring(0, line.length()-1);
							String[] splits = line.split(",");
							for(int i=0;i<features.length;i++) {
								features[i] = Double.parseDouble(splits[i].trim());
							}
							break;
						}
					}

					Dataset newSrc= HelpDataset.removeFeatures(srcDataset.copy(), features);
					Dataset newTarL = HelpDataset.removeFeatures(tarLDataset.copy(), features);


					MyClassifier classifier = new MyClassifier(new Random(1));
					classifier.ClassifierBingKNN(1);
					double accNTF = classifier.classify(srcDataset, tarLDataset);
					double accTF = classifier.classify(newSrc, newTarL);
					pt.println("KNN(1):");
					pt.println("No transfer learning: "+accNTF);
					pt.println("Transfer learning: "+accTF);
//
					classifier.ClassifierLibSVM();
					accNTF = classifier.classify(srcDataset, tarLDataset);
					accTF = estimateError(newSrc, newTarL);
					pt.println("LibSVM:");
					pt.println("No transfer learning: "+accNTF);
					pt.println("Transfer learning: "+accTF);
					pt.close();
				}
			}
		}
	}

	public static double estimateError(Dataset src, Dataset tar) {
		Map<Instance, Instance> t2t = new HashMap<Instance,Instance>();
		Map<Instance, Instance> t2s = new HashMap<Instance,Instance>();
		for(Instance ti: tar) {
			//closest source instance to ti
			DistanceMeasure dm = new EuclideanDistance();
			Set<Instance> cs = src.kNearest(1, ti, dm);
			for(Instance tmp:cs )
				t2s.put(ti, tmp);

			//closest target isntance to ti
			Set<Instance> ct = tar.kNearest(1, ti, dm);
			for(Instance tmp:ct )
				t2t.put(ti, tmp);
		}

		int count = 0;
		//now count the number of case that two target
		//instances can share the same class
		for(int i=0;i<tar.size();i++) {
			Instance ti = tar.get(i);//the current instance
			Instance st = t2s.get(ti);//the closet source instance from the current instance
			Instance ct = t2t.get(ti);//the cloest target instance from the current instance
			Instance sct = t2s.get(ct);//the closet source instance of the cloest targe instance
			//not check label of si and sct
			if(st.classValue().equals(sct.classValue()))
				count++;
		}
		return (count+0.0)/tar.size();
	}

}
