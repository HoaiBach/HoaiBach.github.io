package ExtractResults;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Random;
import java.util.Scanner;

import TransferMain.MyClassifier;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.tools.data.FileHandler;

public class TestFull {

	public static void main(String[] args) throws IOException{
		String[] datasets = new String[] {
				"GasSensor1-2","GasSensor1-3","GasSensor1-4",
				"GasSensor1-5","GasSensor1-6","GasSensor1-7",
				"GasSensor1-8","GasSensor1-9","GasSensor1-10",
				"MNIST-USPS","USPS-MNIST",
				"SURFa-c","SURFa-d","SURFa-w",
				"SURFc-a","SURFc-d","SURFc-w",
				"SURFd-a","SURFd-c","SURFd-w",
				"SURFw-a","SURFw-d","SURFw-c",};
		String dir = "/Users/nguyenhoai2/Documents/Datasets/Transferlearning/Pairs/";

		PrintStream pt = new PrintStream(new File("test.txt"));
		for(String dataset: datasets) {
			String srcName = dir+dataset+"/Source";
			String tarUName = dir+dataset+"/TargetU";
			String tarLName = dir+dataset+"/TargetL";

			Scanner sc = new Scanner(new File(dir+dataset+"/noFeatures"));
			int noFeatures = Integer.parseInt(sc.nextLine().trim());
			sc.close();

			Dataset srcDataset  = FileHandler.loadDataset(new File(srcName), noFeatures,",");
			Dataset tarUDataset = FileHandler.loadDataset(new File(tarUName), noFeatures,",");
			Dataset tarLDataset = FileHandler.loadDataset(new File(tarLName), noFeatures,",");
			
			MyClassifier classifier = new MyClassifier(new Random(1));
			classifier.ClassifierBingKNN(1);
			double accNTF = classifier.classify(srcDataset, tarLDataset);
			pt.println(dataset+": "+accNTF);
		}
		pt.close();
		
	}
}
