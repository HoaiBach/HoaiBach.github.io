package ExtractResults;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Random;
import java.util.Scanner;

import TransferMain.MyClassifier;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;
import net.sf.javaml.core.DenseInstance;
import net.sf.javaml.core.Instance;

public class Temp {

	public static void main(String[] args) throws FileNotFoundException {

		String[] datasets = new String[] {
				"GasSensor1-2","GasSensor1-3","GasSensor1-4",
				"GasSensor1-5","GasSensor1-6","GasSensor1-7",
				"GasSensor1-8","GasSensor1-9","GasSensor1-10",
				"MNIST-USPS","USPS-MNIST",
				"SURFa-c","SURFa-d","SURFa-w",
				"SURFc-a","SURFc-d","SURFc-w",
				"SURFd-a","SURFd-c","SURFd-w",
				"SURFw-a","SURFw-d","SURFw-c",};

		String[] methods = new String[]{"MIDA.txt","SMIDA.txt","STCA.txt","TCA.txt"};

		String inDir = "NewOptimize/Results/Traditional/";
		String outDir = "Results/Full/Traditional/";

		MyClassifier classifier = new MyClassifier(new Random(1));
		classifier.ClassifierBingKNN(1);

		for(String dataset: datasets) {
			new File(outDir+dataset).mkdirs();
			for(String method: methods) {
				File outFile = new File(outDir+dataset+"/"+method);
				PrintStream pt = new PrintStream(outFile);
				Scanner sc = new Scanner(new File(inDir+dataset+"/"+method));
				Dataset training = new DefaultDataset();
				Dataset test = new DefaultDataset();
				while(sc.hasNextLine()) {
					String line = sc.nextLine();
					if(line.startsWith("Train"))
						break;
				}
				while(sc.hasNextLine()) {
					String line = sc.nextLine();
					if(line.startsWith("Test"))
						break;
					training.add(line2Instance(line));
				}
				while(sc.hasNextLine())
					test.add(line2Instance(sc.nextLine()));
				sc.close();
				double acc = classifier.classify(training, test);
				int nf = training.noAttributes();
				pt.println("Number of features: "+nf);
				pt.println("Accuracy: "+acc);
				pt.close();
			}
		}


	}

	public static String getLine(File file,int noLine) throws FileNotFoundException {
		Scanner sc= new Scanner(file);
		int count =1;
		while(count < noLine)
		{
			sc.nextLine();count++;
		}
		String line = sc.nextLine();
		return line;
	}

	public static Instance line2Instance(String line) {
		String[] splits = line.split(",");
		int nf = splits.length-1;
		double[] fs = new double[nf];
		for(int i=0;i<nf;i++) {
			fs[i] = Double.parseDouble(splits[i].trim());
		}
		Instance ins = new DenseInstance(fs);
		ins.setClassValue(Double.parseDouble(splits[nf]));
		return ins;
	}

}
