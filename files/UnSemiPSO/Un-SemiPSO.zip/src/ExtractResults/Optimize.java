package ExtractResults;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class Optimize {

	public static void main(String[] args) throws FileNotFoundException {

		String[] datasets = new String[] {"GasSensor1-8","SURFc-w","USPS-MNIST"};
		String[] types = new String[] {"Sup","UnSup"};
		Map<String,Integer> fulls = new HashMap<String,Integer>();
		fulls.put("GasSensor1-8", 128);
		fulls.put("SURFc-w", 800);
		fulls.put("USPS-MNIST", 256);



		PrintStream pt =new PrintStream(new File("Optimize/optimize.tex"));

		pt.println("\\documentclass[a4paper]{report}\n\n"
				+ "\\usepackage[cm]{fullpage}\n"
				+ "\\usepackage{multirow}\n\n"
				+ "\\begin{document}\n\n");

		for(String dataset: datasets) {
			for(String type: types)
			{
				String table = "\\begin{table}\n"
						+ "\\centering\n"
						+ "\\footnotesize\n"
						+ "\\begin{tabular}{|c|c|c|c|c|c|c|c|c|c|}\n"
						+ "\\hline\n"
						+ "\\multirow{2}{*}{W}&\\multicolumn{3}{c|}{KNN}&\\multicolumn{3}{c|}{SVM}&\\multicolumn{3}{c|}{Overall}\\\\\n"
						+ "\\cline{2-10}\n"
						+ "&Acc&Size&Rank&Acc&Size&Rank&Acc&Size&Rank\\\\\n"
						+ "\\hline\n";

				String dir = "NewOptimize/Results/"
						+ type+"/"+dataset;

				List<String> weights = new ArrayList<String>();
				List<Double> knn = new ArrayList<Double>();
				List<Double> svm = new ArrayList<Double>();
				List<Double> improved = new ArrayList<Double>();
				double knn_no = 0;
				double svm_no = 0;
				List<Integer> size = new ArrayList<Integer>();

				Map<Double,Double> swAcck = new HashMap<Double, Double>();
				Map<Double,Double> swAccn = new HashMap<Double, Double>();
				Map<Double,Integer> swCo = new HashMap<Double,Integer>();
				Map<Double,Double> twAcck = new HashMap<Double, Double>();
				Map<Double,Double> twAccn = new HashMap<Double, Double>();
				Map<Double,Integer> twCo = new HashMap<Double,Integer>();
				Map<Double,Double> stwAcck = new HashMap<Double, Double>();
				Map<Double,Double> stwAccn = new HashMap<Double, Double>();
				Map<Double,Integer> stwCo = new HashMap<Double,Integer>();

				new File("NewOptimize/Processed/"+dataset).mkdirs();
				PrintStream proc = new PrintStream(new File("NewOptimize/Processed/"+dataset+".txt"));
				proc.println("sw,tw,stw,knn,svm");

				for(int swi = 0;swi<=10;swi=swi+1)
					for(int twi=0;twi<=10-swi;twi=twi+1) {
						double sw = swi/10.0;
						double tw =twi/10.0;
						double stw = (10-swi-twi)/10.0;

						String toPrint = sw+","+tw+","+stw;

						String w = sw+"-"+tw;
						weights.add(w);

						Scanner sc = new Scanner(new File(dir+"/"+sw+"_"+tw+".txt"));
						while(sc.hasNext()) {
							String line = sc.nextLine();
							if(line.startsWith("Size")) {
								line  = sc.nextLine();
								int nf = Integer.parseInt(line.split(",")[0].trim());
								size.add(nf);
							}
							else if(line.startsWith("KNN")) {
								line = sc.nextLine();
								if(knn_no ==0)
									knn_no = Double.parseDouble(line.split(":")[1].trim());
								line = sc.nextLine();
								double acc = Double.parseDouble(line.split(":")[1].trim());
								knn.add(acc);
								toPrint+=","+acc;
							}
							else if(line.startsWith("LibSVM")) {
								line = sc.nextLine();
								if(svm_no ==0)
									svm_no = Double.parseDouble(line.split(":")[1].trim());
								line = sc.nextLine();
								double acc = Double.parseDouble(line.split(":")[1].trim());
								svm.add(acc);
								toPrint+=","+acc;
							}
						}
						improved.add((knn.get(knn.size()-1)/knn_no+svm.get(svm.size()-1)/svm_no)*0.5);
						sc.close();
						proc.println(toPrint);
					}

				proc.close();

				Double[] knna = list2Array(knn);
				Double[] svma = list2Array(svm);
				Double[] improveda = list2Array(improved);
				IndexSorter<Double> is = new IndexSorter<Double>(knna);is.sort();
				Integer[] knns = is.getIndexes();
				is = new IndexSorter<Double>(svma);is.sort();
				Integer[] svms = is.getIndexes();
				is= new IndexSorter<Double>(improveda);is.sort();
				Integer[] imps = is.getIndexes();

				int fullSize = fulls.get(dataset);

				table+="NoTL&"+c2decmial(knn_no)+"&"+fullSize+"&&"+c2decmial(svm_no)+"&&&&&\\\\\n\\hline\n";


				for(int i=0;i<weights.size();i++) {
					String w = weights.get(i);
					double knnacc = knn.get(i);
					int knnra = indexOf(i,knns);
					double svmacc = svm.get(i);
					int svmra = indexOf(i,svms);
					double impacc = improved.get(i);
					int impra = indexOf(i, imps);
					int s = size.get(i);
					table+=w+"&"+c2decmial(knnacc)+"&"+s+"&"+knnra
							+"&"+c2decmial(svmacc)+"&"+s+"&"+svmra
							+"&"+c2decmial(impacc)+"&"+s+"&"+impra
									+ "\\\\\n\\hline\n";
				}

				table+="\\end{tabular}\n";
				table+="\\caption{"+dataset+"("+type+").}\n";
				table+="\\end{table}\n";
				pt.println(table);
			}
		}

		pt.println("\\end{document}");
		pt.close();
	}

	public static Double[] list2Array(List<Double> list) {
		Double[] array = new Double[list.size()];
		for(int i=0;i<list.size();i++)
			array[i] = list.get(i);
		return array;
	}

	public static double c2decmial(double value) {
		return ((int)(value*100+0.5))/100.0;
	}

	public static Integer indexOf(Integer a, Integer[] values) {
		for(int i=0;i<values.length;i++)
			if(values[i] == a)
				return i;
		return -1;
	}
}
