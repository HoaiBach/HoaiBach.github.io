package ExtractResults;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ExtractResults {

	public static void main(String[] args) throws FileNotFoundException {
		String[] datasets = new String[] {
				"GasSensor1-2","GasSensor1-3","GasSensor1-4",
				"GasSensor1-5","GasSensor1-6","GasSensor1-7",
				"GasSensor1-8","GasSensor1-9","GasSensor1-10",
				"MNIST-USPS","USPS-MNIST",
				"SURFa-c","SURFa-d","SURFa-w",
				"SURFc-a","SURFc-d","SURFc-w",
				"SURFd-a","SURFd-c","SURFd-w",
				"SURFw-a","SURFw-d","SURFw-c",};
		String[] methods = new String[] {"Sup","UnSup"};
		String[] trMethods = new String[] {"MIDA","SMIDA","TCA","STCA"};
		File out = new File("Latex/table.txt");
		PrintStream pt =new PrintStream(out);
		pt.println("\\begin{table*}\n"
				+ "\\begin{tabular}{|l|c|c|c|c|c|c|c|c|c|c|}\n\\hline\n"
				+ "\\multirow{2}{*}{Dataset}& \\multicolumn{2}{c|}{SupPSO} & \\multicolumn{2}{c|}{UnPSO}"
				+ "& \\multicolumn{2}{c|}{Full} & \\multirow{2}{*}{TCA} & \\multirow{2}{*}{STCA} & \\multirow{2}{*}{MIDA} & \\multirow{2}{*}{SMIDA} \\\\\n"
				+ "\\cline{2-7}\n"
				+ "& \\#F & Acc & \\#F & Acc & \\#F & Acc &&&&\\\\\n"
				+ "\\hline");

		//0-w,1-d,2-l
		Map<String,int[]> sup = new HashMap<String,int[]>();
		Map<String,int[]> un = new HashMap<String,int[]>();
		sup.put("STCA", new int[3]);sup.put("SMIDA", new int[3]);sup.put("Full", new int[3]);
		un.put("TCA", new int[3]);un.put("MIDA", new int[3]);un.put("Full", new int[3]);

		for(String dataset: datasets) {
			Map<String,double[]> m2a = new HashMap<String,double[]>();
			Map<String,double[]> m2f = new HashMap<String,double[]>();

			//full
			double fa = -1;
			Scanner sc = new Scanner(new File("/local/scratch/Transferlearning/Pairs/"+dataset+"/noFeatures"));
			int fn = Integer.parseInt(sc.nextLine().trim());
			sc.close();

			for(String method: methods) {
				m2a.put(method, new double[30]);
				m2f.put(method, new double[30]);

				String dir = "Results/Full/"+method+"/"+dataset;
				for(int i=1;i<=30;i++) {
					File file = new File(dir+"/Output_"+i+".txt");
					sc = new Scanner(file);
					while(sc.hasNext()) {
						String line = sc.nextLine();
						if(line.startsWith("Size")) {
							line = sc.nextLine();
							double f = Double.parseDouble(line.split(",")[0].trim());
							m2f.get(method)[i-1] = f;
						}
						else if(line.startsWith("KNN")) {
							line = sc.nextLine();
							if(fa <0) {
								fa =  Double.parseDouble(line.split(":")[1].trim())*100;
							}
							line = sc.nextLine();
							double a =  Double.parseDouble(line.split(":")[1].trim())*100;
							m2a.get(method)[i-1] = a;
							break;
						}
					}
					sc.close();
				}
			}

			//update significant test
			int compare = isbetter(m2a.get("Sup"), fa);
			if(compare>0)
				sup.get("Full")[0]++;
			else if(compare==0) {
				sup.get("Full")[1]++;
				System.out.println("Sup is same Full on "+dataset);
			}
			else {
				sup.get("Full")[2]++;
				System.out.println("Sup is worse than Full on "+dataset);
			}

			compare = isbetter(m2a.get("UnSup"), fa);
			if(compare>0)
				un.get("Full")[0]++;
			else if(compare==0) {
				un.get("Full")[1]++;
				System.out.println("UnSup is same Full on "+dataset);
			}
			else {
				un.get("Full")[2]++;
				System.out.println("UnSup is worse than Full on "+dataset);
			}
			//end

			for(String method: trMethods) {
				m2a.put(method, new double[1]);
				File file = new File("Results/Full/Traditional/"+dataset+"/"+method+".txt");
				sc = new Scanner(file);
				sc.nextLine();
				String line = sc.nextLine();
				double acc = Double.parseDouble(line.split(":")[1].trim())*100;
				sc.close();
				m2a.get(method)[0] = acc;

				//update significant test
				if(method.equals("STCA") || method.equals("SMIDA")){
					compare = isbetter(m2a.get("Sup"), acc);
					if(compare>0)
						sup.get(method)[0]++;
					else if(compare==0) {
						sup.get(method)[1]++;
						System.out.println("Sup is same "+method+ " on "+dataset);
					}
					else {
						sup.get(method)[2]++;
						System.out.println("Sup is worse than "+method+ " on "+dataset);
					}
				}
				else {
					compare = isbetter(m2a.get("UnSup"), acc);
					if(compare>0)
						un.get(method)[0]++;
					else if(compare==0) {
						un.get(method)[1]++;
						System.out.println("UnSup is same "+method+ " on "+dataset);
					}
					else {
						un.get(method)[2]++;
						System.out.println("UnSup is worse than "+method+ " on "+dataset);
					}
				}
				//end
			}


			//print result
			if(dataset.startsWith("SURF")) {
				String toPrint = dataset.substring(4);
				pt.print(up(toPrint));
			}
			else
				pt.print(dataset);

			String m = "Sup";
			pt.print("& "+r2(ave(m2f.get(m))) +" & "+r2(ave(m2a.get(m))));
			m="UnSup";
			pt.print("& "+r2(ave(m2f.get(m))) +" & "+r2(ave(m2a.get(m))));
			pt.print("& "+fn +" & "+r2(fa));
			pt.print("& "+r2(m2a.get("TCA")[0]));
			pt.print("& "+r2(m2a.get("STCA")[0]));
			pt.print("& "+r2(m2a.get("MIDA")[0]));
			pt.print("& "+r2(m2a.get("SMIDA")[0]));
			pt.print("\\\\\n"
					+ "\\hline\n");
		}
		pt.println("\\end{tabular}\n"
				+ "\\end{table*}");

		pt.println("\\begin{table}\n"
				+ "\\centering\n"
				+ "\\caption{UnPSO vs unsupervised methods}"
				+ "\\begin{tabular}{|c|c|c|\n"
				+ "\\hline\n"
				+ "Full&TCA&MIDA\n"
				+ "\\hline\n");
		String method = "Full";
		int[] score = un.get(method);
		pt.print(score[0]+"/"+score[1]+"/"+score[2]);
		method = "TCA";
		score = un.get(method);
		pt.print("& "+score[0]+"/"+score[1]+"/"+score[2]);
		method = "MIDA";
		score = un.get(method);
		pt.print("& "+score[0]+"/"+score[1]+"/"+score[2]);
		pt.println("\\hline\n"
				+ "\\end{tabular}\n"
				+ "\\end{table}");

		pt.println("\\begin{table}\n"
				+ "\\centering\n"
				+ "\\caption{SupPSO vs semi-supervised methods}"
				+ "\\begin{tabular}{|c|c|c|\n"
				+ "\\hline\n"
				+ "Full&STCA&SMIDA\n"
				+ "\\hline\n");
		method = "Full";
		score = sup.get(method);
		pt.print(score[0]+"/"+score[1]+"/"+score[2]);
		method = "STCA";
		score = sup.get(method);
		pt.print("& "+score[0]+"/"+score[1]+"/"+score[2]);
		method = "SMIDA";
		score = sup.get(method);
		pt.print("& "+score[0]+"/"+score[1]+"/"+score[2]);
		pt.println("\\hline\n"
				+ "\\end{tabular}\n"
				+ "\\end{table}");


		pt.close();



	}

	public static double ave(double[] v) {
		double sum = 0;
		for(double value:v) {
			sum+=value;
		}
		return sum/v.length;
	}

	public static double r2(double v) {
		return ((int)(v*100+0.5))/100.0;
	}

	public static String up(String s) {
		String up = "";
		for(int i=0;i<s.length();i++) {
			up+= s.substring(i, i+1).toUpperCase();
		}
		return up;
	}

	public static int isbetter(double[] mine,double single) {
		double[] mx = new double[mine.length];
		for(int i=0;i<mx.length;i++)
			mx[i] = single;
		String result = WilsonTestBing.TestBingNew(mx, mine);
		if(result.equals("+"))
			return 1;
		else if(result.equals("="))
			return 0;
		else return -1;
	}


}
