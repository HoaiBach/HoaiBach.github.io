package TransferMain;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import Swarm.Swarm;
import Topology.Topology;
import Topology.TopologyStar;
import Utility.HelpDataset;
import Utility.RandomSeed;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;
import net.sf.javaml.core.Instance;
import net.sf.javaml.filter.normalize.NormalizeMean;
import net.sf.javaml.tools.data.FileHandler;

public class TransferLearning {

	/**
	 *
	 * @param args: 1st: run index, 2nd: unsupervised == true?
	 * 3rd: sw, 4th: tw
	 *
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		int r = Integer.parseInt(args[0]);
		boolean unsup = Integer.parseInt(args[1]) == 1;
		double sw = Double.parseDouble(args[2])/10;
		double tw = Double.parseDouble(args[3])/10;

		//int addTargetLabel = Integer.parseInt(args[1]);
		int noIterations = 100;

		long seeder = (long) (Math.pow(10, 6)*(r+3));
		RandomSeed.Seeder.setSeed(seeder);

		//String dataset = args[4];
		//String dir = "/local/scratch/Transferlearning/Pairs/";
		String srcName ="Source";//dir+dataset+"/Source";
		String tarUName = "TargetU";//dir+dataset+"/TargetU";
		String tarLName = "TargetL";//dir+dataset+"/TargetL";

		Scanner sc = new Scanner(new File("noFeatures"));
		int noFeatures = Integer.parseInt(sc.nextLine().trim());
		sc.close();

		Dataset srcDataset  = FileHandler.loadDataset(new File(srcName), noFeatures,",");
//		srcDataset = buildNewDataset(srcDataset, srcDataset.size()/5);
		Dataset tarUDataset = FileHandler.loadDataset(new File(tarUName), noFeatures,",");
//		tarUDataset = buildNewDataset(tarUDataset, tarUDataset.size()/5);
		Dataset tarLDataset = FileHandler.loadDataset(new File(tarLName), noFeatures,",");
//		tarLDataset = buildNewDataset(tarLDataset, tarUDataset.size()/5);

		MyClassifier classifier = new MyClassifier(new Random(1));
		classifier.ClassifierBingKNN(1);

		//normalize in the range [0,1]
		Dataset allDataset = new DefaultDataset();
		allDataset.addAll(srcDataset);
		allDataset.addAll(tarUDataset);
//		allDataset.addAll(tarLDataset);
		NormalizeMean nmf = new NormalizeMean();
		nmf.filter(allDataset);
		System.out.println(allDataset.get(0).value(0));
		System.exit(0);
		int srcSize= srcDataset.size();
		int tarUSize = tarUDataset.size();
		int tarLSize = tarLDataset.size();
		srcDataset = new DefaultDataset();
		tarUDataset = new DefaultDataset();
		tarLDataset = new DefaultDataset();
		for(int i=0;i<allDataset.size();i++) {
			if(i<srcSize)
				srcDataset.add(allDataset.get(i));
			else if(i<srcSize+tarUSize)
				tarUDataset.add(allDataset.get(i));
			else if(i<srcSize+tarUSize+tarLSize)
				tarLDataset.add(allDataset.get(i));
		}



		FeatureTransfer ft = new FeatureTransfer(srcDataset, tarUDataset, tarLDataset, 0.6,classifier,sw,tw, unsup);
//		String fileName;
//		String resultDir = "EstimateResult/"+dataset+"/";
//		new File(resultDir).mkdirs();

//		if(unsup)
//			fileName = "UnSup.txt";
//		else
//			fileName = "Sup.txt";

		File out = new File(sw+"_"+tw+".txt");
		PrintStream pt = new PrintStream(out);
		pt.println("sw= "+sw+", tw= "+tw);

		if(unsup)
			pt.println("Unsupervised learning");
		else
			pt.println("Supervised learning");

		int dimension = noFeatures;
		int noParticles;
		if(noFeatures>100)
			noParticles = 100;
		else
			noParticles = noFeatures;

		Topology topology = new TopologyStar();
		Swarm s = new Swarm(dimension, noParticles,
				noIterations,topology,
				Swarm.STICKY_SWARM,RandomSeed.Create(),ft);
		s.initialise();

		//to store the value during running time
		double[] fitnessArray = new double[noIterations];
		double[][] positions = new double[noIterations][noFeatures];

		//start run PSO
		long runningTime = System.currentTimeMillis();
		for (int i = 0; i < noIterations; ++i) {
			s.iterate(i);
			fitnessArray[i] = s.getSwarm().get(0).getGlobalFitness();
			List<Double> bestPosition = s.getSwarm().get(0).getGlobalPosition();
			positions[i] = ((FeatureTransfer)ft).positionToFeatures(bestPosition);
		}
		//end all iterations

		// ****************** Results of the r-th Run  ***********************
		long estimatedTime = System.currentTimeMillis() - runningTime;
		List<Double> bestPosition = s.getSwarm().get(0).getGlobalPosition();
		double fitness = s.getSwarm().get(0).getGlobalFitness();
		double[] features = ((FeatureTransfer)ft).positionToFeatures(bestPosition);
		Dataset newSrc = HelpDataset.removeFeatures(srcDataset.copy(), features);
		Dataset newTar = HelpDataset.removeFeatures(tarUDataset.copy(), features);
		int size = ((FeatureTransfer)ft).sizeSubset(features);

		pt.println("===========================================================");
		for(int i=0;i<noIterations;i++){
			System.out.println(i);
			pt.println("Iteration "+i+":");
			pt.println("Fitness: "+fitnessArray[i]);
			pt.println("Features: "+Arrays.toString(positions[i]));
			pt.println("===========================================================");
		}
		pt.println("Size, Fitness, RunningTime");
		pt.println(size+","+
				twoDecimal(fitness*100)+", "+estimatedTime);
		pt.println(Arrays.toString(features));


		List<Integer> selected = new ArrayList<Integer>();
		for(int i=0;i<features.length;i++) {
			if (features[i]==1.0)
				selected.add(i);
		}
		pt.println("Selected features: ");
		for(int i: selected)
			pt.print(i+", ");
		pt.println();

		pt.println("===================Classifiers=================");

		classifier.ClassifierBingKNN(1);
		double accNTF = classifier.classify(srcDataset, tarUDataset);
		double accTF = classifier.classify(newSrc, newTar);
		pt.println("KNN(1):");
		pt.println("No transfer learning: "+accNTF);
		pt.println("Transfer learning: "+accTF);

		classifier.ClassifierLibSVM();
		accNTF = classifier.classify(srcDataset, tarUDataset);
		accTF = classifier.classify(newSrc, newTar);
		pt.println("LibSVM:");
		pt.println("No transfer learning: "+accNTF);
		pt.println("Transfer learning: "+accTF);

		classifier.ClassifierNB();
		accNTF = classifier.classify(srcDataset, tarUDataset);
		accTF = classifier.classify(newSrc, newTar);
		pt.println("NaiveBayes:");
		pt.println("No transfer learning: "+accNTF);
		pt.println("Transfer learning: "+accTF);
		pt.close();
	}

	public static double twoDecimal(double s){
		return (int)(s*100+0.5)/100.0;
	}


	/**
	 * Ensreu each class has at least 1 insatnace
	 * @param dataset
	 * @return
	 * @throws Exception
	 */
	public static Dataset buildNewDataset(Dataset dataset, int noInstance) throws Exception {
		int noClass = dataset.classes().size();
		Dataset toReturn = new DefaultDataset();
		if(noInstance < noClass)
			throw new Exception("The number of instance must be at least equal to the number of class!");

		//now build the set of instances for each class
		Map<Object,List<Instance>> class2Instaces = new HashMap<Object,List<Instance>>();
		for(Object c: dataset.classes()) {
			List<Instance> instances = new ArrayList<Instance>();
			class2Instaces.put(c, instances);
		}
		for(Instance ins: dataset) {
			class2Instaces.get(ins.classValue()).add(ins);
		}

		//now define the number of instance added to each class based on its original number of instances
		for(Object c: dataset.classes()) {
			int toAdd = (int)(class2Instaces.get(c).size()*noInstance/dataset.size())+1;
			if(toAdd <= 0)
				toAdd = 1;
			Collections.shuffle(class2Instaces.get(c), new Random(100));
			for(int i=0;i<toAdd;i++)
				toReturn.add(class2Instaces.get(c).get(i));
		}

		return toReturn;
	}
}
