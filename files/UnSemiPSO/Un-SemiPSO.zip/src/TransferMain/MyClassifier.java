package TransferMain;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import libsvm.LibSVM;
import net.sf.javaml.classification.BingKNearestNeighbors;
import net.sf.javaml.classification.Classifier;
import net.sf.javaml.classification.KNearestNeighbors;
import net.sf.javaml.classification.bayes.NaiveBayesClassifier;
import net.sf.javaml.classification.evaluation.PerformanceMeasure;
import net.sf.javaml.classification.tree.RandomTree;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.Instance;
import net.sf.javaml.tools.weka.WekaClassifier;
import weka.classifiers.trees.REPTree;

/**
 *
 * @author xuebing
 */
public class MyClassifier {

    //private NaiveBayesClassifier classifier;
    private net.sf.javaml.classification.Classifier classifier;
    private Random random;
    /*
     */

    public MyClassifier(Random random) {
        this.random = random;
    }

    public void ClassifierKNN(int k) {
        System.out.println("Myclassifier:  new KNearestNeighbors("+k+")");
        setClassifier(new KNearestNeighbors(k));
    }

    public void ClassifierBingKNN(int k) {
        System.out.println("Myclassifier:  new -- Bing-- KNearestNeighbors("+k+")");
        setClassifier(new BingKNearestNeighbors(k));
    }

    public void ClassifierNB() {
        setClassifier(new NaiveBayesClassifier(false, true, false));
        System.out.println("Myclassifier:  new NaiveBayesClassifier(false, true, false)");
    }

    public void ClassifierLibSVM() {
        setClassifier(new LibSVM());
        System.out.println("Myclassifier:  new LibSVM()");
    }

    public void ClassifierDT() {
        setClassifier(new WekaClassifier(new REPTree()));
        System.out.println("Myclassifier: new  DT - REPTree()");
    }

    public void ClassifierRT(int noFeatures) {
        setClassifier(new RandomTree(noFeatures, new Random(0)));
        System.out.println("Myclassifier:  new RandomTree(noFeatures, new Random(0))");
    }

    /**
     * @return the classifier
     */
    public Classifier getClassifier() {
        return classifier;
    }

    /**
     * @param classifier the classifier to set
     */
    public void setClassifier(Classifier classifier) {
        this.classifier = classifier;
    }



    public double classify(Dataset training, Dataset testing) {
//        Classifier knn = new KNearestNeighbors(5);//        KNearestNeighbors knn = new KNearestNeighbors(5);
        getClassifier().buildClassifier(training);

        double count =0.0;
        for(Instance instance: testing) {
        	Object prediction = getClassifier().classify(instance);
        	if(prediction.equals(instance.classValue()))
        		count++;
        }

        return count/testing.size();
    }



}
