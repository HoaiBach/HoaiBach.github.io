package TransferMain;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import Problem.Problem;
import Utility.HelpDataset;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;
import net.sf.javaml.core.DenseInstance;
import net.sf.javaml.core.Instance;
import net.sf.javaml.distance.DistanceMeasure;
import net.sf.javaml.distance.EuclideanDistance;

public class FeatureTransfer extends Problem{

	private Dataset src,tarU, tarL;
	private MyClassifier classifier;
	private double sw = 01/3.0, tw = 1/3.0, stw = 1/3.0;
	private boolean unspervised = true;
	private int nFolds = 3;

	public FeatureTransfer(Dataset src, Dataset tarU, Dataset tarL,double threshold, MyClassifier classifier,
			double sw, double tw, boolean unspervised) throws Exception {
		super(threshold);
		this.src = src;
		this.tarU = tarU;
		this.tarL = tarL;
		this.setMaximised(false);
		this.classifier = classifier;
		this.sw  = sw;
		this.tw  = tw;
		if(this.sw + this.tw >1)
			throw new Exception("SW+TW must not be greater than 1!!");
		else
			stw = 1-this.sw - this.tw;
		this.unspervised = unspervised;
	}



	public double fitness(List<Double> position) {
		double[] features = new double[position.size()];
		boolean nonZero = false;
		for(int i=0;i<position.size();i++) {
			if(position.get(i)>this.getThreshold()) {
				features[i] = 1.0;
				nonZero = true;
			}
			else
				features[i] = 0.0;
		}
		if(!nonZero)
			return this.getWorstFitness();

		Dataset newSrc = HelpDataset.removeFeatures(src.copy(), features);
		Dataset newTar = HelpDataset.removeFeatures(tarU.copy(), features);

		double s2sError = 0.0;
		if(sw>0)
			s2sError = classficationError(newSrc); //source accuracy

		double t2tError=0;
		if(tw>0) {
			if(unspervised) {
				//dont use the information from the target label
				t2tError = 1-estimateAccuracy(newSrc, newTar);
			}
			else {
				//use the labeled instances in the target domain
				Dataset newTarL = HelpDataset.removeFeatures(tarL.copy(), features);
				t2tError = 1-this.classifier.classify(newSrc, newTarL);
			}
		}

		double s2tError = 0;
		if(stw>0)
			s2tError = distributionDistance(newSrc, newTar);

		double fitness = this.sw*s2sError + this.tw*t2tError + this.stw*s2tError;

		return fitness;

	}

	/**
	 * Finding the two closes instance in the target is possibly missclassified
	 * by the instance in the src
	 * @param src
	 * @param tar
	 * @return
	 */
	public double estimateAccuracy(Dataset src, Dataset tar) {
		Map<Instance, Instance> t2t = new HashMap<Instance,Instance>();
		Map<Instance, Instance> t2s = new HashMap<Instance,Instance>();
		for(Instance ti: tar) {
			//closest source instance to ti
			DistanceMeasure dm = new EuclideanDistance();
			Set<Instance> cs = src.kNearest(1, ti, dm);
			for(Instance tmp:cs )
				t2s.put(ti, tmp);

			//closest target isntance to ti
			Set<Instance> ct = tar.kNearest(1, ti, dm);
			for(Instance tmp:ct )
				t2t.put(ti, tmp);
		}

		int count = 0;
		//now count the number of case that two target
		//instances can share the same class
		for(int i=0;i<tar.size();i++) {
			Instance ti = tar.get(i);//the current instance
			Instance st = t2s.get(ti);//the closet source instance from the current instance
			Instance ct = t2t.get(ti);//the cloest target instance from the current instance
			Instance sct = t2s.get(ct);//the closet source instance of the cloest targe instance
			//not check label of si and sct
			if(st.classValue().equals(sct.classValue()))
				count++;
		}
		return (count+0.0)/tar.size();
	}

	public double classficationError(Dataset dataset) {
		Dataset[] folds = dataset.folds(nFolds, new Random(100));
		double error = 0;
		for(int i=0;i<folds.length;i++) {
			Dataset training = new DefaultDataset();
			Dataset testing = folds[i];
			for(int j=0;j<folds.length;j++) {
				if(j!=i)
					training.addAll(folds[j]);
			}
			error+= 1-this.classifier.classify(training, testing);
		}
		return error/folds.length;

	}

	public double distributionDistance(Dataset src, Dataset tar) {
		//calculate the distance between 2 distributions
		//using the RBF kernel
		//gamma is automatically selected
		double[][] kxx = pwDistance(src, src); //size n1*n1
		double[][] kyy = pwDistance(tar, tar); //size n2*n2
		double[][] kxy = pwDistance(src, tar); //size n1*n2

		//now find the gamma for kernel
		double median = medianArray(kxy);
		double sigma = Math.sqrt(median/2);

		kxx = expArray(kxx, sigma);
		kyy = expArray(kyy, sigma);
		kxy = expArray(kxy, sigma);

		double sumxx = sumArray(kxx)/(src.size()*src.size());
		double sumyy = sumArray(kyy)/(tar.size()*tar.size());
		double sumxy = sumArray(kxy)/(src.size()*tar.size());

		double distance = Math.sqrt(Math.abs(sumxx+sumyy-2*sumxy));
		return distance;
	}


	public double[] positionToFeatures(List<Double> position) {
		double[] features = new double[position.size()];
		for(int i=0;i<position.size();i++) {
			if(position.get(i)>this.getThreshold())
				features[i] = 1.0;
			else
				features[i] = 0.0;
		}
		return features;
	}

	public int sizeSubset(double[] position) {
		int count =0;
		for(int i=0;i<position.length;i++) {
			if(position[i] == 1)
				count++;
		}
		return count;
	}


	/**
	 * find the median value of all non-zero elements in an array
	 * @param array
	 * @return
	 */
	public double medianArray(double[][] array) {
		List<Double> values = new ArrayList<Double>();
		for(int i=0;i<array.length;i++)
			for(int j=0;j<array[0].length;j++)
				if(array[i][j]!=0) values.add(array[i][j]);
		Collections.sort(values);
		double median = values.get(values.size()/2);
		return median;
	}

	public double sumArray(double[][] array) {
		double sum = 0;
		for(int i=0;i<array.length;i++)
			for(int j=0;j<array[0].length;j++)
				sum += array[i][j];
		return sum;
	}

	public double[][] expArray(double[][] array, double sigma){
		double[][] newArray = new double[array.length][array[0].length];
		for(int i=0;i<array.length;i++)
			for(int j=0; j<array[0].length;j++)
				newArray[i][j] = Math.exp(-1.0/2/(sigma*sigma)*array[i][j]);
		return newArray;
	}

	public double[][] pwDistance(Dataset d1, Dataset d2){
		//calculate pairwise distance
		double[][] distances = new double[d1.size()][d2.size()];

		for(int i=0;i<d1.size();i++)
			for(int j=0;j<d2.size();j++)
				try {
					distances[i][j] = instanceDistance(d1.get(i), d2.get(j));
				} catch (Exception e) {
					e.printStackTrace();
				}

		return distances;
	}

	public double instanceDistance(Instance i1, Instance i2) throws Exception {
		if(i1.noAttributes() != i2.noAttributes())
			throw new Exception("The two instances do not have the same number of attributes!!!");
		double distance = 0;
		int nf = i1.noAttributes();
		for(int i=0;i<nf;i++) {
			distance += Math.pow(i1.get(i)-i2.get(i), 2);
		}
		return distance;
	}

	private void printmatrix(double[][] matrix, PrintStream pt) {
		for(int i=0;i<matrix.length;i++) {
			for(int j=0;j<matrix[0].length;j++)
				pt.print((int)(matrix[i][j]*100+0.5)/100.0+",");
			pt.println();
		}
		pt.println("====================");

	}

	public static double correlationData(Dataset data) throws Exception {
		//first, find the list of instance in the same class
		Map<Object, List<Instance>> class2Instance = new HashMap<Object,List<Instance>>();
		for(Instance ins: data) {
			if(class2Instance.containsKey(ins.classValue())) {
				class2Instance.get(ins.classValue()).add(ins);
			}
			else {
				List<Instance> list = new ArrayList<Instance>();
				list.add(ins);
				class2Instance.put(ins.classValue(), list);
			}
		}

		double interClass = interClass(class2Instance);
		double intraClass = intraClass(class2Instance);
		return interClass-intraClass;
	}

	public static double correlationDataMean(Dataset data) throws Exception {
		Map<Object, List<Instance>> class2Instance = new HashMap<Object,List<Instance>>();
		for(Instance ins: data) {
			if(class2Instance.containsKey(ins.classValue())) {
				class2Instance.get(ins.classValue()).add(ins);
			}
			else {
				List<Instance> list = new ArrayList<Instance>();
				list.add(ins);
				class2Instance.put(ins.classValue(), list);
			}
		}
		Map<Object,Instance> class2Mean = new HashMap<Object,Instance>();
		for(Entry<Object,List<Instance>> entry: class2Instance.entrySet())
			class2Mean.put(entry.getKey(), clusterMean(entry.getValue()));

		double interClassMean = interClassMean(class2Instance, class2Mean);
		double intraClassMean = intraClassMean(class2Instance, class2Mean);
		return interClassMean-intraClassMean;
	}

	public static Instance clusterMean(List<Instance> list) {
		double[] values = new double[list.get(0).noAttributes()];
		for(int i=0;i<values.length;i++)
			for(int j=0;j<list.size();j++)
				values[i] += list.get(j).value(i);
		for(int i=0;i<values.length;i++)
			values[i] = values[i]/list.size();
		Instance instance = new DenseInstance(values);
		return instance;
	}

	public static double intraClassMean(Map<Object,List<Instance>> clusters, Map<Object,Instance> means) throws Exception {
		double distance = 0;
		for(Entry<Object,List<Instance>> entry: clusters.entrySet()) {
			Object c = entry.getKey();
			distance += distanceInstance2List(clusters.get(c), means.get(c));
		}
		return distance/clusters.size();
	}

	public static double intraClass(Map<Object,List<Instance>> clusters) throws Exception {
		double distance = 0;
		for(Entry<Object,List<Instance>> entry: clusters.entrySet()) {
			distance += distance2SameLists(entry.getValue());
		}
		return distance/clusters.size();
	}

	public static double interClassMean(Map<Object,List<Instance>> cluster, Map<Object,Instance> means) throws Exception {
		List<Object> classes = new ArrayList<Object>(cluster.keySet());
		double distance = 0;
		for(int i=0;i<classes.size()-1;i++)
			for(int j=i+1;j<classes.size();j++)
				distance += distanceInstance2List(cluster.get(classes.get(i)), means.get(classes.get(j)));
		return distance/cluster.size();
	}

	public static double interClass(Map<Object,List<Instance>> cluster) throws Exception {
		List<Object> classes = new ArrayList<Object>(cluster.keySet());
		double distance = 0;
		for(int i=0;i<classes.size()-1;i++)
			for(int j=i+1;j<classes.size();j++)
				distance += distance2DifLists(cluster.get(classes.get(i)), cluster.get(classes.get(j)));
		return distance/(classes.size()*(classes.size()-1)/2);
	}

	public static double distance2DifLists(List<Instance> l1, List<Instance> l2) throws Exception {
		double distance =0;
		for(Instance i1: l1)
			for(Instance i2:l2)
				distance += distance2Instance(i1,i2);
		return distance/(l1.size()*l2.size());
	}

	public static double distance2SameLists(List<Instance> l) throws Exception {
		double distance =0;
		for(int i=0;i<l.size()-1;i++)
			for(int j=i+1;j<l.size();j++)
				distance += distance2Instance(l.get(i),l.get(j));
		return distance/(l.size()*(l.size()-1)/2);
	}

	public static double distanceInstance2List(List<Instance> list, Instance ins) throws Exception {
		double distance = 0;
		for(int i=0;i<list.size();i++)
			distance += distance2Instance(list.get(i), ins);
		return distance/list.size();
	}

	public static double distance2Instance(Instance i1, Instance i2) throws Exception {
		if(i1.noAttributes() != i2.noAttributes())
			throw new Exception("Two instances must have the same number of features!");
		int nf = i1.noAttributes();
		double dis = 0;
		for(int i=0;i<nf;i++) {
			dis+= Math.pow(i1.value(i)-i2.value(i), 2);
		}
		return Math.sqrt(dis);
	}
}
