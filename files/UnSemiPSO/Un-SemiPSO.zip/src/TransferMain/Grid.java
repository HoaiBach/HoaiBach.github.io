package TransferMain;

public class Grid {

	public static void main(String[] args) throws Exception {
		for(int swi=0;swi<=8;swi++) {
			int twi = 8-swi;
			double sw = swi/1.0;
			double tw = twi/1.0;
			String[] na = new String[] {"1","1",sw+"",tw+""};
			TransferLearning.main(na);
		}
	}
}
