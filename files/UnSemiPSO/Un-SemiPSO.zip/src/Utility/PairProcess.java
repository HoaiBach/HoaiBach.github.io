package Utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Random;
import java.util.Scanner;

import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;
import net.sf.javaml.core.Instance;
import net.sf.javaml.tools.data.FileHandler;

public class PairProcess {

	public static void main(String[] args) throws IOException {
		String dataset = "Digit";
		String inDir = "/home/nguyenhoai2/Eclipse/Datasets/Transferlearning/"+dataset+"/";
		String outDir = "/home/nguyenhoai2/Eclipse/Datasets/Transferlearning/Pairs/";

		int[] indices = new int[] {1,3,5,7};
		int noFolds = 10;

		String[] variants = {"MNIST","USPS"};

		Scanner sc = new Scanner(new File(variants[0]+"_nf.txt"));
		int nf = Integer.parseInt(sc.nextLine().trim());
		sc.close();

		for(int i = 0;i<variants.length;i++) {
			for(int j=0;j<variants.length;j++) {
				if(i!=j) {
					String folderName = dataset+variants[i]+"-"+variants[j];
					String srcName = variants[i];
					String tarName = variants[j];

					Dataset src = FileHandler.loadDataset(new File(inDir+srcName+"_data.txt"),nf,",");
					Dataset[] folds = src.folds(noFolds, new Random(100));
					Dataset tmpSrc = new DefaultDataset();
					for(int index: indices)
						tmpSrc.addAll(folds[index]);

					Dataset tar = FileHandler.loadDataset(new File(inDir+tarName+"_data.txt"), nf,",");
					folds = tar.folds(noFolds, new Random(100));
					Dataset tmpTarU = new DefaultDataset();
					tmpTarU.addAll(folds[0]);tmpTarU.addAll(folds[2]);
					tmpTarU.addAll(folds[4]);tmpTarU.addAll(folds[6]);
					tmpTarU.addAll(folds[8]);tmpTarU.addAll(folds[9]);
					Dataset tmpTarL = new DefaultDataset();
					tmpTarL.addAll(folds[1]);tmpTarL.addAll(folds[3]);tmpTarL.addAll(folds[5]);tmpTarL.addAll(folds[7]);

					String newDir = outDir+folderName;
					new File(newDir).mkdirs();
					writeFile(tmpSrc,newDir+"/Source");
					writeFile(tmpTarL,newDir+"/TargetL");
					writeFile(tmpTarU,newDir+"/TargetU");
					PrintStream pt = new PrintStream(new File(newDir+"/noFeatures"));
					pt.println(nf);
					pt.close();
				}
			}
		}

	}

	public static void writeFile(Dataset data, String fileName) throws FileNotFoundException {
		File file = new File(fileName);
		PrintStream pt = new PrintStream(file);

		for(Instance instance: data) {
			for(int i=0;i<instance.noAttributes();i++){
				pt.print(instance.value(i)+",");
			}
			pt.println(instance.classValue());
		}
		pt.close();
	}


}
