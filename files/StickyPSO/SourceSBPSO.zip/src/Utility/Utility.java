package Utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Utility {

	public static List<Double> copyList(List<Double> list){
		List<Double> newList = new ArrayList<Double>();
		for(double d: list)
			newList.add(d);
		return newList;
	}
	
    public static double Scale(double src_min, double src_max, double value, double target_min, double target_max) {

        if (src_max == src_min) {
            System.out.println("src_max == src_min ");
            return (1 / 2) * (target_max - target_min) + target_min;
        } else {
            return  (target_max - target_min)*(value -src_min) / (src_max - src_min) + target_min;
        }
    }

//    public static double Averageitera(Swarm s) {
//        double result = 0.0;
//        for (int i = 0; i < s.numberOfParticles(); ++i) {
//            result += s.getParticle(i).getFitness();
//        }
//        return result / s.numberOfParticles();
//    }

    public static double[] AverageRunIterations(double ARI[][]) {
        double results[] = new double[ARI[0].length];
        for (int i = 0; i < ARI[0].length; ++i) {
            for (int r = 0; r < ARI.length; ++r) {
                results[i] += ARI[r][i];
            }
            results[i] = results[i] / ARI.length;
        }
        return results;
    }

// get mean
    public static double mean(double[] array) {
        double sum = 0.0;  // sum of all the elements
        if (array.length == 0) {
            System.out.println("This array with no elements in it !!!!");
        } else {
            for (int i = 0; i < array.length; i++) {
                sum += array[i];
            }
        }
        return sum / array.length;
    }//end method mean

    // get mean and Standard Deviation
    public static double[] Mean_STD(double BestFitness[]) {
        double Arrays[] = BestFitness;
        double M_STD[] = new double[2];
        double sum = 0.0;
        for (int i = 0; i < BestFitness.length; ++i) {
            sum += BestFitness[i];
        }
        M_STD[0] = sum / (double) BestFitness.length;

        M_STD[1] = calculateSTD(Arrays, M_STD[0]);
        return M_STD;
    }

    public static double calculateSTD(double Arrays[], double Mean) {
        double allSquare = 0.0;
        for (Double Array : Arrays) {
            allSquare += (Array - Mean) * (Array - Mean);
        }
        double denominator = Arrays.length;
        return Math.sqrt(allSquare / denominator);
    }

    public static int ModEuclidean(int D, int d) {
        int r = D % d;
        if (r < 0) {
            if (d > 0) {
                r = r + d;
            } else {
                r = r - d;
            }
        }
        return r;
    }

    public static double[][] featureranking(double distance1[], double distance2[]) {
        double[] d3 = new double[distance1.length];
        double[][] FR = new double[2][distance1.length];
        double tem;

        for (int i = distance1.length - 1; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                if (distance1[j] < distance1[j + 1]) {
                    tem = distance1[j];
                    distance1[j] = distance1[j + 1];
                    distance1[j + 1] = tem;
                }

            }
        }

        for (int i = 0; i < distance2.length; i++) {
            for (int j = 0; j < distance1.length; j++) {
                if (distance1[i] == distance2[j]) {
                    d3[i] = j + 1;
                    break;
                }
            }
        }
        FR[1] = distance1;
        FR[2] = d3;
        return FR;
    }

    // prodce t different int numbers within 0-n
    public static int[] fn(int t, int n) {
        Set<Integer> set = new HashSet<Integer>();
        int length = 0;
        while ((length = set.size()) < t) {
            int raNum = (int) (RandomSeed.Create().nextDouble() * n);
            set.add(raNum);
        }
        int[] array = new int[t];
        Integer[] intArray = new Integer[t];
        intArray = set.toArray(intArray);
        for (int i = 0; i < t; i++) {
            array[i] = intArray[i].intValue();
//            System.out.print(array[i]+ "  ");
//            System.out.println("  ");

        }
        return array;
    }

    /*Divid the datasets, select test from two sides,
    select the first fold, last fold, the third fold, and the third last fold as test set; 0 9 2,   0 9 2 7 4,  0 9 2 7 4 5;
     */
    public static int[] divData(int numTest, int numTrain) {
        int[] select = new int[numTest];
        int tem1 = 0;
        for (int i = 0; i < numTest; i = i + 2) {
            select[tem1] = i;
            if (tem1 < numTest - 1) {
                select[tem1 + 1] = numTrain + numTest - 1 - i;
                tem1 = tem1 + 2;
            } else {
                break;
            }
        }
        return select;
    }
    
    public static double average(double[] values){
    	double sum = 0;
    	for(double value: values)
    		sum+= value;
    	return sum/values.length;
    }
	
    public static double std(double[] values){
    	double ave = average(values);
    	double sum = 0;
    	for(double value: values)
    		sum += (value-ave)*(value-ave);
    	return Math.sqrt(sum/values.length);
    }
    
	public static double distanceBetweenBinaryPositions(List<Double> p1, List<Double> p2){
		double distance = 0;
		
		if(p1.size() != p2.size()){
			try {
				throw new Exception("Length of two positions are not equal!!!!");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		for(int i=0;i<p1.size();i++){
			distance += Math.abs(p1.get(i) - p2.get(i));
		}
		
		return distance;
	}
	
	public static double[] quickSort(double[] values){
		double[] indices = new double[values.length];
		for(int i=0;i<values.length;i++){
			indices[i] = i+1;
		}
		quickSort(values,indices,0,values.length-1);
		//		double[] ranks = new double[values.length];
		//		for(int i=0;i<indices.length;i++){
		//			ranks[(int)indices[i]-1] = i+1;
		//		}
		return indices;
	}

	public static void quickSort(double[] values, double[] indices,int left, int right){
		if(left<right){
			int partitionIndex = partition(values,indices,left,right);
			quickSort(values,indices,left,partitionIndex-1);
			quickSort(values,indices,partitionIndex+1,right);
		}
	}

	public static int partition(double[] values,double[] indices, int left, int right){
		int pivotIndex = (left+right)/2;
		double pivotValue = values[pivotIndex];
		swap(values,indices,pivotIndex,right);
		int storeIndex = left;
		for(int i=left;i<=right-1;i++){
			if(values[i] > pivotValue){
				swap(values,indices,i,storeIndex);
				storeIndex++;
			}
		}
		swap(values,indices,storeIndex,right);
		return storeIndex;
	}

	public static void swap(double[] values, double[] indices, int p1, int p2){
		double tmp = values[p1];
		double tmpIndex = indices[p1];
		values[p1] = values[p2];
		indices[p1] = indices[p2];
		values[p2] = tmp;
		indices[p2] = tmpIndex;
	}
	
	public static String replaceWithCapital(String s){
		String tmp = s.substring(0, 1);
		tmp = tmp.toUpperCase();
		s = tmp+s.substring(1);
		return s;
	}
	public static double rowTwo(double d){
		return  ((int)(d*100+0.5))/100.0;
	}
	
	/**
	 * fine the top n elements of the list
	 * @param list
	 * @param n
	 * @param minimize
	 * @return
	 */
	public static List<Double> findTopElements(List<Double> list, int n, boolean minimize){
		List<Double> top = new ArrayList<Double>();
		List<Double> tmp = new ArrayList<Double>(list);
		Collections.sort(tmp);
		if(minimize){
			for(int i=1;i<=n;i++)
				top.add(tmp.get(i-1));
		}
		else{
			for(int i=tmp.size()-1; i>= tmp.size()-n;i--)
				top.add(tmp.get(i));
		}
		return top;
	}
}
