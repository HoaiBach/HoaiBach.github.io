package PSO.Particle;

import java.util.ArrayList;
import java.util.Random;

import Core.Initializer;
import Problem.Problem;
import Utility.RandomSeed;

/**
 * Standard continuous PSO
 * @author nguyenhoai2
 *
 */
public class StandardParticle extends Particle{
	
	protected Random r1 = RandomSeed.Create();
	protected Random r2 = RandomSeed.Create();
	
	protected double maxPosition, minPosition;
	protected double maxVelocity, minVelocity;
	
	private double c1= 1.49618, c2=1.49618;
	private double w = 0.7298;
	
	public StandardParticle(Problem problem,int length) {
		super(false,problem, length);
		
		this.maxVelocity=0.2;
		this.minVelocity=-0.2;
		this.maxPosition=1.0;
		this.minPosition=0.0;
	}

	public void initialize() {
		Initializer.initializeOpposite(this);
		//it is better to start with 0 velocity
		this.velocity = new ArrayList<Double>();
		for(int i=0;i<this.getLength();i++){
			this.velocity.add(0.);
		}
	}
	
	public void updateVelocity() {
		for (int i = 0; i < this.length; ++i) {
			double v_i = w*velocity.get(i);
			v_i+= c1*r1.nextDouble()*(this.getPbestPosition().get(i) - this.getPosition().get(i));
			v_i+= c2*r2.nextDouble()*(this.getGbestPosition().get(i) - this.getPosition().get(i));
			//add to modify the velocity limit
			if(v_i > this.maxVelocity){
				v_i = this.maxVelocity;
			}
			else if(v_i < this.minVelocity){
				v_i = this.minVelocity;
			}
			velocity.set(i, v_i);
		}
	}

	public void updatePosition() {
		for (int i = 0; i < this.length; ++i) {
			double pos_i = this.getPosition().get(i);
			double new_pos_i = pos_i+this.velocity.get(i);
			if(new_pos_i > this.maxPosition)
				new_pos_i = this.maxPosition;
			else if (new_pos_i < this.minPosition)
				new_pos_i = this.minPosition;
			this.getPosition().set(i, new_pos_i);
			
		}
	}
}
