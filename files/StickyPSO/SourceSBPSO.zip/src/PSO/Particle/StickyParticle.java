package PSO.Particle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Core.Initializer;
import Problem.Problem;
import Utility.RandomSeed;

public abstract class StickyParticle extends Particle {

	//initialize the value of ic, ip and ig
	protected double is = -1,ip = -1,ig = -1;
	protected List<Double> stk,probFlip;
	protected Random random = RandomSeed.Create();
	protected double ustkS;
	protected double pgRate;
	
	public StickyParticle(Problem problem, int length,
			double is, double pgRate, double ustkS) {
		super(true, problem, length);
		this.is = is;
		// ip = pgRate*ig;
		this.pgRate = pgRate;
		this.ig = (1.0-this.is)/(pgRate+1);
		this.ip = pgRate*this.ig;
		this.ustkS = ustkS;
	}
	
	public void initialize() {
		//initialize position
		Initializer.initializeOpposite(this);
		
		stk = new ArrayList<Double>();
		probFlip = new ArrayList<Double>();
		//beginning, stk = 1, probFleip = 0
		for(int i=0;i<this.getLength();i++){
			stk.add(1.0);
			probFlip.add(0.0);
		}
	}

	/**
	 * Update the position
	 */
	public void updatePosition() {
		for(int i=0; i<this.length;i++){
			double prob = probFlip.get(i);
			double rdValue = random.nextDouble();
			if(rdValue < prob){
				this.position.set(i, 1.0-this.position.get(i));
				//reset stk to 1
				double maxStk = 1.0;
//				if(this instanceof DynamicStickyParticle)
//					maxStk = Math.min(1/(pgRate+1), pgRate/(pgRate+1));
				stk.set(i, maxStk);
			}
			else{
				//if not flipping, reduce the stk
				double newStk = Math.max(0.0, stk.get(i)-1.0/ustkS);
				stk.set(i,newStk);
			}
		}
	}

	public double getIs() {
		return is;
	}

	public double getIp() {
		return ip;
	}

	public double getIg() {
		return ig;
	}
	
	public double getUstkS(){
		return this.ustkS;
	}

}
