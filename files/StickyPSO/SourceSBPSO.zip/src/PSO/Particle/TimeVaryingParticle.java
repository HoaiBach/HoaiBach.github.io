package PSO.Particle;

import java.util.ArrayList;
import java.util.Random;

import Core.Initializer;
import Problem.Problem;
import Utility.RandomSeed;

public class TimeVaryingParticle extends Particle{

	private double phiMax = 5.0,phiMin=1.0;
	private int maxIterations;
	private double c1 = 2.0, c2=2.0;
	private int currentIteration = 0;
	private double w = 1.0;
	
	protected Random r1 = RandomSeed.Create();
	protected Random r2 = RandomSeed.Create();
	private Random sigmoidRandom = RandomSeed.Create();
	
	protected double maxPosition, minPosition;
	protected double maxVelocity, minVelocity;
	
	public TimeVaryingParticle(Problem problem, int length, int maxIterations) {
		super(true, problem, length);
		this.maxIterations = maxIterations;
		
		this.maxVelocity = 2.6655*Math.log(length)-4.1;
		this.minVelocity=-this.maxVelocity;
		this.maxPosition=1.0;
		this.minPosition = 0.0;
	}

	public void updateVelocity() {
		for (int i = 0; i < this.length; ++i) {
			double v_i = w*velocity.get(i);
			v_i+= c1*r1.nextDouble()*(this.getPbestPosition().get(i) - this.getPosition().get(i));
			v_i+= c2*r2.nextDouble()*(this.getGbestPosition().get(i) - this.getPosition().get(i));
			//add to modify the velocity limit
			if(v_i > this.maxVelocity){
				v_i = this.maxVelocity;
			}
			else if(v_i < this.minVelocity){
				v_i = this.minVelocity;
			}
			velocity.set(i, v_i);
		}
	}

	public void initialize() {
		Initializer.initializeOpposite(this);
		this.velocity = new ArrayList<Double>();
		for(int i=0;i<this.getLength();i++){
			this.velocity.add(0.);
		}
	}

	public void updatePosition() {
		double phi = phiMax-((phiMax-phiMin)*currentIteration)/maxIterations;
		
		for(int i=0; i<this.length;i++){
			double p_i = 0.0;
			double prob = 1/(1+Math.exp(-this.velocity.get(i)/phi));
			
			if (sigmoidRandom.nextDouble() < prob) {
				p_i = 1.0;
			} else {
				p_i = 0.0;
			}
			
			this.getPosition().set(i, p_i);
		}
		
		currentIteration++;
	}

}
