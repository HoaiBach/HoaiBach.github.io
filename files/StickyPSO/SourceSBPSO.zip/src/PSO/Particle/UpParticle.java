package PSO.Particle;

import java.util.ArrayList;
import java.util.Random;

import Core.Initializer;
import Problem.Problem;
import Utility.RandomSeed;

public class UpParticle extends Particle {
	
		private double upper = 1, lower = 0.4;
		private double control = 0.9;
		private int currentIteration=0;
		private int maxIteration;
		
		protected Random r1 = RandomSeed.Create();
		protected Random r2 = RandomSeed.Create();
		
		protected double maxPosition, minPosition;
		protected double maxVelocity, minVelocity;
		
		private double c1=2.0, c2=2.0;
		private Random sigmoidRandom = RandomSeed.Create();
		
		public UpParticle(Problem problem,int length, int maxIteration) {
			super(true,problem, length);
			this.maxIteration = maxIteration;
			
			this.maxVelocity=6.0;
			this.minVelocity=-6.0;
			this.maxPosition=1.0;
			this.minPosition=0.0;
		}

		public void initialize() {
			Initializer.initializeOpposite(this);
			this.velocity = new ArrayList<Double>();
			for(int i=0;i<this.getLength();i++){
				this.velocity.add(0.);
			}
		}
		
		public void updateVelocity() {
			
			double inertia = lower+ currentIteration*(upper-lower)/(maxIteration*control);
		
			for (int i = 0; i < this.length; ++i) {
				double v_i = inertia*velocity.get(i);
				v_i+= c1*r1.nextDouble()*(this.getPbestPosition().get(i) - this.getPosition().get(i));
				v_i+= c2*r2.nextDouble()*(this.getGbestPosition().get(i) - this.getPosition().get(i));
				//add to modify the velocity limit
				if(v_i > this.maxVelocity){
					v_i = this.maxVelocity;
				}
				else if(v_i < this.minVelocity){
					v_i = this.minVelocity;
				}
				velocity.set(i, v_i);
			}
		}

		public void updatePosition() {
			for (int i = 0; i < this.length; ++i) {
				double p_i = 0.0;
				double sig = 1 / (1 + Math.exp(-this.velocity.get(i)));

				if (sigmoidRandom.nextDouble() < sig) {
					p_i = 1.0;
				} else {
					p_i = 0.0;
				}
				this.getPosition().set(i, p_i);
			}
			currentIteration++;
		}
}
