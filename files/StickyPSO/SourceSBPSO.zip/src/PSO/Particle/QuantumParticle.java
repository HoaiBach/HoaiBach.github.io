package PSO.Particle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Core.Initializer;
import Problem.Problem;
import Utility.RandomSeed;

public class QuantumParticle extends Particle{

	private double thetaMax = 0.05*Math.PI;
	private double thetaMin = 0.01*Math.PI;
	private double theta;
	private List<Double> alphas,betas;
	private int currentIteration = 0;
	private int maxIterations;
	protected Random random = RandomSeed.Create();
	
	public QuantumParticle(boolean isBinary, Problem problem, int length, 
			int maxIterations) {
		super(isBinary, problem, length);
		this.maxIterations = maxIterations;
	}

	//update alpha and beta
	public void updateVelocity() {
		double gammaPbest = this.getProblem().isBetter(this.pFitness, this.fitness)? 1.0:0.0;
		double gammaGbest = this.getProblem().isBetter(this.gFitness, this.fitness)? 1.0:0.0;
		theta = thetaMax - ((thetaMax-thetaMin)*currentIteration)/maxIterations;
		
		for(int i=0;i<this.length;i++){
			double deltaTheta = theta*(
					gammaPbest*(this.getPbestPosition().get(i)-this.getPosition().get(i)) +
					gammaGbest*(this.getGbestPosition().get(i)-this.getPosition().get(i)));
			
			double oldAlpha = this.alphas.get(i);
			double oldBeta = this.betas.get(i);
			double newAlpha = Math.cos(deltaTheta)*oldAlpha-Math.sin(deltaTheta)*oldBeta;
			double newBeta = Math.sin(deltaTheta)*oldAlpha+Math.cos(deltaTheta)*oldBeta;
			
			this.alphas.set(i, newAlpha);
			this.betas.set(i, newBeta);
		}
		
		//increase counter
		this.currentIteration++;
	}

	public void initialize() {
		Initializer.initializeOpposite(this);
		
		this.theta = thetaMax;
		alphas = new ArrayList<Double>();
		betas  = new ArrayList<Double>();
		for(int i=0;i<this.length;i++){
			alphas.add(1.0/Math.sqrt(2));
			betas.add(1.0/Math.sqrt(2));
		}
	}

	//update the new position based on beta
	public void updatePosition() {
		for(int i=0;i<this.length;i++){
			double prob = this.betas.get(i)*this.betas.get(i);
			double rdValue = random.nextDouble();
			if(rdValue<prob)
				this.position.set(i, 1.0);
			else
				this.position.set(i, 0.0);
		}
	}

}
