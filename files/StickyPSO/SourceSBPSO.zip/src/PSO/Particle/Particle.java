package PSO.Particle;

import java.util.List;
import java.util.Random;

import Core.Individual;
import Problem.Problem;
import Utility.RandomSeed;
import Utility.Utility;

public abstract class Particle extends Individual {

	protected List<Double> pbest;
	protected double pFitness;
	protected List<Double> gbest;
	protected double gFitness;
	
	protected List<Double> velocity;
	
	public Particle(boolean isBinary, Problem problem,
			int length) {
		super(isBinary, problem, length);
		this.setPbestFitness(problem.getWorstFitness());
		this.setGbestFitness(problem.getWorstFitness());
	}
	
	public abstract void updateVelocity();
	public abstract void initialize();
	public abstract void updatePosition();

	public List<Double> getPbestPosition() {
		return pbest;
	}

	public void setPbestPosition(List<Double> pbest) {
		this.pbest = Utility.copyList(pbest);
	}

	public double getPbestFitness() {
		return pFitness;
	}

	public void setPbestFitness(double pFitness) {
		this.pFitness = pFitness;
	}

	public double getGbestFitness() {
		return gFitness;
	}

	public void setGbestFitness(double gFitness) {
		this.gFitness = gFitness;
	}

	public List<Double> getGbestPosition() {
		return gbest;
	}

	public void setGbestPosition(List<Double> gbest) {
		this.gbest = Utility.copyList(gbest);
	}

	public List<Double> getVelocity() {
		return velocity;
	}

	public void setVelocity(List<Double> velocity) {
		this.velocity = Utility.copyList(velocity);
	}

}
