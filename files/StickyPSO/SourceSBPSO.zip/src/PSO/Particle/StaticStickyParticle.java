package PSO.Particle;

import java.util.Arrays;

import Problem.Problem;

public class StaticStickyParticle extends StickyParticle{

	public StaticStickyParticle(Problem problem, int length, 
			double is, double pgRate, double ustkS) {
		super(problem, length, is, pgRate, ustkS);
		updateParameter(is, pgRate, ustkS);
	}

	/**
	 * update the flipping probability
	 */
	public void updateVelocity() {
		//double[] temp = new double[this.length];
		for(int i=0; i< this.getLength();i++){
			double prob = is*(1-stk.get(i));
			prob += ip*Math.abs(this.pbest.get(i)-this.getPosition().get(i));
			prob += ig*Math.abs(this.gbest.get(i)-this.getPosition().get(i));
			probFlip.set(i, prob);
			//temp[i] = prob;
		}
//		System.out.println(Arrays.toString(temp));
	}
	
	public void updateParameter(double is, double pgRate, double ustkS){
		this.is = is;
		this.ustkS = ustkS;
		this.pgRate = pgRate;
		this.ig = (1.0-this.is)/(pgRate+1);
		this.ip = pgRate*this.ig;
	}
	
	
	public double getIs(){
		return is;
	}
	
	
	public double getPgRate(){
		return pgRate;
	}
	
	
	public double getUstkS(){
		return this.ustkS;
	}
}
