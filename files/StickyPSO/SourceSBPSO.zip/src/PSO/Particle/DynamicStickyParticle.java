package PSO.Particle;

import Problem.Problem;

public class DynamicStickyParticle extends StickyParticle{

	private double isL, isU, ustkL, ustkU;
	private double currentIteration = 0;
	private double maxIteration;
	
	public DynamicStickyParticle(Problem problem, int length, 
			double isL, double isU, double ustkL, double ustkU,
			double pgRate, int maxIteration) {
		super(problem, length, isU, pgRate, ustkL);
		this.maxIteration = maxIteration;
		updateParameter(isL, isU, pgRate, ustkL, ustkU);
	}
	
	public void updateParameter(
			double isL, double isU, double pgRate,
			double ustkL, double ustkU){
		this.isL = isL;
		this.isU = isU;
		this.pgRate = pgRate;
		this.ustkL = ustkL;
		this.ustkU = ustkU;
		
		this.is = this.isU;
		this.ustkS = this.ustkL;
	}

	/**
	 * First update the flipping probability, 
	 * then update the parameter
	 */
	public void updateVelocity() {
		for(int i=0; i< this.getLength();i++){
			double prob = is*(1-stk.get(i));
			prob += ip*Math.abs(this.pbest.get(i)-this.getPosition().get(i));
			prob += ig*Math.abs(this.gbest.get(i)-this.getPosition().get(i));
			probFlip.set(i, prob);
		}
		
		currentIteration++;
		is = isU-(isU-isL)*currentIteration/maxIteration;
		ig  = (1.0-is)/(pgRate+1);
		ip = ig*pgRate;
		ustkS = ustkL+(ustkU-ustkL)*currentIteration/(maxIteration);
	}
	
	public double getIsLow(){
		return this.isL;
	}
	
	public double getIsUp(){
		return this.isU;
	}
	
	public double getUstkU(){
		return this.ustkU;
	}
	
	public double getUstkL(){
		return this.ustkL;
	}
	
	public double getPgRate(){
		return this.pgRate;
	}
}
