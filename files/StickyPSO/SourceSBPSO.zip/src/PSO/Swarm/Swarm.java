package PSO.Swarm;

import java.util.ArrayList;
import java.util.List;

import PSO.Particle.DynamicStickyParticle;
import PSO.Particle.Particle;
import PSO.Particle.QuantumParticle;
import PSO.Particle.StandardParticle;
import PSO.Particle.StaticStickyParticle;
import PSO.Particle.TimeVaryingParticle;
import PSO.Particle.UpParticle;
import PSO.Topology.Topology;
import Problem.Problem;

public class Swarm {
	protected Problem problem;
	protected Topology topology;
	protected List<Particle> swarm;
	protected int size, length;
	protected double minPosition, maxPosition, minVelocity, maxVelocity;

	protected int maxIteration;
	protected ParticleType type;

	//record in case it needs
	//	public List<List<List<Double>>> records = new ArrayList<List<List<Double>>>();

	public enum ParticleType{
		Standard,StaticSticky, DynamicSticky, Up, Quantum, TimeVarying;
	}

	public Swarm(int length,ParticleType type,
			int size, Topology topology,
			int maxIteration, Problem problem){
		this.length = length;
		this.type = type;
		this.maxIteration = maxIteration;
		this.topology = topology;
		this.size = size;
		this.problem = problem;
	}

	public void initialize(){
		swarm = new ArrayList<Particle>();
		for(int i =0; i<this.size;i++){
			//initialize the particle
			Particle particle = null;
			switch (type) {

			case StaticSticky:
				double is =4.0/this.length;
				int ustkS =8*this.maxIteration/100;
				double pgRate = 2.0;
				//				double is,pgRate=1.0,ustkS;
				//				if(this.length <= 200){
				//					is = 10.0/this.length;
				//					ustkS = this.length/20*unit;
				//				}
				//				else{
				//					is = 10.0/this.length;
				//					ustkS = this.length/20*unit;
				//				}
				//				if(ustkS <= unit )
				//					ustkS = unit;
				//				double is = 0.115397;
				//				double pgRate = 1.0;
				//				double ustkS = 40;
				particle = new StaticStickyParticle(problem, length, 
						is, pgRate, ustkS);
				break;

			case DynamicSticky:
				pgRate = 2.0;
				double isL = 0.0/this.length,isU = 10.0/this.length;
				double ustkL = this.maxIteration/100.0, ustkU= 10*this.maxIteration/100.0;
				//				double isL,isU,ustkL,ustkU;
				//
				//				if(this.length <= 200 ){
				//					isL=1.0/this.length;isU= 10.0/this.length;
				//					ustkL = unit;ustkU=this.length/20*unit;
				//				}
				//				else{
				//					isL=1.0/this.length;isU= 10.0/this.length;
				//					ustkL = unit;ustkU=this.length/20*unit;
				//				}	
				//				if(ustkU <= unit)
				//					ustkU = unit;
				//				
				//				double isU = 0.115397, isL = 0.01;
				//				double ustkU = 40, ustkL = 5;
				particle = new DynamicStickyParticle(problem, length, 
						isL, isU, ustkL, ustkU, pgRate, maxIteration);
				break;

			case Up:
				particle = new UpParticle(problem, length, maxIteration);
				break;

			case Quantum:
				particle = new QuantumParticle(true, problem, length, maxIteration);
				break;

			case TimeVarying:
				particle = new TimeVaryingParticle(problem, length,maxIteration);
				break;
				
			case Standard:
				particle = new StandardParticle(problem, length);
				break;

			default:
				break;
			}

			particle.initialize();
			swarm.add(particle);
		}
	}

	public void iterate(){

		//evalute and update pbset
		for(int i=0;i<size;i++){
			Particle particle = swarm.get(i);

			double newFitness = problem.fitness(particle.getPosition());
			particle.setFitness(newFitness);

			//if the new fitness is better, update the pbest
			if(problem.isBetter(newFitness, particle.getPbestFitness())){
				particle.setPbestFitness(newFitness);
				particle.setPbestPosition(particle.getPosition());
			}
		}

		//for recording
		//		records.add(toRecord);

		//now update the global best via topology
		this.topology.share(this);

		//now update the veolocity and position of particles
		for(int i=0;i<size;i++){
			Particle particle = swarm.get(i);
			particle.updateVelocity();
			particle.updatePosition();
		}
	}

	public List<Particle> getPopulation(){
		return swarm;
	}

	public Problem getProblem(){
		return problem;
	}

	public void setMaxVelocity(double maxV) {
		this.maxVelocity = maxV;
	}

	public void setMinVelocity(double minV){
		this.minVelocity = minV;
	}

	public void setMaxPosition(double maxP){
		this.maxPosition = maxP;
	}

	public void setMinPosition(double minP){
		this.minPosition = minP;
	}

}
