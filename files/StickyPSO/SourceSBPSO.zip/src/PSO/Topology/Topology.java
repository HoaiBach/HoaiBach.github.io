package PSO.Topology;

import PSO.Swarm.Swarm;

public abstract class Topology {
	 public abstract void share(Swarm S);
}
