package PSO.Topology;

import java.util.List;

import PSO.Particle.Particle;
import PSO.Swarm.Swarm;
import Utility.Utility;


public final class TopologyRing extends Topology {

    private int neighbors = 2;

    /**
     *
     * @param n
     */
    public TopologyRing(int n) {
        this.neighbors = n;
        System.out.println("Topology topology = new TopologyRing(n):  n=" + n);
    }

    /**
     *
     * @param s
     */
    public void share(Swarm s) {

    	List<Particle> pop = s.getPopulation();
    	
        for (int i = 0; i < pop.size(); ++i) {
            Particle particle = pop.get(i);

            //Now find the best neighbour
            Particle best_neighbor = null;
            double best_fitness = s.getProblem().getWorstFitness();
            //including itself
            for (int j = -(neighbors+1) / 2; j <= neighbors / 2; ++j) {
                int neigherID = Utility.ModEuclidean(i + j, pop.size());
                
                if (s.getProblem().isBetter(pop.get(neigherID).getPbestFitness(), best_fitness)) {
                    best_neighbor = pop.get(neigherID);
                    best_fitness = best_neighbor.getPbestFitness();
                }
            }

            particle.setGbestPosition(best_neighbor.getPbestPosition());
            particle.setGbestFitness(best_fitness);
        }
    }

}
