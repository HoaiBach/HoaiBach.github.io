package PSO.Topology;

import java.util.List;

import PSO.Particle.Particle;
import PSO.Swarm.Swarm;

public class TopologyStar extends Topology {

    public void share(Swarm s) {
        
        List<Particle> pop = s.getPopulation();

        Particle bestParticle = null;
        double bestFitness = s.getProblem().getWorstFitness();
        
        for(Particle particle: pop){
        	if(s.getProblem().isBetter(particle.getPbestFitness(), bestFitness)){
        		bestParticle = particle;
        		bestFitness = particle.getPbestFitness();
        	}
        }
        
        for(Particle particle: pop){
        	particle.setGbestPosition(bestParticle.getPbestPosition());
        	particle.setGbestFitness(bestFitness);
        }

    }
}
