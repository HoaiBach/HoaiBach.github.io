package Core;

import java.util.List;

import Problem.Problem;
import Utility.Utility;

public abstract class Individual {
	protected boolean isBinary; 
	
	protected double fitness;
	protected List<Double> position;
	protected Problem problem;
	protected int length;

	public Individual(boolean isBinary, Problem problem, int length){
		this.isBinary = isBinary;
		this.setProblem(problem);
		this.length = length;
	}
	
	public boolean getIsBinary(){
		return isBinary;
	}

	public double getFitness() {
		return fitness;
	}

	public void setFitness(double fitness) {
		this.fitness = fitness;
	}

	public List<Double> getPosition() {
		return position;
	}

	public void setPosition(List<Double> position) {
		this.position = Utility.copyList(position);
	}
	
	public abstract void updatePosition();

	public Problem getProblem() {
		return problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}
}
