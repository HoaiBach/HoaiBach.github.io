package Core;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Problem.Problem;

public class Initializer {

	private static Random random;
	private static Problem problem;

	/**
	 * Initialize according to the run index
	 * @param run
	 */
	public Initializer(Random random, Problem problem){
		Initializer.random = random;
		Initializer.problem = problem;
	}

	public static void initializeRandom(Individual ind){
		if(random == null){
			try {
				throw new Exception("Random is not initialized!");
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}

		}
		int length = ind.getLength();

		List<Double> tempPos = new ArrayList<Double>();
		for(int i=0; i<length;i++){
			double value = random.nextDouble();

			//if binary, convert to binary position
			if(ind.getIsBinary()){
				value = value > ind.getProblem().getThreshold()? 1.0:0.0;
			}

			tempPos.add(value);
		}

		ind.setPosition(tempPos);
		ind.setFitness(problem.fitness(tempPos));
	}

	public static void initializeOpposite(Individual ind){
		if(random == null){
			try {
				throw new Exception("Random is not initialized!");
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}

		}
		int length = ind.getLength();

		List<Double> p1 = new ArrayList<Double>();
		List<Double> p2 = new ArrayList<Double>();
		List<Double> position;
		//create two oposite position
		for(int i= 0;i<length;i++){
			double entry = random.nextDouble();
			random.nextDouble();
			//crete position entry
			p1.add(entry);
			//Note that this kind of opposite is only right
			//if the threshold is setting to 0.5. if threshold
			//is 0.7, for example then both 0.6 and 0.4
			//do not represent selected features.
			double tmp = problem.getThreshold()*2-entry;
			if(tmp > 1.0)
				tmp = 1.0;
			else if(tmp< 0.0)
				tmp = 0.0;
			p2.add(tmp);
		}

		//pick the one with better fitness
		//for the initial position of the particle
		double f1 = problem.fitness(p1);
		double f2 = problem.fitness(p2);
		position = problem.isBetter(f1, f2)? p1:p2;
		double fitness = problem.isBetter(f1, f2)? f1:f2;

		if(ind.getIsBinary()){
			for(int i=0;i<length;i++){
				double bp = position.get(i) > problem.getThreshold()? 1:0;
				position.set(i, bp);
			}
		}

		ind.setPosition(position);
		ind.setFitness(fitness);
	}

}
