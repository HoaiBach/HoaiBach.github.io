package Optimization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import Utility.Utility;

public class ExtractOptimizeDynamicIs {


	public static void main(String[] args) throws FileNotFoundException{

		printWithSetting(null);System.exit(0);

		String[] datasets = new String[]{"weing1","weish15", "gk01","gk05",
				"ISCI1000","SCI500"};

		String dir = "FullResults/OptimizeDynamicKsIs";
		int noRuns = 10;
		int isSize = 11;

		double[] isValues = new double[]{0,1,2,3,4,5,6,7,8,9,10};
		
		Set<ParaDynamicIs> topSettings = new HashSet<ParaDynamicIs>();

		PrintStream pt = new PrintStream(new File("ProcessResults/OptimizeDynamicKsIs/ranking.txt"));
		PrintStream stat = new PrintStream(new File("ProcessResults/OptimizeDynamicKsIs/stat.txt"));
		for(String dataset: datasets){
			PrintStream outdata = new PrintStream(new File("ProcessResults/OptimizeDynamicKsIs/Draw/Data/"+dataset+".txt"));
			outdata.println("isL,isU,profit");
			pt.println(dataset.toUpperCase());
			stat.println(dataset.toUpperCase());
			Map<ParaDynamicIs,Record> results = new HashMap<ParaDynamicIs,Record>();
			for(int isLowIndex = 0; isLowIndex<isSize; isLowIndex++)
				for(int isUpIndex = isLowIndex; isUpIndex < isSize; isUpIndex++)
					{
						//1st isL - ParaDynamic.isUpIndex, isUp-ParaDynamic.usLowIndex,
						ParaDynamicIs par = new ParaDynamicIs(isLowIndex,isUpIndex);

						double[] records = new double[noRuns];
						for(int run = 1;run <= noRuns;run++){
							File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+isLowIndex+"_"+isUpIndex+".txt");
							Scanner sc = new Scanner(file);
							while(sc.hasNext()){
								String line = sc.nextLine();
								if(line.startsWith("Optimal"))
									break;
								//								if(line.contains("Iteration 400:"))
								//									break;
							}
							String line = sc.nextLine();
							double profit = Double.parseDouble(line.split(",")[0].trim());
							//							double profit = Double.parseDouble(line.split(":")[1].trim());

							records[run-1] = profit;
							sc.close();

							//1st
							outdata.println(isValues[par.isLowIndex]
									+","+isValues[par.isUpIndex]
													+","+profit);
						}
						double ave = Utility.average(records);
						double std = Utility.std(records);
						Record record = new Record(ave,std);

						results.put(par, record);
					}

			Map<ParaDynamicIs,Record> sorted = results.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
							(oldValue, newValue) -> oldValue, LinkedHashMap::new));

			List<ParaDynamicIs> pars = printTop(pt,sorted);
			topSettings.addAll(pars);
			
			Map<Integer,Integer> isLowCount = new HashMap<Integer,Integer>();
			Map<Integer,Integer> isUpCount = new HashMap<Integer,Integer>();
			for(ParaDynamicIs par: pars){
				updateMap(isLowCount,par.isLowIndex);
				updateMap(isUpCount,par.isUpIndex);
			}
			stat.println("=====isLow======");
			for(Entry<Integer,Integer> entry: isLowCount.entrySet()){
				stat.println(isValues[entry.getKey()]+", "+entry.getValue());
			}
			stat.println("=====isUp======");
			for(Entry<Integer,Integer> entry: isUpCount.entrySet()){
				stat.println(isValues[entry.getKey()]+", "+entry.getValue());
			}

			//			int count =0;
			//			int max = sorted.size();
			pt.println("*****************************************************************");
			stat.println("*****************************************************************");
		}
		pt.close();
		stat.close();
		
		printWithSetting(topSettings);
	}

	public static void updateMap(Map<Integer,Integer> map, Integer key){
		if(map.containsKey(key))
			map.put(key, map.get(key)+1);
		else
			map.put(key, 1);
	}

	public static List<ParaDynamicIs> printTop(PrintStream pt, Map<ParaDynamicIs,Record> sorted){
		Record topResult  = null;
		List<ParaDynamicIs> topPar = new ArrayList<ParaDynamicIs>();
		for(Entry<ParaDynamicIs, Record> entry: sorted.entrySet()){
			if(topResult == null){
				topResult = entry.getValue();
				topPar.add(entry.getKey());
			}
			else if(entry.getValue().compareTo(topResult) >= 0)
				topPar.add(entry.getKey());
			else 
				break;
		}
		for(ParaDynamicIs par: topPar){
			pt.println("==========");
			pt.println("Setting: "+par);
			pt.println("Setting Values: "+par.toStringValue());
			pt.println("Result: "+sorted.get(par));
		}
		return topPar;
	}

	public static void printWithSetting(Set<ParaDynamicIs> topSettings) throws FileNotFoundException{
		List<ParaDynamicIs> paras = new ArrayList<ParaDynamicIs>();
		int noIs = 11;
		for(int i=0;i<noIs;i++)
			for(int j=i;j<noIs;j++){
				paras.add(new ParaDynamicIs(i, j));
			}
//		paras.addAll(topSettings);
//		paras.add(new ParaDynamicIs(1,5));
//		paras.add(new ParaDynamicIs(3, 9));
//		paras.add(new ParaDynamicIs(8, 9));
//		paras.add(new ParaDynamicIs(0, 9));
//		paras.add(new ParaDynamicIs(1, 8));
//		paras.add(new ParaDynamicIs(2, 3));
//		paras.add(new ParaDynamicIs(1, 9));
//		paras.add(new ParaDynamicIs(2, 10));
//		paras.add(new ParaDynamicIs(6, 10));
		
		int[] rankSum = new int[paras.size()];

		System.out.print("Dataset");
		for(int i=0;i<paras.size();i++)
			System.out.print("\tS"+(i+1));
		System.out.println();

		String[] datasets = new String[]{"weing1","weish15","gk01","gk05",
				"ISCI1000","SCI500"};

		String dir = "FullResults/OptimizeDynamicKsIs";
		int noRuns = 10;

		for(String dataset: datasets){
			double[] optimals = new double[paras.size()];
			String toPrint = dataset;
			for(int i=0;i<paras.size();i++){
				ParaDynamicIs para = paras.get(i);
				double ave = 0;
				for(int run=1;run<=noRuns;run++)
				{
					File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+para.isLowIndex+"_"+para.isUpIndex+".txt");
					Scanner sc = new Scanner(file);
					while(sc.hasNextLine()){
						String line = sc.nextLine();
						if(line.startsWith("Optimal")){
							line = sc.nextLine();
							ave += Double.parseDouble(line.split(",")[0].trim());
							break;
						}
						//						if(line.contains("Iteration 100:")){
						//							line = sc.nextLine();
						//							ave += Double.parseDouble(line.split(":")[1].trim());
						//							break;
						//						}
					}
					sc.close();
				}
				ave = ave/10;
				optimals[i] = ave;
			}

			for(int i=0;i<optimals.length;i++){
				int rank = getRank(optimals,optimals[i]);
				rankSum[i] += rank;
				toPrint += "\t"+rank;
			}

			System.out.println(toPrint);
		}
		System.out.print("Ave");
		for(int rank: rankSum){
			System.out.print("\t"+rank);
		}
		System.out.println();System.out.println();

		for(int i=0;i<paras.size();i++){
			System.out.println("S"+(i+1)+": "+paras.get(i).toStringValue());
		}
	}

	public static int getRank(double[] array, double value){
		int count = 0;//count the number of elementes greater than value
		for(double d: array){
			if(d > value)
				count++;
		}
		return count+1;
	}
	
}
