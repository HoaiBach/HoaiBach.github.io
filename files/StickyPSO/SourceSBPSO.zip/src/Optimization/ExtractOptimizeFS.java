package Optimization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import Utility.Utility;

public class ExtractOptimizeFS {


	public static void main(String[] args) throws FileNotFoundException{
		
		String[] datasets = new String[]{"Wine","WBCD","Sonar"};

		String dir = "FullResults/OptimizeStaticFS";
		int noRuns = 5;
		int isSize = 11;
		int pgSize = 3;
		int usSize = 10;
		int noIterations = 100;

		double[] isValues = new double[]{0,1,2,3,4,5,6,7,8,9,10};
		double[] pgRateValues = new double[]{0.5,1.0,2.0};
		double ustkUnit = noIterations/100.0;
		double[] ustkValues = new double[10];
		for(int i=0;i<ustkValues.length;i++)
			ustkValues[i] = (i+1)*(ustkUnit);

		Set<Para> topSettings = new HashSet<Para>();
		
		PrintStream pt = new PrintStream(new File("ProcessResults/OptimizeStaticFS/ranking.txt"));
		PrintStream stat = new PrintStream(new File("ProcessResults/OptimizeStaticFS/stat.txt"));
		for(String dataset: datasets){
			PrintStream outdata = new PrintStream(new File("ProcessResults/OptimizeStaticFS/Draw/Data/"+dataset+".txt"));
			outdata.println("is,pgRate,ustkS,profit");
			pt.println(dataset.toUpperCase());
			stat.println(dataset.toUpperCase());
			Map<Para,Record> results = new HashMap<Para,Record>();
			for(int isIndex = 0; isIndex<isSize; isIndex++)
				for(int pgIndex = 0; pgIndex < pgSize; pgIndex++)
					for(int usIndex =1; usIndex<usSize; usIndex = usIndex+2)
					{
//						int pgIndex=1;
						Para par = new Para(isIndex, pgIndex, usIndex);

						double[] records = new double[noRuns];
						for(int run = 1;run <= noRuns;run++){
							File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+isIndex+"_"+pgIndex+"_"+usIndex+".txt");
							Scanner sc = new Scanner(file);
							while(sc.hasNext()){
								String line = sc.nextLine();
								if(line.startsWith("Size"))
									break;
//								if(line.contains("Iteration 400:"))
//									break;
							}
							String line = sc.nextLine();
							double fitness = Double.parseDouble(line.split(",")[3].trim());
//							double profit = Double.parseDouble(line.split(":")[1].trim());

							records[run-1] = fitness;
							sc.close();

							outdata.println(isValues[par.isIndex]
									+","+pgRateValues[par.pgIndex]
											+","+ustkValues[par.usIndex]
													+","+fitness);
						}
						double ave = Utility.average(records);
						double std = Utility.std(records);
						Record record = new Record(ave,std);

						results.put(par, record);
					}

			Map<Para,Record> sorted = results.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.naturalOrder()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
							(oldValue, newValue) -> oldValue, LinkedHashMap::new));
			
			List<Para> pars = printTop(pt,sorted);

			topSettings.addAll(pars);
			
			Map<Integer,Integer> isCount = new HashMap<Integer,Integer>();
			Map<Integer,Integer> pgCount = new HashMap<Integer,Integer>();
			Map<Integer,Integer> usCount = new HashMap<Integer,Integer>();
			for(Para par: pars){
				updateMap(isCount,par.isIndex);
				updateMap(pgCount,par.pgIndex);
				updateMap(usCount,par.usIndex);
			}
			stat.println("=====is======");
			for(Entry<Integer,Integer> entry: isCount.entrySet()){
				stat.println(isValues[entry.getKey()]+", "+entry.getValue());
			}
			stat.println("=====pg======");
			for(Entry<Integer,Integer> entry: pgCount.entrySet()){
				stat.println(pgRateValues[entry.getKey()]+", "+entry.getValue());
			}
			stat.println("=====us======");
			for(Entry<Integer,Integer> entry: usCount.entrySet()){
				stat.println(ustkValues[entry.getKey()]+", "+entry.getValue());
			}

			//			int count =0;
			//			int max = sorted.size();
			pt.println("*****************************************************************");
			stat.println("*****************************************************************");
		}
		pt.close();
		stat.close();

		printWithSetting(topSettings);
	}

	public static void updateMap(Map<Integer,Integer> map, Integer key){
		if(map.containsKey(key))
			map.put(key, map.get(key)+1);
		else
			map.put(key, 1);
	}

	public static List<Para> printTop(PrintStream pt, Map<Para,Record> sorted){
		Record topResult  = null;
		List<Para> topPar = new ArrayList<Para>();
		for(Entry<Para, Record> entry: sorted.entrySet()){
			if(topResult == null){
				topResult = entry.getValue();
				topPar.add(entry.getKey());
			}
			else if(entry.getValue().compareTo(topResult) <= 0)
				topPar.add(entry.getKey());
			else 
				break;
		}
		for(Para par: topPar){
			pt.println("==========");
			pt.println("Setting: "+par);
			pt.println("Result: "+sorted.get(par));
		}
		return topPar;
	}

	public static void printWithSetting(Set<Para> settings) throws FileNotFoundException{
		List<Para> paras = new ArrayList<Para>();
		paras.addAll(settings);
		paras.add(new Para(4,2,7));
		paras.add(new Para(4,2,9));
		
		int[] rankSum = new int[paras.size()];
		
		System.out.print("Dataset");
		for(int i=0;i<paras.size();i++)
			System.out.print("\tS"+(i+1));
		System.out.println();
		
//		String[] datasets = new String[]{"sento1",  "gk01","gk05","gk10", 
//				"UCI500","ISCI1000","SCI2000","WCI5000"};
		String[] datasets = new String[]{"Wine","WBCD","Sonar"};

		String dir = "FullResults/OptimizeStaticFS";
		int noRuns = 5;
		
		for(String dataset: datasets){
			double[] optimals = new double[paras.size()];
			String toPrint = dataset;
			for(int i=0;i<paras.size();i++){
				Para para = paras.get(i);
				double ave = 0;
				for(int run=1;run<=noRuns;run++)
				{
					File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+para.isIndex+"_"+para.pgIndex+"_"+para.usIndex+".txt");
					Scanner sc = new Scanner(file);
					while(sc.hasNextLine()){
						String line = sc.nextLine();
						if(line.startsWith("Size")){
						line = sc.nextLine();
						ave += Double.parseDouble(line.split(",")[3].trim());
						break;
						}
//						if(line.contains("Iteration 100:")){
//							line = sc.nextLine();
//							ave += Double.parseDouble(line.split(":")[1].trim());
//							break;
//						}
					}
					sc.close();
				}
				ave = ave/10;
				optimals[i] = ave;
			}

			for(int i=0;i<optimals.length;i++){
				int rank = getRank(optimals,optimals[i]);
				rankSum[i] += rank;
				toPrint += "\t"+rank;
			}
			
			System.out.println(toPrint);
		}
		System.out.print("Ave");
		for(int rank: rankSum){
			System.out.print("\t"+rank);
		}
		System.out.println();System.out.println();
		
		for(int i=0;i<paras.size();i++){
			System.out.println("S"+(i+1)+": \t"+paras.get(i).toString());
		}
	}
	
	public static int getRank(double[] array, double value){
		int count = 0;//count the number of elementes smaller than value
		for(double d: array){
			if(d < value)
				count++;
		}
		return count+1;
	}
}
