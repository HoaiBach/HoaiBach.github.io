package Optimization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import Utility.Utility;

public class ExtractOptimizeDynamicUstk {


	public static void main(String[] args) throws FileNotFoundException{
		printWithSetting(null);System.exit(0);
		
		String[] datasets = new String[]{"weing1","weish15", "gk01","gk05",
				"ISCI1000","SCI500"};

		String dir = "FullResults/OptimizeDynamicKsUstk";
		int noRuns = 10;
		int ustkSize = 10;

		double[] ustkValues = new double[]{10,20,30,40,50,60,70,80,90,100};

		PrintStream pt = new PrintStream(new File("ProcessResults/OptimizeDynamicKsUstk/ranking.txt"));
		PrintStream stat = new PrintStream(new File("ProcessResults/OptimizeDynamicKsUstk/stat.txt"));
		Set<ParaDynamicUstk> topSettings = new HashSet<ParaDynamicUstk>();
		for(String dataset: datasets){
			PrintStream outdata = new PrintStream(new File("ProcessResults/OptimizeDynamicKsUstk/Draw/Data/"+dataset+".txt"));
			outdata.println("ustkL,ustkU,profit");
			pt.println(dataset.toUpperCase());
			stat.println(dataset.toUpperCase());
			Map<ParaDynamicUstk,Record> results = new HashMap<ParaDynamicUstk,Record>();
			for(int ustkLowIndex = 0; ustkLowIndex<ustkSize; ustkLowIndex++)
				for(int ustkUpIndex = ustkLowIndex; ustkUpIndex < ustkSize; ustkUpIndex++)
					{
						//1st isL - ParaDynamic.isUpIndex, isUp-ParaDynamic.usLowIndex,
						ParaDynamicUstk par = new ParaDynamicUstk(ustkLowIndex,ustkUpIndex);

						double[] records = new double[noRuns];
						for(int run = 1;run <= noRuns;run++){
							File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+ustkLowIndex+"_"+ustkUpIndex+".txt");
							Scanner sc = new Scanner(file);
							while(sc.hasNext()){
								String line = sc.nextLine();
								if(line.startsWith("Optimal"))
									break;
								//								if(line.contains("Iteration 400:"))
								//									break;
							}
							String line = sc.nextLine();
							double profit = Double.parseDouble(line.split(",")[0].trim());
							//							double profit = Double.parseDouble(line.split(":")[1].trim());

							records[run-1] = profit;
							sc.close();

							//1st
							outdata.println(ustkValues[par.ustkLowIndex]
									+","+ustkValues[par.ustkUpIndex]
													+","+profit);
						}
						double ave = Utility.average(records);
						double std = Utility.std(records);
						Record record = new Record(ave,std);

						results.put(par, record);
					}

			Map<ParaDynamicUstk,Record> sorted = results.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
							(oldValue, newValue) -> oldValue, LinkedHashMap::new));

			List<ParaDynamicUstk> pars = printTop(pt,sorted);
			topSettings.addAll(pars);
			
			Map<Integer,Integer> ustkLowCount = new HashMap<Integer,Integer>();
			Map<Integer,Integer> ustkUpCount = new HashMap<Integer,Integer>();
			for(ParaDynamicUstk par: pars){
				updateMap(ustkLowCount,par.ustkLowIndex);
				updateMap(ustkUpCount,par.ustkUpIndex);
			}
			stat.println("=====ustkLow======");
			for(Entry<Integer,Integer> entry: ustkLowCount.entrySet()){
				stat.println(ustkValues[entry.getKey()]+", "+entry.getValue());
			}
			stat.println("=====ustkUp======");
			for(Entry<Integer,Integer> entry: ustkUpCount.entrySet()){
				stat.println(ustkValues[entry.getKey()]+", "+entry.getValue());
			}

			//			int count =0;
			//			int max = sorted.size();
			pt.println("*****************************************************************");
			stat.println("*****************************************************************");
		}
		pt.close();
		stat.close();
		
		printWithSetting(topSettings);
	}

	public static void updateMap(Map<Integer,Integer> map, Integer key){
		if(map.containsKey(key))
			map.put(key, map.get(key)+1);
		else
			map.put(key, 1);
	}

	public static List<ParaDynamicUstk> printTop(PrintStream pt, Map<ParaDynamicUstk,Record> sorted){
		Record topResult  = null;
		List<ParaDynamicUstk> topPar = new ArrayList<ParaDynamicUstk>();
		for(Entry<ParaDynamicUstk, Record> entry: sorted.entrySet()){
			if(topResult == null){
				topResult = entry.getValue();
				topPar.add(entry.getKey());
			}
			else if(entry.getValue().compareTo(topResult) >= 0)
				topPar.add(entry.getKey());
			else 
				break;
		}
		for(ParaDynamicUstk par: topPar){
			pt.println("==========");
			pt.println("Setting: "+par);
			pt.println("Setting Values: "+par.toStringValue());
			pt.println("Result: "+sorted.get(par));
		}
		return topPar;
	}

	public static void printWithSetting(Set<ParaDynamicUstk> topSettings) throws FileNotFoundException{
		List<ParaDynamicUstk> paras = new ArrayList<ParaDynamicUstk>();
		//paras.addAll(topSettings);
		int noUstk = 10;
		for(int i=0;i<noUstk;i++)
			for(int j=i;j<noUstk;j++)
				paras.add(new ParaDynamicUstk(i,j));
		
		int[] rankSum = new int[paras.size()];

		System.out.print("Dataset");
		for(int i=0;i<paras.size();i++)
			System.out.print("\tS"+(i+1));
		System.out.println();

		String[] datasets = new String[]{"weing1","weish15","gk01","gk05",
				"ISCI1000","SCI500"};

		String dir = "FullResults/OptimizeDynamicKsUstk";
		int noRuns = 10;

		for(String dataset: datasets){
			double[] optimals = new double[paras.size()];
			String toPrint = dataset;
			for(int i=0;i<paras.size();i++){
				ParaDynamicUstk para = paras.get(i);
				double ave = 0;
				for(int run=1;run<=noRuns;run++)
				{
					File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+para.ustkLowIndex+"_"+para.ustkUpIndex+".txt");
					Scanner sc = new Scanner(file);
					while(sc.hasNextLine()){
						String line = sc.nextLine();
						if(line.startsWith("Optimal")){
							line = sc.nextLine();
							ave += Double.parseDouble(line.split(",")[0].trim());
							break;
						}
						//						if(line.contains("Iteration 100:")){
						//							line = sc.nextLine();
						//							ave += Double.parseDouble(line.split(":")[1].trim());
						//							break;
						//						}
					}
					sc.close();
				}
				ave = ave/10;
				optimals[i] = ave;
			}

			for(int i=0;i<optimals.length;i++){
				int rank = getRank(optimals,optimals[i]);
				rankSum[i] += rank;
				toPrint += "\t"+rank;
			}

			System.out.println(toPrint);
		}
		System.out.print("Ave");
		for(int rank: rankSum){
			System.out.print("\t"+rank);
		}
		System.out.println();System.out.println();

		for(int i=0;i<paras.size();i++){
			System.out.println("S"+(i+1)+": "+paras.get(i).toStringValue());
		}
	}

	public static int getRank(double[] array, double value){
		int count = 0;//count the number of elementes greater than value
		for(double d: array){
			if(d > value)
				count++;
		}
		return count+1;
	}
	
}

