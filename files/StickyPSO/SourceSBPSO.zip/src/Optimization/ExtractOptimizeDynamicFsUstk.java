package Optimization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import Utility.Utility;

public class ExtractOptimizeDynamicFsUstk {

	public static void main(String[] args) throws FileNotFoundException{

		printWithSetting(null);System.exit(0);
		
		String[] datasets = new String[]{"Wine","WBCD","Sonar"};

		String dir = "FullResults/OptimizeDynamicFsUstk";
		int noRuns = 10;
		int ustkSize = 10;
		int noIterations = 100;

		double[] isValues = new double[]{0,1,2,3,4,5,6,7,8,9,10};
		double ustkUnit = noIterations/100.0;
		double[] ustkValues = new double[10];
		for(int i=0;i<ustkValues.length;i++)
			ustkValues[i] = (i+1)*(ustkUnit);

		Set<ParaDynamicUstk> topSettings = new HashSet<ParaDynamicUstk>();

		PrintStream pt = new PrintStream(new File("ProcessResults/OptimizeDynamicFsUstk/ranking.txt"));
		PrintStream stat = new PrintStream(new File("ProcessResults/OptimizeDynamicFsUstk/stat.txt"));
		for(String dataset: datasets){
			PrintStream outdata = new PrintStream(new File("ProcessResults/OptimizeDynamicFsUstk/Draw/Data/"+dataset+".txt"));
			outdata.println("ustkL,ustkU,profit");
			pt.println(dataset.toUpperCase());
			stat.println(dataset.toUpperCase());
			Map<ParaDynamicUstk,Record> results = new HashMap<ParaDynamicUstk,Record>();
			for(int ustkLowIndex = 0; ustkLowIndex<ustkSize;ustkLowIndex++)
				for(int ustkUpIndex = ustkLowIndex; ustkUpIndex<ustkSize;ustkUpIndex++)
				{
					//						int pgIndex=1;
					ParaDynamicUstk par = new ParaDynamicUstk(ustkLowIndex, ustkUpIndex);

					double[] records = new double[noRuns];
					for(int run = 1;run <= noRuns;run++){
						File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+ustkLowIndex+"_"+ustkUpIndex+".txt");
						Scanner sc = new Scanner(file);
						while(sc.hasNext()){
							String line = sc.nextLine();
							if(line.startsWith("Size"))
								break;
							//								if(line.contains("Iteration 400:"))
							//									break;
						}
						String line = sc.nextLine();
						double fitness = Double.parseDouble(line.split(",")[3].trim());
						//							double profit = Double.parseDouble(line.split(":")[1].trim());

						records[run-1] = fitness;
						sc.close();

						outdata.println(isValues[par.ustkLowIndex]
								+","+isValues[par.ustkUpIndex]
										+","+fitness);
					}
					double ave = Utility.average(records);
					double std = Utility.std(records);
					Record record = new Record(ave,std);

					results.put(par, record);
				}

			Map<ParaDynamicUstk,Record> sorted = results.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.naturalOrder()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
							(oldValue, newValue) -> oldValue, LinkedHashMap::new));

			List<ParaDynamicUstk> pars = printTop(pt,sorted);

			topSettings.addAll(pars);

			Map<Integer,Integer> ustkLowCount = new HashMap<Integer,Integer>();
			Map<Integer,Integer> ustkUpCount = new HashMap<Integer,Integer>();
			for(ParaDynamicUstk par: pars){
				updateMap(ustkLowCount,par.ustkLowIndex);
				updateMap(ustkUpCount,par.ustkUpIndex);
			}
			stat.println("=====ustkLow======");
			for(Entry<Integer,Integer> entry: ustkLowCount.entrySet()){
				stat.println(isValues[entry.getKey()]+", "+entry.getValue());
			}
			stat.println("=====ustkUp======");
			for(Entry<Integer,Integer> entry: ustkUpCount.entrySet()){
				stat.println(isValues[entry.getKey()]+", "+entry.getValue());
			}

			//			int count =0;
			//			int max = sorted.size();
			pt.println("*****************************************************************");
			stat.println("*****************************************************************");
		}
		pt.close();
		stat.close();

		printWithSetting(topSettings);
	}

	public static void updateMap(Map<Integer,Integer> map, Integer key){
		if(map.containsKey(key))
			map.put(key, map.get(key)+1);
		else
			map.put(key, 1);
	}

	public static List<ParaDynamicUstk> printTop(PrintStream pt, Map<ParaDynamicUstk,Record> sorted){
		Record topResult  = null;
		List<ParaDynamicUstk> topPar = new ArrayList<ParaDynamicUstk>();
		for(Entry<ParaDynamicUstk, Record> entry: sorted.entrySet()){
			if(topResult == null){
				topResult = entry.getValue();
				topPar.add(entry.getKey());
			}
			else if(entry.getValue().compareTo(topResult) <= 0)
				topPar.add(entry.getKey());
			else 
				break;
		}
		for(ParaDynamicUstk par: topPar){
			pt.println("==========");
			pt.println("Setting: "+par);
			pt.println("Result: "+sorted.get(par));
		}
		return topPar;
	}

	public static void printWithSetting(Set<ParaDynamicUstk> settings) throws FileNotFoundException{
		List<ParaDynamicUstk> paras = new ArrayList<ParaDynamicUstk>();		
		int noUstk = 10;
		for(int i=0;i<noUstk;i++)
			for(int j=i;j<noUstk;j++){
				paras.add(new ParaDynamicUstk(i, j));
			}
//		paras.addAll(settings);
//		paras.add(new ParaDynamicIs(0, 10));

		int[] rankSum = new int[paras.size()];

		System.out.print("Dataset");
		for(int i=0;i<paras.size();i++)
			System.out.print("\tS"+(i+1));
		System.out.println();

		//		String[] datasets = new String[]{"sento1",  "gk01","gk05","gk10", 
		//				"UCI500","ISCI1000","SCI2000","WCI5000"};
		String[] datasets = new String[]{"Wine","WBCD","Sonar"};

		String dir = "FullResults/OptimizeDynamicFsUstk";
		int noRuns = 10;

		for(String dataset: datasets){
			double[] optimals = new double[paras.size()];
			String toPrint = dataset;
			for(int i=0;i<paras.size();i++){
				ParaDynamicUstk para = paras.get(i);
				double ave = 0;
				for(int run=1;run<=noRuns;run++)
				{
					File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+para.ustkLowIndex+"_"+para.ustkUpIndex+".txt");
					Scanner sc = new Scanner(file);
					while(sc.hasNextLine()){
						String line = sc.nextLine();
						if(line.startsWith("Size")){
							line = sc.nextLine();
							ave += Double.parseDouble(line.split(",")[3].trim());
							break;
						}
						//						if(line.contains("Iteration 100:")){
						//							line = sc.nextLine();
						//							ave += Double.parseDouble(line.split(":")[1].trim());
						//							break;
						//						}
					}
					sc.close();
				}
				ave = ave/10;
				optimals[i] = ave;
			}

			for(int i=0;i<optimals.length;i++){
				int rank = getRank(optimals,optimals[i]);
				rankSum[i] += rank;
				toPrint += "\t"+rank;
			}

			System.out.println(toPrint);
		}
		System.out.print("Ave");
		for(int rank: rankSum){
			System.out.print("\t"+rank);
		}
		System.out.println();System.out.println();

		for(int i=0;i<paras.size();i++){
			System.out.println("S"+(i+1)+": \t"+paras.get(i).toStringValue());
		}
	}

	public static int getRank(double[] array, double value){
		int count = 0;//count the number of elementes smaller than value
		for(double d: array){
			if(d < value)
				count++;
		}
		return count+1;
	}

}
