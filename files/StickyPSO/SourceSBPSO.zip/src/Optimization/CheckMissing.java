package Optimization;

import java.io.File;

public class CheckMissing {

	public static void main(String[] args){
		String[] datasets = new String[] {"ISCI1000"};

		for(String dataset: datasets) {
			for(int j=0;j<3;j++) {
				for(int k=0;k<10;k++) {
					for(int run=1;run<=10;run++) {
						File file = new File("/Users/nguyenhoai2/Documents/Eclipse/SwarmAlgorithm/FullResults/NewOptimize/"+dataset+"/Output_"+run+"_0_"+j+"_"+k+".txt");
						if(!file.exists())
							System.out.println("qsub -t "+run+"-"+run+":1 optimize.sh '"+dataset+"' "+j+" "+k);
					}
				}
			}
		}

	}
}

