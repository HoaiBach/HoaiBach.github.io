package Optimization;

public class ParaDynamicUstk {

	int ustkLowIndex,ustkUpIndex;

	double[] ustkValues = new double[]{10,20,30,40,50,60,70,80,90,100};
	
	public ParaDynamicUstk(int ustkLowIndex, int ustkUpIndex){
		this.ustkLowIndex = ustkLowIndex;
		this.ustkUpIndex = ustkUpIndex;
	}
	
	public String toString(){		
		String toReturn = "ustkLowIndex= "+ustkLowIndex+", ustkUpIndex= "+ustkUpIndex;
		return toReturn;
	}
	
	public String toStringValue(){
		String toReturn = "ustkLow= "+ustkValues[ustkLowIndex]+", ustkUp= "+ustkValues[ustkUpIndex];
		return toReturn;
	}
	
	public boolean equals(Object other){
		if(!(other instanceof ParaDynamicUstk))
			return false;
		ParaDynamicUstk parOther = (ParaDynamicUstk) other;
		return (this.ustkLowIndex==parOther.ustkLowIndex 
				&& this.ustkUpIndex == parOther.ustkUpIndex);
	}

	public int hashCode(){
		return (int)(Math.pow(7, this.ustkLowIndex)+Math.pow(13, this.ustkUpIndex));
	}
}
