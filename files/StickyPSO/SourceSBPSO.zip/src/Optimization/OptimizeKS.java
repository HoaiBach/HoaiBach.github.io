package Optimization;

import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import Core.Initializer;
import PSO.Particle.DynamicStickyParticle;
import PSO.Particle.Particle;
import PSO.Particle.StaticStickyParticle;
import PSO.Swarm.Swarm;
import PSO.Swarm.Swarm.ParticleType;
import PSO.Topology.Topology;
import PSO.Topology.TopologyStar;
import Problem.Knapsack.Knapsack;
import Utility.RandomSeed;
import Utility.Utility;
public class OptimizeKS {

	/**
	 *
	 * @param args: 1st run (0)
	 * for optimization static: all indices of is, pgrate, ustks-
	 * for ooptimization dynamic: indices of isL (1), isU (2)
	 * or: indices of usL (1), usU(2)
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		int r = Integer.parseInt(args[0]);
		int noIterations = 1000;

		long seeder = (long) (Math.pow(10, 6)*(r+3));
		RandomSeed.Seeder.setSeed(seeder);

		Random initRandom = RandomSeed.Create();

		//Construct the classifier.
		//note noDim is the number of costs
		Knapsack problem = new Knapsack(0.5);
		int noItems = problem.getNoItems();
		int optimal = problem.getOptimal();
		int noDim = problem.getNoDim();

		//create initializer
		Initializer init = new Initializer(initRandom,problem);
		int	noParticles = noItems <= 100? noItems:100;
		//for optimization
		double isUnit = 1.0/noItems;
		double[] isValues = new double[11];
		for(int i=0;i<isValues.length;i++){
			isValues[i] = i*isUnit;
		}
		double[] pgRateValues = new double[]{1.0/2,1,2};
		double ustkUnit = noIterations/100.0;
		double[] ustkValues = new double[10];
		for(int i=0;i<ustkValues.length;i++)
			ustkValues[i] = (i+1)*(ustkUnit);

		//for static
		//		int isIndex = Integer.parseInt(args[1]);
		//		int pgRateIndex = Integer.parseInt(args[2]);
		//		int ustkSIndex = Integer.parseInt(args[3]);
		//		double is = isValues[isIndex];
		//		double pgRate = pgRateValues[pgRateIndex];
		//		double ustkS = ustkValues[ustkSIndex];

		//for dynamic
		int isLowIndex = 0;// Integer.parseInt(args[1]);
		int isUpIndex = 10;//Integer.parseInt(args[2]);
						int ustkLowIndex = Integer.parseInt(args[1]);//7
						int ustkUpIndex = Integer.parseInt(args[2]);//7
		double isLow = isValues[isLowIndex];
		double isUp = isValues[isUpIndex];
		double pgRate = 2.0;
		double ustkLow = ustkValues[ustkLowIndex];
		double ustkUp = ustkValues[ustkUpIndex];

		//output file - static
		//		File out = new File("Output_" +r+ "_" +Integer.parseInt(args[1]) + 
		//				"_"+Integer.parseInt(args[2])+"_"+Integer.parseInt(args[3])+".txt");

		//output file - dynamic
		File out = new File ("Output_" +r+ "_" +ustkLowIndex + "_"+ustkUpIndex+".txt");
		PrintStream pt = new PrintStream(out);
		pt.println("#items #optimal #dimension");
		pt.println(noItems+" "+optimal +" "+noDim);

		Topology topology = new TopologyStar();
		//		Swarm s = new Swarm(noItems, ParticleType.StaticSticky, 
		//				noParticles, topology, noIterations, problem);
		Swarm s = new Swarm(noItems, ParticleType.DynamicSticky, 
				noParticles, topology, noIterations, problem);

		//Initialize swarm.
		s.initialize();

		//for optimization
		for(Particle p: s.getPopulation()){
			//for static
			//			StaticStickyParticle sp = (StaticStickyParticle) p;
			//			sp.updateParameter(is, pgRate, ustkS);
			//for dynamic
			DynamicStickyParticle dp = (DynamicStickyParticle) p;
			dp.updateParameter(isLow, isUp, pgRate, ustkLow, ustkUp);
		}

		//for static
//		double testis = ((StaticStickyParticle)s.getPopulation().get(0)).getIs();
//		double testpgRate = ((StaticStickyParticle)s.getPopulation().get(0)).getPgRate();
//		double testustkS = ((StaticStickyParticle)s.getPopulation().get(0)).getUstkS();
//		pt.println("Setting: is= "+testis+", pgRate= "+testpgRate+ ", ustkS="+testustkS);

		//for Dynamic
				double testisLow = ((DynamicStickyParticle)s.getPopulation().get(0)).getIsLow();
				double testisUp = ((DynamicStickyParticle)s.getPopulation().get(0)).getIsUp();
				double testpgRate = ((DynamicStickyParticle)s.getPopulation().get(0)).getPgRate();
				double testustkLow = ((DynamicStickyParticle)s.getPopulation().get(0)).getUstkL();
				double testustkUp = ((DynamicStickyParticle)s.getPopulation().get(0)).getUstkU();
				pt.println("Setting: isLow= "+testisLow+", isUp= "+testisUp+", pgRate= "+testpgRate
						+ ", ustkSLow= "+testustkLow + ", ustkSUp= "+testustkUp);

		//to store the value during running time
		double[] fitnessArray = new double[noIterations];
		double[][] positions = new double[noIterations][noItems];

		//start run PSO
		long runningTime = System.currentTimeMillis();
		for (int i = 0; i < noIterations; ++i) {
			s.iterate();
			fitnessArray[i] = s.getPopulation().get(0).getGbestFitness();
			List<Double> bestPosition = Utility.copyList(s.getPopulation().get(0).getGbestPosition());
			positions[i] = problem.positionToArray(bestPosition);
		}
		//end all iterations

		// ****************** Results of the r-th Run  ***********************
		long estimatedTime = System.currentTimeMillis() - runningTime;
		List<Double> bestPosition = s.getPopulation().get(0).getGbestPosition();
		double fitness = s.getPopulation().get(0).getGbestFitness();
		double[] features = problem.positionToArray(bestPosition);

		//File file = new File(String.valueOf("Run"+Integer.valueOf(args[0]) + 1) + ".txt");   // for grid use  ** be carefull !!!!
		pt.println("===========================================================");
		int lap = noIterations/100;
		for(int i=0;i<noIterations;i=i+lap){
			pt.println("Iteration "+i+":");
			pt.println("Fitness: "+fitnessArray[i]);
			pt.println("Features: "+Arrays.toString(positions[i]));
			pt.println("===========================================================");
		}

		pt.println("Iteration "+(noIterations-1)+":");
		pt.println("Fitness: "+fitnessArray[noIterations-1]);
		pt.println("Features: "+Arrays.toString(positions[noIterations-1]));
		pt.println("===========================================================");

		pt.println("Optimal, Penalty, RunningTime");
		pt.println(fitness+", "+problem.calculatePenalty(bestPosition)+", "+estimatedTime);
		pt.println(Arrays.toString(features));
		pt.close();

		/*
		String outDir = "/Users/Mochi/Documents/Eclipse/PhDStudy/BinaryParticleSwarmOptimisation/ToPlot/Testing/";
		PrintStream pt1;
		if(testing){
			pt =  new PrintStream(new File(outDir+"rate1First.txt"));
			pt1 = new PrintStream(new File(outDir+"velocityFirst.txt"));
			//go through each item
			Particle p = s.getSwarm().get(0);
			for(int i=0;i<noIterations;i++){
				pt.print(i+"\t");
				pt1.print(i+"\t");
				for(int j=0;j<noItems;j++){
					pt.print(p.rate1[i][j]+"\t");
					pt1.print(p.vmemo[i][j]+"\t");
				}
				pt.println();
				pt1.println();
			}
			pt.close();
			pt1.close();

			pt =  new PrintStream(new File(outDir+"rate1Ave.txt"));
			pt1 = new PrintStream(new File(outDir+"velocityAve.txt"));
			for(int i=0;i<noIterations;i++){
				pt.print(i+"\t");
				pt1.print(i+"\t");
				for(int j=0;j<noItems;j++){
					double sumRate = 0;
					double sumVelo = 0;
					for(Particle ps:s.getSwarm()){
						sumRate += ps.rate1[i][j];
						sumVelo += ps.vmemo[i][j];
					}
					pt.print(sumRate / s.getSwarmSize()+"\t");
					pt1.print(sumVelo / s.getSwarmSize()+"\t");
				}
				pt.println();
				pt1.println();
			}
			pt.close();
			pt1.close();

		}*/
	}

	public static double twoDecimal(double s){
		return (int)(s*100+0.5)/100.0;
	}
}
