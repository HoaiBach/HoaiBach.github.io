package Optimization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.stream.Collectors;

import Utility.Utility;

public class ExtractOptimizeFinalDynamic {

	public static void main(String[] args) throws FileNotFoundException{

		printWithSetting();System.exit(0);

		String[] datasets = new String[]{"sento1",  "gk01","gk05","gk10", 
				"UCI500","ISCI1000","SCI2000","WCI5000"};//"weing5","weish23",

		String dir = "FullResults/OptimizeDynamic";
		int noRuns = 10;
		int isSize = 6;
		int alphaSize = 6;
		int usSize = 5;

		double[] isValues = new double[]{5,6,7,8,9,10};
		double[] alphaValues = new double[]{0.5,0.6,0.7,0.8,0.9,1.0};
		int[] usValues = new int[]{1,5,10,15,20};

		PrintStream pt = new PrintStream(new File("ProcessResults/OptimizeDynamic/ranking.txt"));
		PrintStream stat = new PrintStream(new File("ProcessResults/OptimizeDynamic/stat.txt"));
		for(String dataset: datasets){
			PrintStream outdata = new PrintStream(new File("ProcessResults/OptimizeDynamic/Draw/Data/"+dataset+".txt"));
			outdata.println("isU,ustkL,alpha,profit");
			pt.println(dataset.toUpperCase());
			stat.println(dataset.toUpperCase());
			Map<ParaDynamic,Record> results = new HashMap<ParaDynamic,Record>();
			for(int isIndex = 0; isIndex<isSize; isIndex++)
				for(int alphaIndex = 0; alphaIndex < alphaSize; alphaIndex++)
					for(int usIndex =0; usIndex<usSize; usIndex++)
					{
						//1st isL - isIndex, alphaIndex-pgIndex, usIndex-usIndex 
						ParaDynamic par = new ParaDynamic(isIndex,usIndex,alphaIndex);

						double[] records = new double[noRuns];
						for(int run = 1;run <= noRuns;run++){
							File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+isIndex+"_"+usIndex+"_"+alphaIndex+".txt");
							Scanner sc = new Scanner(file);
							while(sc.hasNext()){
								String line = sc.nextLine();
								if(line.startsWith("Optimal"))
									break;
								//								if(line.contains("Iteration 400:"))
								//									break;
							}
							String line = sc.nextLine();
							double profit = Double.parseDouble(line.split(",")[0].trim());
							//							double profit = Double.parseDouble(line.split(":")[1].trim());

							records[run-1] = profit;
							sc.close();

							outdata.println(isValues[par.isUpIndex]
									+","+usValues[par.usLowIndex]
											+","+alphaValues[par.alphaIndex]
													+","+profit);
						}
						double ave = Utility.average(records);
						double std = Utility.std(records);
						Record record = new Record(ave,std);

						results.put(par, record);
					}

			Map<ParaDynamic,Record> sorted = results.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
							(oldValue, newValue) -> oldValue, LinkedHashMap::new));

			List<ParaDynamic> pars = printTop(pt,sorted);
			Map<Integer,Integer> isCount = new HashMap<Integer,Integer>();
			Map<Integer,Integer> usCount = new HashMap<Integer,Integer>();
			Map<Integer,Integer> alphaCount = new HashMap<Integer,Integer>();
			for(ParaDynamic par: pars){
				updateMap(isCount,par.isUpIndex);
				updateMap(alphaCount,par.alphaIndex);
				updateMap(usCount,par.usLowIndex);
			}
			stat.println("=====isUp======");
			for(Entry<Integer,Integer> entry: isCount.entrySet()){
				stat.println(isValues[entry.getKey()]+", "+entry.getValue());
			}
			stat.println("=====usLow======");
			for(Entry<Integer,Integer> entry: usCount.entrySet()){
				stat.println(usValues[entry.getKey()]+", "+entry.getValue());
			}
			stat.println("=====alpha======");
			for(Entry<Integer,Integer> entry: alphaCount.entrySet()){
				stat.println(alphaValues[entry.getKey()]+", "+entry.getValue());
			}

			//			int count =0;
			//			int max = sorted.size();
			pt.println("*****************************************************************");
			stat.println("*****************************************************************");
		}
		pt.close();
		stat.close();
	}

	public static void updateMap(Map<Integer,Integer> map, Integer key){
		if(map.containsKey(key))
			map.put(key, map.get(key)+1);
		else
			map.put(key, 1);
	}

	public static List<ParaDynamic> printTop(PrintStream pt, Map<ParaDynamic,Record> sorted){
		Record topResult  = null;
		List<ParaDynamic> topPar = new ArrayList<ParaDynamic>();
		for(Entry<ParaDynamic, Record> entry: sorted.entrySet()){
			if(topResult == null){
				topResult = entry.getValue();
				topPar.add(entry.getKey());
			}
			else if(entry.getValue().compareTo(topResult) >= 0)
				topPar.add(entry.getKey());
			else 
				break;
		}
		for(ParaDynamic par: topPar){
			pt.println("==========");
			pt.println("Setting: "+par);
			pt.println("Setting Values: "+par.toStringValue());
			pt.println("Result: "+sorted.get(par));
		}
		return topPar;
	}

	public static void printWithSetting() throws FileNotFoundException{
		List<ParaDynamic> paras = new ArrayList<ParaDynamic>();
		paras.add(new ParaDynamic(1, 1, 4));
		paras.add(new ParaDynamic(2, 0, 0));
		paras.add(new ParaDynamic(3,0,3));
		paras.add(new ParaDynamic(5,2,3));
		paras.add(new ParaDynamic(2, 2, 1));
		paras.add(new ParaDynamic(1, 2, 4));
		paras.add(new ParaDynamic(5, 1, 5));
		
		int[] rankSum = new int[paras.size()];

		System.out.print("Dataset");
		for(int i=0;i<paras.size();i++)
			System.out.print("\tS"+(i+1));
		System.out.println();

//		String[] datasets = new String[]{"sento1",  "gk01","gk05","gk10", 
//				"UCI500","ISCI1000","SCI2000","WCI5000"};	
		String[] datasets = new String[]{"sento1",  "gk01","gk05", "gk10",
		"UCI500","ISCI1000","SCI2000","WCI5000"};

		String dir = "FullResults/OptimizeDynamic";
		int noRuns = 10;

		for(String dataset: datasets){
			double[] optimals = new double[paras.size()];
			String toPrint = dataset;
			for(int i=0;i<paras.size();i++){
				ParaDynamic para = paras.get(i);
				double ave = 0;
				for(int run=1;run<=noRuns;run++)
				{
					File file = new File(dir+"/"+dataset+"/Output_"+run+"_"+para.isUpIndex+"_"+para.usLowIndex+"_"+para.alphaIndex+".txt");
					Scanner sc = new Scanner(file);
					while(sc.hasNextLine()){
						String line = sc.nextLine();
						if(line.startsWith("Optimal")){
							line = sc.nextLine();
							ave += Double.parseDouble(line.split(",")[0].trim());
							break;
						}
						//						if(line.contains("Iteration 100:")){
						//							line = sc.nextLine();
						//							ave += Double.parseDouble(line.split(":")[1].trim());
						//							break;
						//						}
					}
					sc.close();
				}
				ave = ave/10;
				optimals[i] = ave;
			}

			for(int i=0;i<optimals.length;i++){
				int rank = getRank(optimals,optimals[i]);
				rankSum[i] += rank;
				toPrint += "\t"+rank;
			}

			System.out.println(toPrint);
		}
		System.out.print("Ave");
		for(int rank: rankSum){
			System.out.print("\t"+rank);
		}
		System.out.println();System.out.println();

		for(int i=0;i<paras.size();i++){
			System.out.println("S"+(i+1)+": "+paras.get(i).toStringValue());
		}
	}

	public static int getRank(double[] array, double value){
		int count = 0;//count the number of elementes greater than value
		for(double d: array){
			if(d > value)
				count++;
		}
		return count+1;
	}
}


