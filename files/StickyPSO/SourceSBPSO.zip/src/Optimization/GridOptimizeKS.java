package Optimization;

public class GridOptimizeKS {

	/**
	 * 1st: run, 2nd: pgrate, 3rd: ustks - static
	 * 1st: run, 2nd: islowIndex
	 * 1st: run, 2nd: usLowIndex
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception{
		//for static
//		String run = args[0];
//		int pgIndex = Integer.parseInt(args[1]);
//		int usIndex = Integer.parseInt(args[2]);
//		int noIs = 11;
//		for(int isIndex = 0; isIndex<noIs;isIndex++){
//			OptimizeKS.main(new String[]{run+"",isIndex+"",pgIndex+"",usIndex+""});
//		}

		//		for dynamic - us
		//		int ustkLowIndex = Integer.parseInt(args[1]);
		//		int noUstk = 10;
		//		for(int ustkUpIndex=ustkLowIndex;ustkUpIndex<noUstk;ustkUpIndex++){
		//			Optimize.main(new String[]{args[0],ustkLowIndex+"",ustkUpIndex+""});
		//		}
		
		//dor dynamic - is
//		int noIs = 11;
//		int isLowIndex = Integer.parseInt(args[1]);
//		for(int isUpIndex = isLowIndex;isUpIndex<noIs;isUpIndex++)
//			OptimizeKS.main(new String[]{args[0], args[1],isUpIndex+""});
		
		//dor dynamic - is
		int noUstk = 10;
		int ustkLowIndex = Integer.parseInt(args[1]);
		for(int ustkUpIndex = ustkLowIndex;ustkUpIndex<noUstk;ustkUpIndex++)
			OptimizeKS.main(new String[]{args[0], args[1],ustkUpIndex+""});

	}
}
