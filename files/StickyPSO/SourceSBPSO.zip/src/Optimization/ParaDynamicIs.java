package Optimization;

public class ParaDynamicIs {

	int isLowIndex,isUpIndex;

	double[] isValues = new double[]{0,1,2,3,4,5,6,7,8,9,10};

	public ParaDynamicIs(int isLowIndex, int isUpIndex){
		this.isLowIndex = isLowIndex;
		this.isUpIndex = isUpIndex;
	}

	public String toString(){		
		String toReturn = "isLowIndex= "+isLowIndex+", isUpIndex= "+isUpIndex;
		return toReturn;
	}

	public boolean equals(Object other){
		if(!(other instanceof ParaDynamicIs))
			return false;
		ParaDynamicIs parOther = (ParaDynamicIs) other;
		return (this.isLowIndex==parOther.isLowIndex 
				&& this.isUpIndex == parOther.isUpIndex);
	}

	public int hashCode(){
		return (int)(Math.pow(7, this.isLowIndex)+Math.pow(13, this.isUpIndex));
	}

	public String toStringValue(){
		String toReturn = "isLow= "+isValues[isLowIndex]+", isUp= "+isValues[isUpIndex];
		return toReturn;
	}
}
