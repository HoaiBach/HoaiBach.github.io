package Optimization;

import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import Core.Individual;
import Core.Initializer;
import DE.DESwarm;
import DE.DESwarm.DEType;
import PSO.Particle.DynamicStickyParticle;
import PSO.Particle.Particle;
import PSO.Particle.StaticStickyParticle;
import PSO.Swarm.Swarm;
import PSO.Swarm.Swarm.ParticleType;
import PSO.Topology.Topology;
import PSO.Topology.TopologyStar;
import Problem.Problem;
import Problem.FeatureSelection.FeatureSelection;
import Problem.FeatureSelection.HelpDataset;
import Problem.FeatureSelection.MainHelp;
import Problem.FeatureSelection.MyClassifier;
import Utility.RandomSeed;
import Utility.Utility;
import net.sf.javaml.core.Dataset;

public class OptimizeFS {
	/**
	 * 
	 * @param args: 
	 * static: 0-run, 1-isIndex, 2-pgIndex, 3-ustkSindex
	 * dynamic Is: 0-run, 1-usLowIndex, 2-isUpIdex
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception{
		int r = Integer.parseInt(args[0]);
		int noIterations = 100;

		long seeder = (long) (Math.pow(10, 6)*(r+3));
		RandomSeed.Seeder.setSeed(seeder);

		/** start PSO    */
		//seed for constant results PSO
		Random initRandom = RandomSeed.Create();

		//Construct the dataset.
		int noFeatures = MainHelp.noFeature();
		Dataset[] trainTest = MainHelp.readBingData(noFeatures);
		Dataset training = trainTest[0];
		Dataset testing = trainTest[1];

		//Construct the classifier.
		MyClassifier myclassifier = new MyClassifier();
		myclassifier.ClassifierBingKNN();

		// Construct the problem
		Problem fs = new FeatureSelection(training,testing,0.6);
		((FeatureSelection)fs).setClassifier(myclassifier);

		//create initializer
		@SuppressWarnings("unused")
		Initializer init = new Initializer(initRandom,fs);

		//write full set results
		double fullTrain = myclassifier.fullclassify(training, training);
		double fullTest = myclassifier.fullclassify(training, testing);

		int noParticles;
		if(noFeatures>100)
			noParticles = 100;
		else
			noParticles = noFeatures;

		//for optimization
		double isUnit = 1.0/noFeatures;
		double[] isValues = new double[11];
		for(int i=0;i<isValues.length;i++){
			isValues[i] = i*isUnit;
		}
		double[] pgRateValues = new double[]{1.0/2,1,2};
		double ustkUnit = noIterations/100.0;
		double[] ustkValues = new double[10];
		for(int i=0;i<ustkValues.length;i++)
			ustkValues[i] = (i+1)*(ustkUnit);

		//for static
		//		int isIndex = Integer.parseInt(args[1]);
		//		int pgRateIndex = Integer.parseInt(args[2]);
		//		int ustkSIndex = Integer.parseInt(args[3]);
		//
		//		double is = isValues[isIndex];
		//		double pgRate = pgRateValues[pgRateIndex];
		//		double ustkS = ustkValues[ustkSIndex];

		//dor dynamic
		int isLowIndex = 0;
		int isUpIndex = 10;
		int ustkLowIndex = Integer.parseInt(args[1]);//7;
		int ustkUpIndex=Integer.parseInt(args[2]);//7;

		double pgRate = 2.0;
		double isLow = isValues[isLowIndex];
		double isUp = isValues[isUpIndex];
		double ustkLow = ustkValues[ustkLowIndex];
		double ustkUp = ustkValues[ustkUpIndex];

		//for static
		//		File out = new File("Output_" +r+ "_" +Integer.parseInt(args[1]) + 
		//				"_"+Integer.parseInt(args[2])+"_"+Integer.parseInt(args[3])+".txt");

		//for dynamic
		File out = new File("Output_" +r+ "_" +ustkLowIndex+"_"+ustkUpIndex+".txt");
		PrintStream pt = new PrintStream(out);
		pt.println("fullSet.Trainacc() " + fullTrain);
		pt.println("fullSet.Testacc()   " + fullTest);
		pt.println("no features:" +noFeatures);

		Topology topology = new TopologyStar();
		//		Swarm s = new Swarm(noFeatures, ParticleType.StaticSticky, 
		//				noParticles, topology, noIterations, fs);
		Swarm s = new Swarm(noFeatures, ParticleType.DynamicSticky, 
				noParticles, topology, noIterations, fs);

		//Initialize swarm.
		s.initialize();

		//for optimization
		for(Particle p: s.getPopulation()){
			//for static
			//			StaticStickyParticle sp = (StaticStickyParticle) p;
			//			sp.updateParameter(is, pgRate, ustkS);
			//for dynamic
			DynamicStickyParticle dp = (DynamicStickyParticle) p;
			dp.updateParameter(isLow, isUp, pgRate, ustkLow, ustkUp);
		}

		//for Static
//		double testis = ((StaticStickyParticle)s.getPopulation().get(0)).getIs();
//		double testpgRate = ((StaticStickyParticle)s.getPopulation().get(0)).getPgRate();
//		double testustkS = ((StaticStickyParticle)s.getPopulation().get(0)).getUstkS();
//		pt.println("Setting: is= "+testis+", pgRate= "+testpgRate+ ", ustkS="+testustkS);

		//for Dynamic
		double testisLow = ((DynamicStickyParticle)s.getPopulation().get(0)).getIsLow();
		double testisUp = ((DynamicStickyParticle)s.getPopulation().get(0)).getIsUp();
		double testpgRate = ((DynamicStickyParticle)s.getPopulation().get(0)).getPgRate();
		double testustkLow = ((DynamicStickyParticle)s.getPopulation().get(0)).getUstkL();
		double testustkUp = ((DynamicStickyParticle)s.getPopulation().get(0)).getUstkU();
		pt.println("Setting: isLow= "+testisLow+", isUp= "+testisUp+", pgRate= "+testpgRate
				+ ", ustkSLow= "+testustkLow + ", ustkSUp= "+testustkUp);
		
		long startTime = 0;

		//to store the value during running time
		double[] fitnessArray = new double[noIterations];
		double[][] positions = new double[noIterations][noFeatures];
		List<Double> bestPosition= null;
		double bestFitness = fs.getWorstFitness();

		//start run PSO
		startTime = System.currentTimeMillis();
		for (int i = 0; i < noIterations; ++i) {
			s.iterate();
			fitnessArray[i] = s.getPopulation().get(0).getGbestFitness();
			bestPosition = Utility.copyList(s.getPopulation().get(0).getGbestPosition());
			positions[i] = fs.positionToArray(bestPosition);
		}
		bestPosition = s.getPopulation().get(0).getGbestPosition();
		bestFitness = s.getPopulation().get(0).getGbestFitness();
		//end all iterations

		// ****************** Results of the r-th Run  ***********************
		long estimatedTime = System.currentTimeMillis() - startTime;
		double[] features = ((FeatureSelection)fs).positionToFeatures(bestPosition);
		double fitness = bestFitness;

		Dataset newTrain = HelpDataset.removeFeatures(training.copy(), features);
		Dataset newTest = HelpDataset.removeFeatures(testing.copy(), features);
		double trainAcc = myclassifier.classify(newTrain, newTrain);
		double testAcc = myclassifier.classify(newTrain, newTest);
		int size = MainHelp.sizeSubset(features);


		//File file = new File(String.valueOf("Run"+Integer.valueOf(args[0]) + 1) + ".txt");   // for grid use  ** be carefull !!!!
		pt.println("===========================================================");
		for(int i=0;i<noIterations;i++){
			pt.println("Iteration "+i+":");
			pt.println("Fitness: "+fitnessArray[i]);
			pt.println("Features: "+Arrays.toString(positions[i]));
			pt.println("===========================================================");
		}
		pt.println("Size, TrainAcc, TestAcc, Fitness, RunningTime");
		pt.println(size+", "+twoDecimal(trainAcc*100)+", "+twoDecimal(testAcc*100)+","+
				fitness+", "+estimatedTime);
		pt.println(Arrays.toString(features));
		pt.close();

	}

	public static double twoDecimal(double s){
		return (int)(s*100+0.5)/100.0;
	}
}
