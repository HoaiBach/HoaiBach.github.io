package Optimization;

public class Para {
	int isIndex,pgIndex,usIndex;

	double[] isValues = new double[]{0,1,2,3,4,5,6,7,8,9,10};
	double[] pgRates = new double[]{0.5,1,2};
	int[] uTimes = new int[]{1,2,3,4,5,6,7,8,9,10};
	
	public Para(int isIndex, int pgIndex, int usIndex){
		this.isIndex = isIndex;
		this.pgIndex = pgIndex;
		this.usIndex = usIndex;
	}
	
	public String toString(){
//		String toReturn = "is= "+isValues[isIndex]+"\t pgRate= "+pgRates[pgIndex]+"\t usTime= "+uTimes[this.usIndex];
		String toReturn = isValues[isIndex]+"\t"+pgRates[pgIndex]+"\t"+uTimes[this.usIndex];
		return toReturn;
	}
	
	public boolean equals(Object other){
		if(! (other instanceof Para))
			return false;
		Para pa =(Para) other;
		return (this.isIndex==pa.isIndex && this.pgIndex == pa.pgIndex
				&& this.usIndex== pa.usIndex);
	}
	
	public int hashCode(){
		return (int)(Math.pow(7, this.isIndex)+Math.pow(13, this.pgIndex)+Math.pow(17, usIndex));
	}
}