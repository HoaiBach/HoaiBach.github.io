package Optimization;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class ExtractOptimizeEP {

	public static void main(String[] args) throws FileNotFoundException{

		
		String[] datasets = new String[]{"pet7", "sento1", "ks_16a", 
				"weing5", "weish16", "weish23", 
				"gk01", "gk05", "gk07","UCI100", "WCI500", "SCI1000"};
		
		String inDir = "FullResults/OptimizeStatic";
		String outDir = "ProcessResults/OptimizeStatic/EP/Data";
		int noRuns = 10;
		int isSize = 11;
		int pgSize = 5;
		int usSize = 8;
		int noIterations = 101;

		double[] isValues = new double[]{0.01,0.03,0.06,0.09,0.12,0.15,0.18,0.21,0.24,0.27,0.30};
		double[] pgRates = new double[]{1.0/2,2.0/3,1,1.5,2};
		int[] uTimes = new int[]{1,2,3,4,5,6,7,8};
		
		int pgIndex = 2;
		
		for(String dataset: datasets){
			String dataDir = inDir+"/"+dataset;
			double[][] isEp = new double[isSize][noIterations];
			int isCount = usSize*noRuns;
			double[][] usEp = new double[usSize][noIterations];
			int usCount = isSize*noRuns;
			
			for(int isIndex=0;isIndex<isSize;isIndex++){
				for(int usIndex=0;usIndex<usSize;usIndex++){
					//scan for each run
					for(int runIndex=1;runIndex<=noRuns;runIndex++){
						Scanner sc = new Scanner(new File(dataDir+"/Output_"+runIndex+"_"+isIndex+"_"+pgIndex+"_"+usIndex+".txt"));
						int iterIndex = 0;
						while(sc.hasNextLine()){
							String line = sc.nextLine();
							if(line.startsWith("Iteration")){
								line = sc.nextLine();
								double fitness = Double.parseDouble(line.split(":")[1].trim());
								if(fitness<0){
									if(dataset.equalsIgnoreCase("sento1"))
										fitness = 6000;
									else if(dataset.equalsIgnoreCase("weish23"))
										fitness = 6000;
								}
								isEp[isIndex][iterIndex] += fitness;
								usEp[usIndex][iterIndex] += fitness;
								iterIndex++;
							}
						}
						sc.close();
					}
				}
			}
			
			
			PrintStream pt = new PrintStream(new File(outDir+"/is/"+dataset+".txt"));
			pt.println("is,iteration,fitness");
			for(int i=0;i<isEp.length;i++){
				for(int j=0;j<isEp[0].length;j++){
					isEp[i][j] = isEp[i][j]/isCount;
					pt.println(isValues[i]+","+j+","+isEp[i][j]);
				}
			}
			
			pt.close();
			
			pt = new PrintStream(new File(outDir+"/us/"+dataset+".txt"));
			pt.println("us,iteration,fitness");
			for(int i=0;i<usEp.length;i++){
				for(int j=0;j<usEp[0].length;j++){
					usEp[i][j] = usEp[i][j]/usCount;
					pt.println(uTimes[i]+","+j+","+usEp[i][j]);
				}
			}
			
			pt.close();
		}
	}
	
}
