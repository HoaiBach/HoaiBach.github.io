package Optimization;

public class ParaDynamic {
	int isUpIndex,alphaIndex,usLowIndex;

	public ParaDynamic(int isUpIndex, int usLowIndex, int alphaIndex){
		this.isUpIndex = isUpIndex;
		this.usLowIndex = usLowIndex;
		this.alphaIndex = alphaIndex;
	}
	
	public String toString(){		
		String toReturn = "isUp= "+isUpIndex+", usLow= "+usLowIndex+", alpha= "+ this.alphaIndex;
		return toReturn;
	}
	
	public String toStringValue(){

		double[] isValues = new double[]{5,6,7,8,9,10};
		double[] alphaValues = new double[]{0.5,0.6,0.7,0.8,0.9,1.0};
		int[] usValues = new int[]{1,5,10,15,20};
		
		String toReturn = "isUp= "+isValues[isUpIndex]+", usLow= "+usValues[usLowIndex]+", alpha= "+ alphaValues[this.alphaIndex];
		return toReturn;
	}
}
