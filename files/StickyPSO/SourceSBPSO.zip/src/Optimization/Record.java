package Optimization;


public class Record implements Comparable<Record>{
	double ave;
	double std;
	double max;
	double min;
	public Record(double ave, double std){
		this.ave = ave;
		this.std = std;
	}

	@Override
	public int compareTo(Record other) {
		if(this.ave > other.ave)
			return 1;
		if(this.ave == other.ave){
			if(this.std < other.std)
				return 1;
			if(this.std == other.std)
				return 0;
			if(this.std > other.std)
				return -1;
		}
		return -1;
	}

	public String toString(){
		return "Average: "+ave+", Std: "+std;
	}

}