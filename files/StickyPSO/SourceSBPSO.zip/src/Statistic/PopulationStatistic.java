package Statistic;

import java.util.ArrayList;
import java.util.List;

public class PopulationStatistic {

	/**
	 * Calculate the mean distance between particles in pop
	 * @param pop
	 * @return
	 */
	public static double mutualDistancePop(List<List<Double>> pop){
		double dis =0;
		for(int i=0;i<pop.size();i++){
			for(int j=0;j<pop.size();j++){
				if(i!=j)
					dis += listDistance(pop.get(i),pop.get(j));
			}
		}
		return dis/(pop.size()*(pop.size()-1));
	}
	
	public static double listDistance(List<Double> l1, List<Double> l2){
		double dis = 0;
		int length = l1.size() <= l2.size()? l1.size():l2.size();
		for(int i=0;i<length;i++){
			dis += (l1.get(i)-l2.get(i))*(l1.get(i)-l2.get(i));
		}
		dis = Math.sqrt(dis);
		return dis;
	}
	
	public static double factorOfPop(List<List<Double>> pop,int bestIndex){
		//distances from an ind to others
		double[] distances = new double[pop.size()];
		
		//fill the distnaces
		for(int i=0;i<pop.size()-1;i++){
			for(int j=i+1;j<pop.size();j++){
				double distance_i_j = listDistance(pop.get(i), pop.get(j));
				distances[i] += distance_i_j;
				distances[j] += distance_i_j;
			}
		}
		
		//find the max, and min
		double dmax = -Double.MAX_VALUE;
		double dmin = Double.MAX_VALUE;
		for(int i=0;i<pop.size();i++){
			distances[i] = distances[i]/pop.size()-1;
			if(dmax <distances[i])
				dmax = distances[i];
			if(dmin > distances[i])
				dmin = distances[i];
		}
		
		//the distance of best particle
		double d_g = distances[bestIndex];
		
		return (d_g-dmin)/(dmax-dmin);		
	}
	
}
