package Applications;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.plaf.FileChooserUI;

public class GridKnapsack {

	public static void main(String[] args) throws Exception{
		String[] datasets = new String[]{"gk01"};
//		List<String> datasets = new ArrayList<String>();
//		for(int i=1;i<=2;i++){
//			datasets.add("sento"+i);//(i<=9? "0"+i:i)
//		}
		for(String dataset: datasets){
			Files.copy(new File("/Users/nguyenhoai2/Documents/Datasets/KnapSack/"+dataset+"/data.dat").toPath(), 
					new File("/Users/nguyenhoai2/Documents/Eclipse/SwarmAlgorithm/data.dat").toPath(),
					StandardCopyOption.REPLACE_EXISTING);

			double ave=0;
			int noRuns = 1;
			for(int i=1;i<=noRuns;i++){
				MainKnapSack.main(new String[]{i+"" ,"1000", "2"});
				File file = new File("Output_"+i+".txt");
				Scanner sc= new Scanner(file);
				while(sc.hasNextLine()){
					String line = sc.nextLine();
					if(line.startsWith("Optimal"))
						break;
				}
				String line = sc.nextLine();
				ave += Double.parseDouble(line.split(",")[0].trim());
				sc.close();
				file.delete();
			}
			System.out.println(dataset+":"+ave/noRuns);
		}
	}
}
