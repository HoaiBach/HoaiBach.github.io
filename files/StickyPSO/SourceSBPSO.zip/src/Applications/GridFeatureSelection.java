package Applications;

import java.io.File;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

public class GridFeatureSelection {

	public static void main(String[] args) throws Exception{
		String[] datasets = new String[]{"Colon","SRBCT","Leukemia1","DLBCL","9Tumor","Brain1"};
		int[] methodIndices = new int[]{1,2,3,4,5,6};
		PrintStream pt = new PrintStream(new File("Output.txt"));
		for(String dataset: datasets){
			pt.println("========"+dataset+"========");
			for(int methodIndex: methodIndices){
				String method ="";
				if(methodIndex==1)
					method = "Static";
				if(methodIndex==2)
					method = "Dynamic";
				if(methodIndex==3)
					method = "Up";
				if(methodIndex==4)
					method = "Quantum";
				if(methodIndex==5)
					method = "Time";
				if(methodIndex==6)
					method ="NMBDE";
				
				Files.copy(new File("/Users/nguyenhoai2/Documents/Datasets/BigFeatureSelection/"+dataset+"/Data.data").toPath(), 
						new File("/Users/nguyenhoai2/Documents/Eclipse/SwarmAlgorithm/Data.data").toPath(),
						StandardCopyOption.REPLACE_EXISTING);

				Files.copy(new File("/Users/nguyenhoai2/Documents/Datasets/BigFeatureSelection/"+dataset+"/noFeatures.txt").toPath(), 
						new File("/Users/nguyenhoai2/Documents/Eclipse/SwarmAlgorithm//noFeatures.txt").toPath(),
						StandardCopyOption.REPLACE_EXISTING);

				double ave=0;
				int noRuns = 10;
				for(int i=1;i<=10;i++){

					MainFeatureSelection.main(new String[]{i+"" ,"100", methodIndex+""});
					File file = new File("Output_"+i+".txt");
					Scanner sc= new Scanner(file);
					while(sc.hasNextLine()){
						String line = sc.nextLine();
						if(line.startsWith("Size"))
							break;
					}
					String line = sc.nextLine();
					ave += Double.parseDouble(line.split(",")[3].trim());
					sc.close();
					file.delete();
				}
				pt.println(method+":"+ave/noRuns);
			}
		}
		pt.close();
	}
}
