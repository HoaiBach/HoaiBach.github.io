package Applications;

import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import Core.Individual;
import Core.Initializer;
import DE.DESwarm;
import DE.DESwarm.DEType;
import PSO.Swarm.Swarm;
import PSO.Swarm.Swarm.ParticleType;
import PSO.Topology.Topology;
import PSO.Topology.TopologyStar;
import Problem.Problem;
import Problem.FeatureSelection.FeatureSelection;
import Problem.FeatureSelection.HelpDataset;
import Problem.FeatureSelection.MainHelp;
import Problem.FeatureSelection.MyClassifier;
import Utility.RandomSeed;
import Utility.Utility;
import net.sf.javaml.core.Dataset;


public class MainFeatureSelection {

	/**
	 * 
	 * @param args: 1st: run, 2nd: maxIterations, 3rd type of algorithm
	 * @throws Exception 
	 */
	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception{
		int r = Integer.parseInt(args[0]);
		int noIterations = Integer.parseInt(args[1]);
		int algorithmTypes = Integer.parseInt(args[2]);

		/**
		 * 0: standard PSO
		 * 1: Static sticky PSO
		 * 2: Dynamc sticky PSO
		 * 3: Up BPSO
		 * 4: Quantum BPSO
		 * 5: Time varying BPSO
		 * 6: NMBDE
		 */

		long seeder = (long) (Math.pow(10, 6)*(r+3));
		RandomSeed.Seeder.setSeed(seeder);

		/** start PSO    */
		//seed for constant results PSO
		Random initRandom = RandomSeed.Create();

		//Construct the dataset.
		int noFeatures = MainHelp.noFeature();
		Dataset[] trainTest = MainHelp.readBingData(noFeatures);
		Dataset training = trainTest[0];
		Dataset testing = trainTest[1];

		//Construct the classifier.
		MyClassifier myclassifier = new MyClassifier();
		myclassifier.ClassifierBingKNN();

		// Construct the problem
		Problem fs = new FeatureSelection(training,testing,0.6);
		((FeatureSelection)fs).setClassifier(myclassifier);

		//create initializer
		@SuppressWarnings("unused")
		Initializer init = new Initializer(initRandom,fs);

		//write full set results
		double fullTrain = myclassifier.fullclassify(training, training);
		double fullTest = myclassifier.fullclassify(training, testing);

		File out = new File("Output_" +r+ ".txt");
		PrintStream pt = new PrintStream(out);
		pt.println("fullSet.Trainacc() " + fullTrain);
		pt.println("fullSet.Testacc()   " + fullTest);
		pt.println("no features:" +noFeatures);

		int noParticles;
		if(noFeatures>100)
			noParticles = 100;
		else
			noParticles = noFeatures;

		long startTime = 0;

		//to store the value during running time
		double[] fitnessArray = new double[noIterations];
		double[][] positions = new double[noIterations][noFeatures];
		List<Double> bestPosition= null;
		double bestFitness = fs.getWorstFitness();

		if(algorithmTypes <= 5){
			Topology topology = new TopologyStar();
			Swarm s = null;
			if(algorithmTypes == 0)
				s = new Swarm(noFeatures, ParticleType.Standard, 
						noParticles, topology, noIterations, fs);
			else if(algorithmTypes == 1)
				s = new Swarm(noFeatures, ParticleType.StaticSticky, 
						noParticles, topology, noIterations, fs);
			else if(algorithmTypes == 2)
				s = new Swarm(noFeatures, ParticleType.DynamicSticky, 
						noParticles, topology, noIterations, fs);
			else if(algorithmTypes == 3)
				s = new Swarm(noFeatures, ParticleType.Up, 
						noParticles, topology, noIterations, fs);
			else if(algorithmTypes == 4)
				s = new Swarm(noFeatures, ParticleType.Quantum, 
						noParticles, topology, noIterations, fs);
			else if(algorithmTypes == 5)
				s = new Swarm(noFeatures, ParticleType.TimeVarying, 
						noParticles, topology, noIterations, fs);
			else
			{
				System.out.println("Not implemented yet");
				System.exit(0);
			}

			//Initialize swarm.
			s.initialize();

			//start run PSO
			startTime = System.currentTimeMillis();
			for (int i = 0; i < noIterations; ++i) {
				s.iterate();
				fitnessArray[i] = s.getPopulation().get(0).getGbestFitness();
				bestPosition = Utility.copyList(s.getPopulation().get(0).getGbestPosition());
				positions[i] = fs.positionToArray(bestPosition);
			}
			bestPosition = s.getPopulation().get(0).getGbestPosition();
			bestFitness = s.getPopulation().get(0).getGbestFitness();
			//end all iterations
		}
		else if(algorithmTypes>5){
			DESwarm swarm = null;
			if(algorithmTypes == 6)
				swarm = new DESwarm(noFeatures, DEType.NMBDE, 
						noParticles, noIterations,fs);
			else{
				throw new Exception("Not implemented yet");
			}

			swarm.initialize();
			startTime = System.currentTimeMillis();
			for(int i=0; i<noIterations;i++){
				Individual bestInd = swarm.getBestIndividual();
				bestFitness = bestInd.getFitness();
				bestPosition = Utility.copyList(bestInd.getPosition());
				fitnessArray[i] = bestFitness;
				positions[i] = fs.positionToArray(bestPosition);
				swarm.iterate();
			}
			//note DE does not use the best individual for the interation (noIterations)
			//to ensure a fair comparison with PSO
		}

		// ****************** Results of the r-th Run  ***********************
		long estimatedTime = System.currentTimeMillis() - startTime;
		double[] features = ((FeatureSelection)fs).positionToFeatures(bestPosition);
		double fitness = bestFitness;

		Dataset newTrain = HelpDataset.removeFeatures(training.copy(), features);
		Dataset newTest = HelpDataset.removeFeatures(testing.copy(), features);
		double trainAcc = myclassifier.classify(newTrain, newTrain);
		double testAcc = myclassifier.classify(newTrain, newTest);
		int size = MainHelp.sizeSubset(features);


		//File file = new File(String.valueOf("Run"+Integer.valueOf(args[0]) + 1) + ".txt");   // for grid use  ** be carefull !!!!
		pt.println("===========================================================");
		for(int i=0;i<noIterations;i++){
			pt.println("Iteration "+i+":");
			pt.println("Fitness: "+fitnessArray[i]);
			pt.println("Features: "+Arrays.toString(positions[i]));
			pt.println("===========================================================");
		}
		pt.println("Size, TrainAcc, TestAcc, Fitness, RunningTime");
		pt.println(size+", "+twoDecimal(trainAcc*100)+", "+twoDecimal(testAcc*100)+","+
				fitness+", "+estimatedTime);
		pt.println(Arrays.toString(features));
		pt.close();


		/*
	//analyse the mutation rates of each particle.
	double[][][] mutateRates = s.getMutateRates();
	//print for the first particle: iteration and mutate for each index
	File file = new File("rateFirst.txt");
	int maxNoF = noFeatures > 10 ? 10: noFeatures;
	pt = new PrintStream(file);
	pt.print("Iteration");
	for(int j=0;j<maxNoF;j++){
		pt.print(",F"+j);
	}
	for(int i=0;i<noIterations;i++){
		pt.println();
		pt.print(i);
		for(int j=0;j<maxNoF;j++){
			pt.print(","+twoDecimal(mutateRates[i][0][j]));
		}
	}
	pt.close();

	//analyse the mutation rates of all particlse.
	mutateRates = s.getMutateRates();
	//print for the first particle: iteration and mutate for each index
	file = new File("rateAverage.txt");
	pt = new PrintStream(file);
	pt.print("Iteration");
	for(int j=0;j<maxNoF;j++){
		pt.print(",F"+j);
	}
	for(int i=0;i<noIterations;i++){
		pt.println();
		pt.print(i);
		for(int j=0;j<maxNoF;j++){
			double average =0;
			for(int k=0;k<noParticles;k++){
				average+= mutateRates[i][k][j];
			}
			average = twoDecimal(average/noParticles);
			pt.print(","+average);
		}
	}
	pt.close();
		 */

	}

	public static double twoDecimal(double s){
		return (int)(s*100+0.5)/100.0;
	}
}
