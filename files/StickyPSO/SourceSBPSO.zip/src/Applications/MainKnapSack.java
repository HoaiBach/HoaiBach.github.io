package Applications;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import Core.Individual;
import Core.Initializer;
import DE.DESwarm;
import DE.DESwarm.DEType;
import DE.Individual.DEIndividual;
import PSO.Particle.Particle;
import PSO.Swarm.Swarm;
import PSO.Swarm.Swarm.ParticleType;
import PSO.Topology.Topology;
import PSO.Topology.TopologyStar;
import Problem.Knapsack.Knapsack;
import Statistic.PopulationStatistic;
import Utility.RandomSeed;
import Utility.Utility;
public class MainKnapSack {

	/**
	 *
	 * @param args: 1st: run, 2nd: maxIterations, 3rd: type of algorithm
	 * 
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		int r = Integer.parseInt(args[0]);
		int noIterations = Integer.parseInt(args[1]);
		int algorithmTypes = Integer.parseInt(args[2]);
		boolean analysis= true;
		/**
		 * 1: Static sticky PSO
		 * 2: Dynamc sticky PSO
		 * 3: Up BPSO
		 * 4: Quantum BPSO
		 * 5: Time varying BPSO
		 * 6: NMBDE
		 */

		long seeder = (long) (Math.pow(10, 6)*(r+3));
		RandomSeed.Seeder.setSeed(seeder);

		Random initRandom = RandomSeed.Create();

		//Construct the classifier.
		//note noDim is the number of costs
		Knapsack problem = new Knapsack(0.5);
		int noItems = problem.getNoItems();
		int optimal = problem.getOptimal();
		int noDim = problem.getNoDim();

		//create initializer
		Initializer init = new Initializer(initRandom,problem);
		int noParticles = noItems<=100? noItems:100;

		File out = new File("Output_" +r+ ".txt");
		PrintStream pt = new PrintStream(out);
		pt.println("#items #optimal #dimension");
		pt.println(noItems+" "+optimal +" "+noDim);

		/** start PSO    */
		//seed for constant results PSO

		//construct swarm

		long startTime=0;

		//to store the value during running time
		double[] fitnessArray = new double[noIterations];
		double[][] positions = new double[noIterations][noItems];
		//		double[] diversity = new double[noIterations];
		double[] factor = new double[noIterations];
		List<Double> bestPosition= null;
		double bestFitness = problem.getWorstFitness();

		if(algorithmTypes <= 5){
			Topology topology = new TopologyStar();
			Swarm s = null;
			if(algorithmTypes == 1)
				s = new Swarm(noItems, ParticleType.StaticSticky, 
						noParticles, topology, noIterations, problem);
			else if(algorithmTypes == 2)
				s = new Swarm(noItems, ParticleType.DynamicSticky, 
						noParticles, topology, noIterations, problem);
			else if(algorithmTypes == 3)
				s = new Swarm(noItems, ParticleType.Up, 
						noParticles, topology, noIterations, problem);
			else if(algorithmTypes == 4)
				s = new Swarm(noItems, ParticleType.Quantum, 
						noParticles, topology, noIterations, problem);
			else if(algorithmTypes == 5)
				s = new Swarm(noItems, ParticleType.TimeVarying, 
						noParticles, topology, noIterations, problem);
			else
			{
				System.out.println("Not implemented yet");
				System.exit(0);
			}

			//Initialize swarm.
			s.initialize();

			//start run PSO
			startTime = System.currentTimeMillis();
			for (int i = 0; i < noIterations; ++i) {
				//				if(analysis)
				//				{
				//					int bestIndex = -1;
				//					List<List<Double>> pops = new ArrayList<List<Double>>();
				//					for(Particle p:s.getPopulation()){
				//						pops.add(p.getPosition());
				//					}
				//					diversity[i] = getDiversity(pops);
				//				}
				s.iterate();

				if(analysis)
				{
					int bestIndex = -1;
					List<List<Double>> pops = new ArrayList<List<Double>>();
					for(int pIndex=0;pIndex<s.getPopulation().size();pIndex++){
						Particle p = s.getPopulation().get(pIndex);
						pops.add(p.getPosition());
						if(bestIndex<0 && p.getPbestFitness()==p.getGbestFitness())
							bestIndex = pIndex;
					}
					factor[i] = PopulationStatistic.factorOfPop(pops, bestIndex);
				}

				fitnessArray[i] = s.getPopulation().get(0).getGbestFitness();
				bestPosition = Utility.copyList(s.getPopulation().get(0).getGbestPosition());
				positions[i] = problem.positionToArray(bestPosition);
			}
			bestPosition = s.getPopulation().get(0).getGbestPosition();
			bestFitness = s.getPopulation().get(0).getGbestFitness();
			//end all iterations
		}
		else if(algorithmTypes >5){
			DESwarm swarm = null;
			if(algorithmTypes == 6)
				swarm = new DESwarm(noItems, DEType.NMBDE, 
						noParticles, noIterations,problem);
			else{
				throw new Exception("Not implemented yet");
			}

			swarm.initialize();

			startTime = System.currentTimeMillis();
			for(int i=0; i<noIterations;i++){
				//				if(analysis)
				//				{
				//					List<List<Double>> pops = new ArrayList<List<Double>>();
				//					for(DEIndividual ind:swarm.getPop()){
				//						pops.add(ind.getPosition());
				//					}
				//					diversity[i] = PopulationStatistic.factorOfPop(pops, bestIndex);
				//				}

				Individual bestInd = swarm.getBestIndividual();
				bestFitness = bestInd.getFitness();
				bestPosition = Utility.copyList(bestInd.getPosition());
				fitnessArray[i] = bestFitness;
				positions[i] = problem.positionToArray(bestPosition);
				swarm.iterate();

				if(analysis)
				{
					int bestIndex = swarm.getBestIndex();
					List<List<Double>> pops = new ArrayList<List<Double>>();
					for(DEIndividual ind: swarm.getPop()){
						pops.add(ind.getPosition());
					}
					factor[i] = PopulationStatistic.factorOfPop(pops, bestIndex);
				}
			}
			//note DE does not use the best individual for the interation (noIterations)
			//to ensure a fair comparison with PSO
		}

		//print analysis
		//		if(analysis){
		//			PrintStream ptA = new PrintStream(new File("diversity_"+r+".txt"));
		//			for(int i=0;i<noIterations;i++){
		//				ptA.println("Iteration "+i+":");
		//				ptA.println("Diversity: "+diversity[i]);
		//				ptA.println("===========================================================");
		//			}
		//			ptA.close();
		//		}
		if(analysis){
			PrintStream ptF = new PrintStream(new File("factor_"+r+".txt"));
			for(int i=0;i<noIterations;i++){
				ptF.println("Iteration "+i+":");
				ptF.println("Factor: "+factor[i]);
				ptF.println("===========================================================");
			}
			ptF.close();
		}

		// ****************** Results of the r-th Run  ***********************
		long estimatedTime = System.currentTimeMillis() - startTime;
		double[] features = problem.positionToArray(bestPosition);

		//File file = new File(String.valueOf("Run"+Integer.valueOf(args[0]) + 1) + ".txt");   // for grid use  ** be carefull !!!!
		pt.println("===========================================================");
		int lap = noIterations/100;
		for(int i=0;i<noIterations;i=i+lap){
			pt.println("Iteration "+i+":");
			pt.println("Fitness: "+fitnessArray[i]);
			pt.println("Features: "+Arrays.toString(positions[i]));
			pt.println("===========================================================");
		}

		pt.println("Iteration "+(noIterations-1)+":");
		pt.println("Fitness: "+fitnessArray[noIterations-1]);
		pt.println("Features: "+Arrays.toString(positions[noIterations-1]));
		pt.println("===========================================================");

		pt.println("Optimal, Penalty, RunningTime");
		pt.println(bestFitness+", "+problem.calculatePenalty(bestPosition)+", "+estimatedTime);
		pt.println(Arrays.toString(features));
		pt.close();

		/*
		String outDir = "/Users/Mochi/Documents/Eclipse/PhDStudy/BinaryParticleSwarmOptimisation/ToPlot/Testing/";
		PrintStream pt1;
		if(testing){
			pt =  new PrintStream(new File(outDir+"rate1First.txt"));
			pt1 = new PrintStream(new File(outDir+"velocityFirst.txt"));
			//go through each item
			Particle p = s.getSwarm().get(0);
			for(int i=0;i<noIterations;i++){
				pt.print(i+"\t");
				pt1.print(i+"\t");
				for(int j=0;j<noItems;j++){
					pt.print(p.rate1[i][j]+"\t");
					pt1.print(p.vmemo[i][j]+"\t");
				}
				pt.println();
				pt1.println();
			}
			pt.close();
			pt1.close();

			pt =  new PrintStream(new File(outDir+"rate1Ave.txt"));
			pt1 = new PrintStream(new File(outDir+"velocityAve.txt"));
			for(int i=0;i<noIterations;i++){
				pt.print(i+"\t");
				pt1.print(i+"\t");
				for(int j=0;j<noItems;j++){
					double sumRate = 0;
					double sumVelo = 0;
					for(Particle ps:s.getSwarm()){
						sumRate += ps.rate1[i][j];
						sumVelo += ps.vmemo[i][j];
					}
					pt.print(sumRate / s.getSwarmSize()+"\t");
					pt1.print(sumVelo / s.getSwarmSize()+"\t");
				}
				pt.println();
				pt1.println();
			}
			pt.close();
			pt1.close();

		}*/
	}

	public static double twoDecimal(double s){
		return (int)(s*100+0.5)/100.0;
	}

	public static double getDiversity(List<List<Double>> pop){
		double distance = 0;
		for(int i=0;i<pop.size();i++){
			for(int j=0;j<pop.size();j++){
				if(i!=j){
					distance += getDistance(pop.get(i),pop.get(j));
				}
			}
		}
		int size = pop.size();
		distance = distance/(size*(size-1));
		return distance;
	}

	public static double getDistance(List<Double> ind1, List<Double> ind2){
		double distance = 0;
		for(int i=0;i<ind1.size();i++){
			distance += (ind1.get(i)-ind2.get(i))*(ind1.get(i)-ind2.get(i));
		}
		distance = Math.sqrt(distance);
		return distance;
	}
}
