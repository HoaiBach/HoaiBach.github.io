package DE.Individual;

import Core.Individual;
import Problem.Problem;

public abstract class DEIndividual extends Individual {

	public DEIndividual(boolean isBinary, Problem problem, int length) {
		super(isBinary, problem, length);
	}

	public abstract void updatePosition();
	public abstract void initialize();

}
