package DE.Individual;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Core.Initializer;
import DE.DEMating;
import Problem.Problem;
import Utility.RandomSeed;

public class NMBDEIndividual extends DEIndividual {

	private DEMating selector;
	private double F = 0.8, CR = 0.2, b =20;
	private Random rnd = RandomSeed.Create();
	
	public NMBDEIndividual(Problem problem, int length, DEMating selector) {
		super(true, problem, length);
		this.selector = selector;
	}
	
	public void initialize() {
		Initializer.initializeOpposite(this);
	}

	public void updatePosition() {
		List<Double> mutant = mutate();
		List<Double> trial = crossover(mutant);
		
		//selection between the trial and the current
		double trialFitness = problem.fitness(trial);
		if(problem.isBetter(trialFitness, this.fitness)){
			this.setPosition(trial);
			this.setFitness(trialFitness);
		}
	}
	
	public List<Double> mutate(){
		List<Integer> parents = selector.StandardRandomOne();
		int r1 = parents.get(0);
		int r2 = parents.get(1);
		int r3 = parents.get(2);
		
		List<DEIndividual> pop = selector.getSwarm().getPop();
		
		//perform mutation
		List<Double> r1Position = pop.get(r1).getPosition();
		List<Double> r2Position = pop.get(r2).getPosition();
		List<Double> r3Position = pop.get(r3).getPosition();
		
		List<Double> newPosition = new ArrayList<Double>();
		
		for(int j=0;j<r1Position.size();j++){
			double MO = r1Position.get(j)+F*(r2Position.get(j)-r3Position.get(j));
			double prob = 1.0/(1.0+Math.exp(-2*b*(MO-0.5)/(1+2*F)));
			double newEntry;
			if(rnd.nextDouble()<=prob)
				newEntry = 1.0;
			else
				newEntry = 0.0;
			newPosition.add(newEntry);
		}
		
		return newPosition;
	}

	public List<Double> crossover(List<Double> mutant){
		List<Double> newPosition = new ArrayList<Double>();
		
		//ensure at least one entry is from the mutant vector
		int mustCrossover = rnd.nextInt(this.length);
		
		for(int j=0; j<mutant.size(); j++){
			if( j==mustCrossover || rnd.nextDouble() <= CR)
				newPosition.add(mutant.get(j));
			else
				newPosition.add(this.position.get(j));
		}
		
		return newPosition;
	}

}
