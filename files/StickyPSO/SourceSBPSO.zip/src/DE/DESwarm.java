package DE;

import java.util.ArrayList;
import java.util.List;

import Core.Individual;
import DE.Individual.DEIndividual;
import DE.Individual.NMBDEIndividual;
import Problem.Problem;

public class DESwarm {
	protected Problem problem;
	protected List<DEIndividual> pop;

	protected int size,length;
	protected int maxIteration;
	protected DEType type;
	
	public enum DEType{
		NMBDE, BDE;
	}
	
	public DESwarm(int length, DEType type,
			int size, int maxIteration, Problem problem){
		this.length = length;
		this.type = type;
		this.size = size;
		this.maxIteration = maxIteration;
		this.problem = problem;
	}
	
	//to do, initialize each individual
	public void initialize(){
		pop = new ArrayList<DEIndividual>();
		for(int i=0;i<this.size;i++){
			DEIndividual ind = null;
			DEMating mating = new DEMating(i, this);
			
			switch (type){
			case NMBDE:
				ind = new NMBDEIndividual(problem, length, mating);
				break;
			
			default:
				try {
					throw new Exception("Not implementedyet");
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(0);
				}
				break;
			}
			
			ind.initialize();
			pop.add(ind);
		}
	}
	
	public void iterate(){
		for(int i=0;i<size;i++){
			DEIndividual ind = pop.get(i);
			
			//no need to evaluate the individual here
			//since its evaluation is done for the trial
			//once the position is updated, its fitness is updated too
			ind.updatePosition();
		}
	}
	
	public List<DEIndividual> getPop(){
		return this.pop;
	}
	
	public Individual getBestIndividual(){
		Individual bestInd = null;
		double bestFitness = problem.getWorstFitness();
		
		for(Individual ind: pop){
			double fitness = ind.getFitness();
			if(problem.isBetter(fitness, bestFitness))
			{
				bestInd = ind;
				bestFitness = fitness;
			}
		}
		
		return bestInd;
	}
	
	public int getBestIndex(){
		int bestIndex = 0;
		double bestFitness = problem.getWorstFitness();
		
		for(int i=0;i<pop.size();i++){
			DEIndividual ind = pop.get(i);
			double fitness = ind.getFitness();
			if(problem.isBetter(fitness, bestFitness))
			{
				bestIndex = i;
				bestFitness = fitness;
			}
		}
		
		return bestIndex;
	}
	
}
