package DE;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Utility.RandomSeed;

public class DEMating {
	Random rnd = RandomSeed.Create();
	private int ownIndex;
	protected DESwarm swarm;
	
	public DEMating(int index, DESwarm swarm){
		this.ownIndex = index;
		this.swarm = swarm;
	}
	
	public List<Integer> StandardRandomOne(){
		
		//select random indices
		int r1=0,r2=0,r3=0;
		
		do{
			r1 = rnd.nextInt(swarm.size);
		}while(r1 == ownIndex);
		
		do{
			r2 = rnd.nextInt(swarm.size);
		}while(r2 == ownIndex || r2 == r1);
		
		do{
			r3 = rnd.nextInt(swarm.size);
		}while(r3 == ownIndex || r3 == r1 || r3 == r2 );
		
		List<Integer> indices = new ArrayList<Integer>();
		indices.add(r1);indices.add(r2);indices.add(r3);
		return indices;
	}
	
	public DESwarm getSwarm(){
		return this.swarm;
	}
}
