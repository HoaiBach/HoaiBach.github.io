package DE.Test;

import java.util.Arrays;

public class BinaryUtilities {

	/**
	 * 
	 * @param barray: array of binary numbers
	 * @param max: maxRange of the converted value
	 * @param min: minRange of the converted value
	 * @return a corresponding real value within given ranges
	 * the first bit is reserved for sign: 0- negative, 1-positive
	 * @throws Exception 
	 */
	public static double convert(double[] barray,double max, double min) throws Exception{
		double result=0;
		//first bit is sign.
		//decide maximum bit for decimal part
		int maxDec = (int) Math.ceil(Math.log(max)/Math.log(2));
		//assum that there must be at least maxDec+1 binary values to decide.
		if(barray.length < maxDec+1){
			throw new Exception("Not enough bits to represent value at range "+min+" - "+max);
		}
		assert (barray.length >= maxDec+1);
		for(int i=1;i<barray.length;i++){
			result+= Math.pow(2, maxDec-i)*barray[i];
		}
		result = Math.pow(-1, barray[0]+1)*result;
		return result;
	}
	
	public static double[] subArray(double[] origin, int start, int end){
		double[] tmp = new double[end-start];
		for(int i=start; i< end;i++){
			tmp[i-start] = origin[i];
		}
		return tmp;
	}
	
	public static void main(String[] args){
		double[] barray = new double[]{1,1,0,1,0,0,1};
		int max = 6;
		try {
			System.out.println(convert(barray,max,-max));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
