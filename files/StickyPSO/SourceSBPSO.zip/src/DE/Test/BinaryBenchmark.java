package DE.Test;

import Problem.Problem;

public abstract class BinaryBenchmark extends Problem{
	protected double maxRange,minRange;
	
	public BinaryBenchmark(double threshold) {
		super(threshold);
		this.setMaximised(false);
	}

	private int noVariables = 2;
	private int dimEach = 15;
	
	public int getNoVariables() {
		return noVariables;
	}

	public void setNoVariables(int noVariables) {
		this.noVariables = noVariables;
	}

	public int getDimEach() {
		return dimEach;
	}

	public void setDimEach(int dimEach) {
		this.dimEach = dimEach;
	}

}
