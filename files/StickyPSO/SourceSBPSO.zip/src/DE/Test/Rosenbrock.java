package DE.Test;

import java.util.Arrays;
import java.util.List;

public class Rosenbrock  extends BinaryBenchmark{
	public Rosenbrock(){
		super(0.5);
	}

	/**
	 * evaluate binary bit string
	 */
	public double fitness(double[] position) {
		double sum = 0.0;
		double[] values = new double[this.getNoVariables()];
		for(int i=0; i<this.getNoVariables();i++){
			double[] barray = BinaryUtilities.subArray(position, i*this.getDimEach(), (i+1)*this.getDimEach());
			double value = 0;
			try {
				value = BinaryUtilities.convert(barray, maxRange, minRange);
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}
			values[i] = value;
		}
		for(int i=0;i<this.getNoVariables()-1;i++){
			sum+= 100*((values[i+1]-values[i]*values[i])*(values[i+1]-values[i]*values[i])
					+(values[i]-1)*(values[i]-1));
		}
		return sum;
	}

	public double fitness(List<Double> position) {
		double[] arrPosition = new double[position.size()];
		for(int i=0;i<position.size();i++){
			if(position.get(i) > this.getThreshold())
				arrPosition[i] = 1.0;
			else
				arrPosition[i] = 0.0;
		}
		return fitness(arrPosition);
	}

}
