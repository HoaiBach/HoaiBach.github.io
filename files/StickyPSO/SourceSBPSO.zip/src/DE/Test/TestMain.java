package DE.Test;

import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import Core.Individual;
import Core.Initializer;
import DE.DESwarm;
import DE.DESwarm.DEType;
import Utility.RandomSeed;

public class TestMain {

	public static void main(String[] args) throws Exception{
		BinaryBenchmark prob = new Rosenbrock();
		prob.maxRange = 2.047;
		prob.minRange = -2.047;
		prob.setNoVariables(30);
		prob.setDimEach(20);
		
		int run = Integer.parseInt(args[0]);
		long seeder = (long) (Math.pow(10, 6)*(run+3));
		RandomSeed.Seeder.setSeed(seeder);
		
		Random initRandom = RandomSeed.Create();
		Initializer init = new Initializer(initRandom, prob);

		int maxIterations = 5000;
		int step = maxIterations/100;
		
		DESwarm swarm = new DESwarm(
				prob.getNoVariables()*prob.getDimEach(),
				DEType.NMBDE, 200, maxIterations, prob);
		swarm.initialize();
		
		int index = 0;
		double[] records = new double[101];
		
		//
		System.out.println("Number of variables: "+ prob.getNoVariables());
		System.out.println("Dimension: "+swarm.getPop().get(0).getLength());
		
		for(int i=0;i<maxIterations;i++){
			if(i%step == 0 || i == maxIterations-1){
				records[index] = swarm.getBestIndividual().getFitness();
				index++;
			}
			System.out.println(i);
			swarm.iterate();
		}
		
		PrintStream pt = new PrintStream(new File("result.txt"));
		for(int i=0;i<records.length-1;i++){
			pt.println(i*100+": "+records[i]);
		}
		
		List<Double> bestPosition = swarm.getBestIndividual().getPosition();
		double[] solution = new double[bestPosition.size()];
		for(int i=0;i<solution.length;i++)
			solution[i] = bestPosition.get(i);
		double[] variables = new double[prob.getNoVariables()];
		for(int i=0;i<variables.length;i++){
			double[] sub = BinaryUtilities.subArray(solution, i*prob.getDimEach(), (i+1)*prob.getDimEach());
			variables[i] = BinaryUtilities.convert(sub, prob.maxRange, prob.minRange);
		}
				
				
		
		pt.println(Arrays.toString(variables));
		pt.close();
	}
}
