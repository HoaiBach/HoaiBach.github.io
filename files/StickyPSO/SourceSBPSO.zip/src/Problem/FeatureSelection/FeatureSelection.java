package Problem.FeatureSelection;

import java.util.List;
import java.util.Random;

import Problem.Problem;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;

public class FeatureSelection extends Problem{
	
	@SuppressWarnings("unused")
	private Dataset training, test;
	private MyClassifier classifier;
	
	
	public FeatureSelection(Dataset training, Dataset test, double threshold) {
		super(threshold);
		//minimise the error.
		this.setMaximised(false);
		this.training = training;
		this.test = test;
	}

	/**
	 * Count the number of selected features
	 * @param position
	 * @return
	 */
	public int  selectedFeature(double[] position){
		int count =0;
		for(int i=0;i<position.length;i++){
			if(position[i] ==1.0)
				count++;
		}
		return count;
	}
	
	public double[] positionToFeatures(List<Double> position){
		double[] features = new double[position.size()];
		for(int i=0;i<position.size();i++){
			if(position.get(i)>this.getThreshold()){
				features[i] = 1.0;
			}
			else{
				features[i] = 0.0;
			}
		}
		return features;
	}

	public double fitness(List<Double> position) {
		double fitness = 0;
		double weight = 0.98;
		Dataset temTrain = this.training.copy();
		double[] features = positionToFeatures(position);
		int noSelected = selectedFeature(features);
		
		if(noSelected == 0){
			return this.getWorstFitness();
			}

		temTrain = HelpDataset.removeFeatures(temTrain, features);

		Dataset[] foldsTem = temTrain.folds(10, new Random(1));
		double accuracy = 0.0;
		for (int f = 0; f < 10 ; f++) {
			Dataset testTem = foldsTem[f];
			Dataset trainTem = new DefaultDataset();
			for (int j = 0; j < 10; j++) {
				if (j != f) {
					trainTem.addAll(foldsTem[j]);
				}
			}
			accuracy += this.getClassifier().classify(trainTem, testTem);
		}
		fitness = weight*(1.0 - accuracy/ 10)+(1-weight)*noSelected/(features.length+0.0);
		return fitness;
	}

	public MyClassifier getClassifier() {
		return classifier;
	}

	public void setClassifier(MyClassifier classifier) {
		this.classifier = classifier;
	}

}
