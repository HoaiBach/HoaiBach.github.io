package Problem.FeatureSelection;

public class Results {

	public double[] trainaccs;
	public double[] testaccs;
	public double[] sizes;
	public double[][] fitness; //iteration * run
	public double fullTrain,fullTest,fullSize;
	
	public int optimal,dimension,size;
	public double[] times;
	public double[][] fitnessSnap;
}
