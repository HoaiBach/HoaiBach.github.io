package Problem.FeatureSelection;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import Problem.Knapsack.Process.KnapsackResults;
import Utility.Helper;
import Utility.Utility;
import Utility.WilsonTestBing;

public class ExtractDataFeatureSelection {
	static int noRun = 30;
	static int noIteration = 100;
	static String dir = "FullResults/FeatureSelection";
	
	static Map<String,Map<String,Results>> datasetMethod = new HashMap<String,Map<String,Results>>();
	static List<String> methods = new ArrayList<String>();
	static List<String> datasets = new ArrayList<String>();

	public static void main(String[] args) throws FileNotFoundException{

		methods.add("NMBDE");
		methods.add("Quantum");
		methods.add("Up"); 
		methods.add("TimeVarying");
		methods.add("StaticS1"); 
		methods.add("DynamicS3");


		datasets.add("Wine");
		datasets.add("Australian");
		datasets.add("Zoo");
		datasets.add("Vehicle");
		datasets.add("German");
		datasets.add("WBCD");
		datasets.add("Ionosphere");
		datasets.add("Sonar");
		datasets.add("Movementlibras");
		datasets.add("Hillvalley");
		datasets.add("Musk1");
		datasets.add("Arrhythmia");
		datasets.add("Madelon");
		datasets.add("Isolet5");
		datasets.add("MultipleFeatures");

		ExtractData();
//		writeResults();
		printEvolutionaryProcess();
		
		List<String> masters = new ArrayList<String>();
		masters.add("StaticS1"); masters.add("DynamicS3");
		printSignificance(masters);
		
	}
	
	public static void ExtractData() throws FileNotFoundException{
		for(String dataset: datasets){
			System.out.println("Processing "+dataset+"....");
			Map<String,Results> methodResult = new HashMap<String,Results>();
			datasetMethod.put(dataset, methodResult);

			for(String method: methods){
				//for full results
				double fullTrain,fullTest,fullSize;

				//for each dataset
				double[] trainaccs = new double[noRun];
				double[] testaccs = new double[noRun];
				double[] sizes = new double[noRun];
				double[] times  = new double[noRun];
				double[][] fitness = new double[noIteration][noRun];

				Results result = new Results();
				result.trainaccs = trainaccs;
				result.testaccs = testaccs;
				result.sizes = sizes;
				result.times = times;
				result.fitness = fitness;

				methodResult.put(method, result);

				//start scanning
				for(int run=1;run<=noRun;run++){
					File output = new File(dir+"/"+dataset+"/"+method+"/Output_"+run+".txt");

					int index = run-1;
					Scanner sc = new Scanner(output);

					String line = sc.nextLine();
					//System.out.println(typeName+":"+run+":"+line);
					fullTrain = Double.parseDouble(line.split("\\s+")[1].trim());
					line = sc.nextLine();
					fullTest = Double.parseDouble(line.split("\\s+")[1].trim());
					line = sc.nextLine();
					fullSize = Double.parseDouble(line.split(":")[1].trim());

					//set to results
					if(run==1){
						result.fullTrain = fullTrain*100;
						result.fullTest = fullTest*100;
						result.fullSize = fullSize;
					}

					//now read results for each run
					sc.nextLine();
					int iteration = 0;
					while(sc.hasNextLine()){
						line  = sc.nextLine();
						//line for iteration results
						if(line.startsWith("Iteration")){
							line = sc.nextLine().split(":")[1].trim();
							if(iteration<noIteration){
								fitness[iteration][index] = 100*Double.parseDouble(line);
								iteration++;
							}
							sc.nextLine();
							sc.nextLine();
						}
						//line for run results
						else if(line.startsWith("Size")){
							line = sc.nextLine();
							String[] tmps = line.split(",");
							sizes[index] = Double.parseDouble(tmps[0].trim());
							trainaccs[index] = 
//																		100.0-(Double.parseDouble(tmps[3].trim())-0.1*sizes[index]/fullSize)/0.9*100;
									Double.parseDouble(tmps[1].trim());
							testaccs[index] = Double.parseDouble(tmps[2].trim());
							times[index] = Double.parseDouble(tmps[4].trim());
							break;
						}
					}

					sc.close();
				}
			}
		}
	}

	public static void writeResults() throws FileNotFoundException{
		NumberFormat aveformatter = new DecimalFormat("0.00");
		//print for toec
		
		int nomethods = methods.size();
		String colume = "l";
		String columeNoAll="";
		for(int i=0;i<nomethods+1;i++){
			columeNoAll+="ll";
		}
		colume += columeNoAll;
		String methodHead = " & All";
		String methodHeadNoAll="";
		for(String method: methods){
			if(method.equals("TimeVarying"))
				method ="TV";
			else if(method.equalsIgnoreCase("StaticS1"))
				method ="Stat";
			else if(method.equalsIgnoreCase("DynamicS3"))
				method="Dyn";
			methodHeadNoAll += " & "+method;
		}
		methodHead += methodHeadNoAll;
		methodHead += methodHead;

		PrintStream pt = new PrintStream(new File("ProcessResults/FeatureSelection/Latex/Result.tex"));
		pt.println("\\documentclass{report}\n"+
				"\\usepackage[cm]{fullpage}\n"+
				"\\usepackage{rotating}\n"+
				"\\usepackage{multirow}\n"+
				"\\begin{document}\n");

		String nfTrainTable = "\\begin{table}\n"
				+ "\\centering\n"
				+ "\\scriptsize\n"
				+ "\\caption{Training Accuracies on Feature Selection Problems.}\n"
				+ "\\begin{tabular}{"+colume+"}\n"
				+ "\\hline \n"
				+ "\\multirow{2}{*}{Dataset} & \\multicolumn{7}{c}{Number of selected features} &"
				+ "\\multicolumn{7}{c}{Training accuracies}\\\\\n"
				+ "\\cline{2-8} \\cline{9-15}"
				+ methodHead + "\\\\ \\hline \n";

		String timeTestTable = "\\begin{table}\n"
				+ "\\centering\n"
				+ "\\scriptsize\n"
				+ "\\caption{Testing Accuracies on Feature Selection Problems.}\n"
				+ "\\begin{tabular}{"+colume+"}\n"
				+ "\\hline \n"
				+ "\\multirow{2}{*}{Dataset} & \\multicolumn{7}{c}{Computational times (seconds)} &"
				+ "\\multicolumn{7}{c}{Testing accuracies}\\\\\n"
				+ "\\cline{2-8} \\cline{9-15}"
				+ methodHead + "\\\\ \\hline \n";


		for(String dataset: datasets){
			System.out.println("Writing "+dataset);

			nfTrainTable += dataset;
			timeTestTable += dataset;

			Map<String,Results> methodResult = datasetMethod.get(dataset);

			double[] fullTrainArray = new double[noRun];
			double[] fullTestArray = new double[noRun];

			String trainTable = " & "+aveformatter.format(methodResult.get("NMBDE").fullTrain);
			String testTable = " & "+aveformatter.format(methodResult.get("NMBDE").fullTest);
			String nfTable  = " & "+ aveformatter.format(methodResult.get("NMBDE").fullSize);
			String timeTable = "& N/A ";

			List<Double> train = new ArrayList<Double>();
			List<Double> test  = new ArrayList<Double>();
			List<Double> nf  = new ArrayList<Double>();
			List<Double> time = new ArrayList<Double>();
			
			for(String method: methods){
				Results result = methodResult.get(method);
				
				train.add(Helper.getMean(result.trainaccs));
				test.add(Helper.getMean(result.testaccs));
				nf.add(Helper.getMean(result.sizes));
				time.add(Helper.getMean(result.times)/1000);
			}
			
			List<Double> trainBest = Utility.findTopElements(train, 2, false);
			List<Double> testBest = Utility.findTopElements(test, 2, false);
			List<Double> nfBest = Utility.findTopElements(nf, 2, true);
			List<Double> timeBest = Utility.findTopElements(time, 2, true);
			
			//now print
			for(int i=0;i<methods.size();i++){
				double methodTrain = train.get(i);
				double methodTest = test.get(i);
				double methodNf = nf.get(i);
				double methodTime = time.get(i);

				trainTable += " & "+ convertBest(methodTrain,trainBest);
				testTable += " & "+ convertBest(methodTest,testBest);
				nfTable += " &"+ convertBest(methodNf,nfBest);
				timeTable += "& "+convertBest(methodTime,timeBest);
			}

			nfTrainTable += nfTable+trainTable +"\\\\ \n";
			timeTestTable += timeTable + testTable+ "\\\\ \n";
		}

		nfTrainTable += "\\hline\n \\end{tabular}\n"+"\\end{table}\n";
		timeTestTable += "\\hline\n \\end{tabular}\n"+"\\end{table}\n";

		pt.println(nfTrainTable);
		pt.println(timeTestTable);

		pt.println("\\end{document}\n");
		pt.close();
	}

	public static void printEvolutionaryProcess() throws FileNotFoundException{
		for(String dataset: datasets){
			PrintStream pse = new PrintStream(new File("ProcessResults/FeatureSelection/Draw/Data/"+dataset+".txt"));
			pse.println("Iteration, Method, Fitness");
			Map<String,Results> methodResult = datasetMethod.get(dataset);

			for(int iIndex = 0;iIndex<noIteration;iIndex++){
				for(String method: methods){
					String methodName;
					if(method.equals("StaticS1"))
						methodName = "Static";
					else if(method.equals("DynamicS3"))
						methodName = "Dynamic";
					else
						methodName = method;
					String s = iIndex+", "+methodName;
					Results rs = methodResult.get(method);
					double value=0;
					for(int r=0;r<noRun;r++){
						value+= rs.fitness[iIndex][r];
					}
					value = value/noRun;
					s+= ", "+value;
					pse.println(s);
				}
			}
			pse.close();
		}
	}
	
	public static void printSignificance(List<String> masters){
		String trainPrint = "Significant train\n";
		String testPrint = "Significant test\n";
		String nfPrint = "Significant number features\n";
		
		trainPrint += ("Method\t");
		testPrint += ("Method\t");
		nfPrint += ("Method\t");
		
		for(String method: methods){
			String s = method+"\t";
			trainPrint += s;
			testPrint += s;
			nfPrint += s;
		}
		
		trainPrint += "\n";testPrint += "\n";nfPrint += "\n";
		
		for(String master:masters){
			trainPrint += (master+"\t");
			testPrint += (master+"\t");
			nfPrint += (master+"\t");
			
			for(String other: methods){
				//0-training, 1-testing, 2-nofeatures
				int[] win= new int[3];
				int[] draw=new int[3];
				int[] lost=new int[3];
				for(String dataset: datasets){
					Map<String,Results> methodResults = datasetMethod.get(dataset);
					Results masterResult = methodResults.get(master);
					Results otherResult = methodResults.get(other);
					
					String trainCompare = WilsonTestBing.TestBingNew(otherResult.trainaccs, masterResult.trainaccs, false);
					if(trainCompare.equals("="))
						draw[0]++;
					else if(trainCompare.equals("+"))
						win[0]++;
					else
						lost[0]++;
					
					String testCompare = WilsonTestBing.TestBingNew(otherResult.testaccs, masterResult.testaccs, false);
					if(testCompare.equals("="))
						draw[1]++;
					else if(testCompare.equals("+"))
						win[1]++;
					else
						lost[1]++;
					
					String nfCompare = WilsonTestBing.TestBingNew(otherResult.sizes, masterResult.sizes, true);
					if(nfCompare.equals("="))
						draw[2]++;
					else if(nfCompare.equals("+"))
						win[2]++;
					else
						lost[2]++;
				}
				
				if(master.equals(other)){
					trainPrint += ("-\t");
					testPrint += ("-\t");
					nfPrint += ("-\t");
				}
				else{
					trainPrint += (win[0]+"\\"+draw[0]+"\\"+lost[0]+"\t");
					testPrint +=  (win[1]+"\\"+draw[1]+"\\"+lost[1]+"\t");
					nfPrint +=  (win[2]+"\\"+draw[2]+"\\"+lost[2]+"\t");
				}
			}
			trainPrint += "\n";
			testPrint+= "\n";
			nfPrint += "\n";
		}
		System.out.println(trainPrint);
		System.out.println(testPrint);
		System.out.println(nfPrint);
	}
	
	public static String convertBest(double value,List<Double> top){
		NumberFormat aveformatter = new DecimalFormat("0.00");
		if(value == top.get(0))
			return "\\textbf{"+aveformatter.format(value)+"}";
		else if(value == top.get(1))
			return "\\underline{"+aveformatter.format(value)+"}";
		else 
			return aveformatter.format(value);
	}
	
}
