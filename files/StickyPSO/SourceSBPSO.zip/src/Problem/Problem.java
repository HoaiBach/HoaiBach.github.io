package Problem;
import java.util.List;

public abstract class Problem {
	private boolean isMaximised;
	private double threshold;
	
	public Problem(double threshold){
		this.threshold = threshold;
	}
	
	public abstract double fitness(List<Double> position);
	
	public double getWorstFitness(){
		double s = isMaximised ? -Double.MAX_VALUE: Double.MAX_VALUE;
		return s;
	}

	/**
	 * 
	 * @param me
	 * @param enemy
	 * @return return true if me is better than enemy
	 */
	public boolean isBetter(double me, double enemy){
		return (isMaximised ? (me>enemy): (me<enemy));
	}
	
	public boolean isMaximised() {
		return isMaximised;
	}

	public void setMaximised(boolean isMaximised) {
		this.isMaximised = isMaximised;
	}

	public double getThreshold() {
		return threshold;
	}

	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}
	
	public double[] positionToArray(List<Double> position){
		double[] array = new double[position.size()];
		for(int i=0;i<position.size();i++){
			array[i] = position.get(i);
		}
		return array;
	}
}
