package Problem.Knapsack;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

import Problem.Problem;

public class Knapsack extends Problem{

	private int noItems,noDim,optimal;
	private int[] profits,capacities;
	private int[][] costs;
	
	public Knapsack(double threshold) {
		super(threshold);
		this.setMaximised(true);
		readFile("data.dat");
	}


	private void readFile(String file) {
		try {
			Scanner sc = new Scanner(new File(file));
			String line = sc.nextLine();
			String[] split = line.split(" ");
			noItems = Integer.parseInt(split[0].trim());
			noDim = Integer.parseInt(split[1].trim());
			setOptimal(Integer.parseInt(split[2].trim()));

			profits = new int[noItems];
			costs = new int[noItems][noDim];
			capacities = new int[noDim];

			split = sc.nextLine().split(" ");
			for(int i=0;i<noItems;i++){
				profits[i] = Integer.parseInt(split[i]);
			}

			for(int i=0;i<noItems;i++){
				split = sc.nextLine().split(" ");
				for(int j=0;j<noDim;j++){
					costs[i][j] = Integer.parseInt(split[j]);
				}
			}

			split = sc.nextLine().split(" ");
			for( int i=0;i<noDim;i++){
				capacities[i]  = Integer.parseInt(split[i]);
			}

			sc.close();
		} catch (FileNotFoundException e) {
			System.out.println("Can not read file: "+file);
		}
	}

	public double calculateProfit(List<Double> position){
		double profit = 0;

		for(int i=0;i<position.size();i++){
			//item is selected
			if(position.get(i) > this.getThreshold()){
				profit += profits[i];
			}
		}

		return profit;
	}

	public double calculatePenalty(List<Double> position){
		double penalty = -Double.MAX_VALUE;

		//for each resource
		for(int i=0;i<noDim;i++){
			double cost =0;
			for(int j=0;j<position.size();j++){
				//item is selected
				if(position.get(j) > this.getThreshold()){
					cost+= this.costs[j][i];
				}
			}
			double singlePenalty = cost - capacities[i];
			penalty = (penalty < singlePenalty) ? singlePenalty : penalty;
		}

		return penalty;
	}

	public double fitness(List<Double> position) {
		double profit = 0;
		int noOverfill = 0;
		int noSelected = 0;
		double[] costSelected = new double[noDim];
		double maxProfit = -Double.MAX_VALUE;
		
		for(int i=0;i<position.size();i++){
			if(position.get(i) > this.getThreshold()){
				noSelected ++;
				double profit_i = profits[i];
				
				//update maxProfit
				if(profit_i>maxProfit)
					maxProfit = profit_i;
				
				//update the cost
				for(int j=0;j<noDim;j++){
					costSelected[j] += costs[i][j];
				}
				
				//update profit
				profit += profit_i;
			}
		}
		
		for(int j=0;j<noDim;j++){
			if(costSelected[j] > capacities[j])
				noOverfill++;
		}
		
		double fitness = profit-noOverfill*noSelected*(maxProfit+1);
		
		return fitness;
	}

	public int getNoItems(){
		return noItems;
	}

	public int getNoDim(){
		return noDim;
	}

	public int getOptimal() {
		return optimal;
	}

	public int[] getProfits(){
		return profits;
	}

	public int[][] getCost(){
		return costs;
	}

	public int[] getCapacities(){
		return capacities;
	}

	public void setOptimal(int optimal) {
		this.optimal = optimal;
	}
}
