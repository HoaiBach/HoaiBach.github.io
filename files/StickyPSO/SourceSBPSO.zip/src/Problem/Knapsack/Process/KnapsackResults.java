package Problem.Knapsack.Process;

public class KnapsackResults {
	
	protected double[] profits;
	protected double[] times;
	protected double[][] evoprocess;
	
	public KnapsackResults(int noRuns, int noRecords){
		profits = new double[noRuns];
		times = new double[noRuns];
		evoprocess = new double[noRuns][noRecords];
	}
	
	public int getHits(double optimal){
		int count=0;
		for(double profit: profits)
			if(profit==optimal)
				count++;
		return count;
	}
}
