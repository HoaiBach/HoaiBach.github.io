package Problem.Knapsack.Process;

public class DatasetInfo {

	int noItems, noCosts;
	double optimal;
}
