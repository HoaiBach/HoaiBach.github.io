package Problem.Knapsack.Process;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import Utility.WilsonTestBing;

public class ExtractKnapsack {
	List<String> datasets;
	List<String> methods;
	String inDir = "FullResults/Knapsack";
	String outDir = "ProcessResults/Knapsack";
	Map<String,Map<String,KnapsackResults>> dataMethod;
	Map<String,DatasetInfo> dataInfo;
	int noRuns = 30;
	int noRecords = 101;

	public ExtractKnapsack() throws FileNotFoundException{
		datasets = new ArrayList<String>();

//				for(int i=1; i<=30; i++)
//					datasets.add("weish"+(i<10? "0"+i:i));
		//
//				for(int i=1;i<=8;i++)
//					datasets.add("weing"+i);
//				for(int i=2;i<=7;i++)
//					datasets.add("pet"+i);
//				for(int i=1;i<=7;i++)
//					if(i!=3)
//					datasets.add("pb"+i);
		//		
//		datasets.add("sento1"); datasets.add("sento2");
		for(int i=1; i<=11; i++)
			datasets.add("gk"+(i<10? "0"+i:i));
		
		datasets.add("UCI500"); datasets.add("UCI1000"); datasets.add("UCI2000"); datasets.add("UCI5000");
		datasets.add("ISCI500"); datasets.add("ISCI1000"); datasets.add("ISCI2000"); datasets.add("ISCI5000");
		datasets.add("SCI500"); datasets.add("SCI1000"); datasets.add("SCI2000"); datasets.add("SCI5000");
		datasets.add("WCI500"); datasets.add("WCI1000"); datasets.add("WCI2000"); datasets.add("WCI5000");		


		List<String> masters = new ArrayList<String>();
		masters.add("StaticS1");
		masters.add("DynamicS3");
		
		methods = new ArrayList<String>();
		methods.add("NMBDE");
		methods.add("Quantum");
		methods.add("Up");
		methods.add("TimeVarying");
		methods.add("StaticS1");
//		methods.add("DynamicS1");
		methods.add("DynamicS3");

		dataMethod = new HashMap<String,Map<String,KnapsackResults>>();
		dataInfo = new HashMap<String,DatasetInfo>();

		extractData();
//		result2Latex(outDir+"/Latex");

//		printSignificance(masters, methods);
//		extractConvergence(outDir+"/Draw/Convergence/Data");
		time2Latex(outDir+"/Latex");
	}
	

	public void extractData(){
		for(String dataset: datasets){
			System.out.println(dataset);
			String dataDir = inDir+"/"+dataset;
			Map<String,KnapsackResults> methodResult = new HashMap<String,KnapsackResults>();

			for(String method: methods){
				String methodDir = dataDir+"/"+method;
				KnapsackResults result = extractMethod(methodDir, dataset);

				methodResult.put(method, result);
			}

			dataMethod.put(dataset, methodResult);
		}
	}

	public KnapsackResults extractMethod(String dir, String dataset){
		KnapsackResults result = new KnapsackResults(noRuns,noRecords);

		for(int run=1; run<=noRuns; run++){
			File file = new File(dir+"/Output_"+run+".txt");
			try {
				Scanner sc = new Scanner(file);
				sc.nextLine();

				if(!dataInfo.containsKey(dataset)){
					String line = sc.nextLine();
					String[] splits = line.split("\\s+");
					DatasetInfo info = new DatasetInfo();
					info.noItems = Integer.parseInt(splits[0].trim());
					info.optimal = Double.parseDouble(splits[1]);
					info.noCosts = Integer.parseInt(splits[2].trim());
					dataInfo.put(dataset, info);
					sc.nextLine();
				}
				else{
					sc.nextLine();sc.nextLine();
				}

				//start scanning for evolutionary process
				for(int i=0; i<=noRecords-1; i++){
					sc.nextLine();
					String line = sc.nextLine();
					String[] splits = line.split(":");
					result.evoprocess[run-1][i] = Double.parseDouble(splits[1].trim());
					sc.nextLine();sc.nextLine();
				}

				//now scan for results
				sc.nextLine();
				String line = sc.nextLine();
				String[] splits = line.split(",");
				result.profits[run-1] = Double.parseDouble(splits[0].trim());
				result.times[run-1] = Double.parseDouble(splits[2].trim())/1000;

				sc.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		return result;
	}

	public void result2Latex(String dir){
		File file = new File(dir+"/Result.tex");
		PrintStream pt;
		try {
			pt = new PrintStream(file);

			pt.println("\\documentclass{report}\n"
					+ "\\usepackage[cm]{fullpage}\n"
					+ "\\usepackage{rotating}\n"
					+ "\\usepackage{longtable}\n"
					+ "\\begin{document}\n");

			String format = "{lll";
			for(int i=0;i<methods.size();i++)
				format+="l";
			format += "}";
			String first = "Dataset & n & m ";
			for(String method: methods)
				first += " & "+method;
			pt.println(
					//					"\\begin{table*}\n"
					//					+ "\\centering\n"
					//					+ "\\scriptsize\n"+		
					"\\begin{longtable}"+format+"\n"+
					//					 "\\hline\n"
					first+"\\\\\\hline\n");

			for(String dataset: datasets){
				String toPrint = capital(dataset);
				DatasetInfo info = dataInfo.get(dataset);
				toPrint += " & "+info.noItems + " & " + 
						info.noCosts;

				double[] ave = new double[methods.size()];
				double[][] fullResults = new double[methods.size()][noRuns];
				double[] std = new double[methods.size()];
				int[] hits = new int[methods.size()];
				int bestHit = -1;

				for(int i=0;i<methods.size();i++){
					String method = methods.get(i);
					KnapsackResults result = dataMethod.get(dataset).get(method);
					fullResults[i] = result.profits;
					ave[i] = ave(result.profits);
					std[i] = std(result.profits);
					if(info.optimal >0 )
						hits[i] = result.getHits(info.optimal);
				}

				for(int hit: hits)
					if (hit > bestHit)
						bestHit = hit;

				List<Double> union = new ArrayList<>();
				for(double d: ave)
					union.add(d);
				Collections.sort(union);
				double best = union.get(union.size()-1);
				double secondBest = union.get(union.size()-2);

				DecimalFormat f = new DecimalFormat("0.000E0");
				DecimalFormat f_std = new DecimalFormat("0.0E0");
				for(int methodIndex = 0;methodIndex<methods.size();methodIndex++){
					double value = ave[methodIndex];
					double s = std[methodIndex];
					//compare with other				
					if(value == best){
						//sign
						boolean betterThanALl = true;
						double[] mine = fullResults[methodIndex];
						for(int otherIndex=0;otherIndex<methods.size();otherIndex++){
							if(otherIndex!=methodIndex)
							{
								double[] other = fullResults[otherIndex];
								if(!WilsonTestBing.TestBingNew(other, mine, false).equals("+")){
									betterThanALl = false;
									break;
								}
							}
						}

						toPrint += " & \\textbf{"+f.format(value) + " $\\pm$ "+f_std.format(s)+"}";
//								+(betterThanALl? "$\\dagger$":"");
					}
					else if(value == secondBest)
						toPrint += " & \\underline{"+f.format(value) +" $\\pm$ "+f_std.format(s)+"}";
					else
						toPrint += " & "+f.format(value) +" $\\pm$ "+f_std.format(s);
				}
				toPrint += "\\\\\n";

				//print the std
//				toPrint += "& & ";
//				for(double value:std)
//					toPrint += "& $\\pm$"+f_std.format(value);
//				toPrint += "\\\\ \\\\ \n";

				//print the hits
				//				toPrint += "& & & ";
				//				for(int value:hits)
				//					if(info.optimal <=0)
				//						toPrint += "& -";
				//					else
				//						toPrint += "& "+(value==bestHit?"\\textbf{"+value+"}":value);

				pt.println(toPrint);
			}

			pt.println("\\hline \n \\end{longtable}\n");

			//Significant test


			pt.println("\\end{document}\n ");
			pt.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	

	private void time2Latex(String dir) {
		File file = new File(dir+"/Time.tex");
		PrintStream pt;
		DecimalFormat f = new DecimalFormat("0.00");
		try {
			pt = new PrintStream(file);
			
			pt.println("\\documentclass{report}\n"
					+ "\\usepackage[cm]{fullpage}\n"
					+ "\\usepackage{rotating}\n"
					+ "\\usepackage{longtable}\n"
					+ "\\begin{document}\n");
			pt.println("\\begin{table}");
			pt.println("\\centering");
			pt.println("\\caption{Computation time on Knapsack datasets (seconds).}");
			pt.println("\\label{tb:timeKS}");
			pt.print("\\begin{tabular}{");
			
			pt.print("l");
			for(int i=0;i<methods.size();i++){
				pt.print("l");
			}
			pt.println("} \n \\hline");
			pt.print("Dataset ");
			for(int i=0;i<methods.size();i++){
				pt.print(" & "+methods.get(i));
			}
			pt.println("\\\\\\hline");
			
			for(String dataset: datasets){
				String toPrint = dataset;
				double[] average = new double[methods.size()];
				double[] std = new double[methods.size()];
				double best = Double.MAX_VALUE;
				for(int i=0;i<methods.size();i++){
					String method = methods.get(i);
					KnapsackResults results = dataMethod.get(dataset).get(method);
					double time = ave(results.times);
					if(time<best)
						best = time;
					average[i] = time;
					std[i] = std(results.times);
				}
				
				for(int i=0;i<methods.size();i++)
				{
					toPrint += "& "+(average[i]==best? 
							"\\textbf{"+f.format(average[i])+"("+f.format(std[i])+")"+"}": 
								f.format(average[i])+"("+f.format(std[i])+")");
				}
				toPrint +="\\\\\\hline";
				pt.println(toPrint);
			}
			pt.println();
			
			
			
			pt.println("\\end{tabular}");
			pt.println("\\end{table}");
			
			
			pt.println("\\end{document}\n ");
			pt.close();		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void printSignificance(List<String> masters,List<String> methods){
		System.out.print("Method\t");
		for(String method: methods){
			System.out.print(method+"\t\t");
		}
		System.out.println();
		for(String master:masters){
			System.out.print(master+"\t\t");
			for(String other: methods){
				int win=0,draw=0,lost=0;
				for(String dataset: datasets){
					Map<String,KnapsackResults> methodResults = dataMethod.get(dataset);
					KnapsackResults masterResult = methodResults.get(master);
					KnapsackResults otherResult = methodResults.get(other);
					String compare = WilsonTestBing.TestBingNew(otherResult.profits, masterResult.profits, false);
					if(compare.equals("="))
						draw++;
					else if(compare.equals("+"))
						win++;
					else
						lost++;
				}
				if(master.equals(other)){
					System.out.print("-\t\t");
				}
				else{
					System.out.print(win+"\\"+draw+"\\"+lost+"\t\t");
				}
			}
			System.out.println();
		}
	}

	public void extractConvergence(String dir) throws FileNotFoundException{
		int step = 10;
		for(String dataset: datasets){
			Map<String,KnapsackResults> methodResult = dataMethod.get(dataset);
			PrintStream pt =new PrintStream(dir+"/"+dataset+".txt");
			pt.println("Method, Iteration, Fitness");
			for(String method: methods){
				double[][] eps = methodResult.get(method).evoprocess;
				for(int i=0;i<eps[0].length;i++){
					double[] fI = new double[noRuns];
					for(int run = 0;run<eps.length;run++)
						fI[run] = eps[run][i];
					double ave = ave(fI);
					pt.println(method+", "+i*step+", "+ave);
				}
			}
			pt.close();
		}
	}

	public double ave(double[] values){
		double sum = 0;
		for(double value: values)
			sum+=value;
		return sum/values.length;
	}

	public double std(double[] values){
		double mean = ave(values);
		double std = 0;
		for(double value: values)
			std += (value-mean)*(value-mean);
		std = std/(values.length-1);
		return Math.sqrt(std);
	}

	public String capital(String s){
		return s.substring(0,1).toUpperCase()+s.substring(1);
	}

	public static void main(String[] args){
		try {
			ExtractKnapsack ek = new ExtractKnapsack();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
