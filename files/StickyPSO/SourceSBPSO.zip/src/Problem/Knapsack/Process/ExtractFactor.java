package Problem.Knapsack.Process;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class ExtractFactor {

	public static void main(String[] args) throws FileNotFoundException{
		String[] datasets = new String[]{
				"weing1","pb1","gk01","gk05","UCI500","WCI1000","SCI2000"
		};//,"ISCI5000"
		String[] methods = new String[]{
			"NMBDE", "Quantum","Up","TimeVarying","StaticS1","DynamicS3"
		};
		int noIterations = 1000;
		int runIndex = 1;
		
		String indir = "FullResults/Factor/";
		String outdir = "ProcessResults/Factor/Data/";
		
		for(String dataset: datasets){
			PrintStream pt = new PrintStream(new File(outdir+dataset+".txt"));
			pt.println("Method,Iteration,Factor");
			for(String method: methods){
				String methodname;
				if(method.equals("StaticS1"))
					methodname = "Static";
				else if(method.equals("DynamicS3"))
					methodname = "Dynamic";
				else
					methodname = method;
				
				Scanner sc = new Scanner(new File(indir+dataset+"/"+method+"/factor_"+runIndex+".txt"));
				int iteration = 1;
				while(sc.hasNextLine()){
					String line = sc.nextLine();
					line = sc.nextLine();
					String factorString = line.split(":")[1].trim();
					double factor;
					if(factorString.equalsIgnoreCase("NaN"))
						factor=-0.1;
					else
						factor= Double.parseDouble(factorString);
					pt.println(methodname+","+iteration+","+factor);
					iteration++;
					sc.nextLine();
				}
				sc.close();
			}
			pt.close();
		}
	}
}
