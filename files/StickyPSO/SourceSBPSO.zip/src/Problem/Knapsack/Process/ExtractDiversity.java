package Problem.Knapsack.Process;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;

public class ExtractDiversity {

	public static void main(String[] args) throws FileNotFoundException{
		String[] datasets = new String[]{"weing1","pb1","gk01","gk05","UCI500","WCI1000","SCI2000","ISCI5000"};
		String[] methods = new String[]{"NMBDE","Quantum","Up","TimeVarying","DynamicS3","StaticS1"};
		int noRuns = 30;
		int noIterations = 1000;
		String outDir = "ProcessResults/Diversity/Data/";
		String inDir  = "FullResults/Diversity/";
		
		for(String dataset: datasets){
			PrintStream output = new PrintStream(new File(outDir+dataset+".txt"));
			output.println("Method,Iteration,Distance");
			
			for(String method: methods){
				double[] fitness = new double[noIterations];
				for(int i=1;i<=noRuns;i++){
					Scanner sc = new Scanner(new File(inDir+dataset+"/"+method+"/diversity_"+i+".txt"));
					int iterationIndex=0;
					while(sc.hasNextLine()){
						String line = sc.nextLine();
						line = sc.nextLine();
						fitness[iterationIndex] += Double.parseDouble(line.split(":")[1].trim());
						iterationIndex++;
						sc.nextLine();
					}
					sc.close();
				}
				
				for(int i=0;i<noIterations;i++)
				{
					if(method.startsWith("Dynamic"))
						method = "Dynamic";
					if(method.startsWith("Static"))
						method = "Static";
					output.println(method+","+(i+1)+","+(fitness[i]/noRuns));
				}
			}
			
			output.close();
		}
	}
	
}
